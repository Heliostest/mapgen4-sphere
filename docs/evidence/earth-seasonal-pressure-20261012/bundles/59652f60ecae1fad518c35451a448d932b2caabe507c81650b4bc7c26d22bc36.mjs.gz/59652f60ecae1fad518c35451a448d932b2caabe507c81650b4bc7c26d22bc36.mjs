var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __commonJS = (cb, mod) => function __require() {
  try {
    return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
  } catch (e2) {
    throw mod = 0, e2;
  }
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));

// node_modules/.pnpm/hash-int@1.0.0/node_modules/hash-int/hashint.js
var require_hashint = __commonJS({
  "node_modules/.pnpm/hash-int@1.0.0/node_modules/hash-int/hashint.js"(exports, module) {
    "use strict";
    var A;
    if (typeof Uint32Array === void 0) {
      A = [0];
    } else {
      A = new Uint32Array(1);
    }
    function hashInt(x) {
      A[0] = x | 0;
      A[0] -= A[0] << 6;
      A[0] ^= A[0] >>> 17;
      A[0] -= A[0] << 9;
      A[0] ^= A[0] << 4;
      A[0] -= A[0] << 3;
      A[0] ^= A[0] << 10;
      A[0] ^= A[0] >>> 15;
      return A[0];
    }
    module.exports = hashInt;
  }
});

// node_modules/.pnpm/@redblobgames+prng@https+++_416aa289375707ae1ec9f251aa57e488/node_modules/@redblobgames/prng/index.js
var require_prng = __commonJS({
  "node_modules/.pnpm/@redblobgames+prng@https+++_416aa289375707ae1ec9f251aa57e488/node_modules/@redblobgames/prng/index.js"(exports) {
    "use strict";
    var hashInt = require_hashint();
    exports.makeRandInt = function(seed) {
      let i = 0;
      return function(N) {
        i++;
        return hashInt(seed + i) % N;
      };
    };
    exports.makeRandFloat = function(seed) {
      let randInt = exports.makeRandInt(seed);
      let divisor = 268435456;
      return function() {
        return randInt(divisor) / divisor;
      };
    };
  }
});

// docs/evidence/earth-seasonal-pressure-20261012/full.ts
import assert from "node:assert/strict";
import { readFile, writeFile, mkdir } from "node:fs/promises";
import { createHash } from "node:crypto";

// config.js
var HIGH_DETAIL_SPACING = 2.75;
var config_default = {
  spacing: 5.5,
  mountainSpacing: 35,
  mesh: {
    seed: 12345
  },
  elevation: {},
  biomes: {},
  rivers: {},
  render: {}
};

// node_modules/.pnpm/robust-predicates@3.0.2/node_modules/robust-predicates/esm/util.js
var epsilon = 11102230246251565e-32;
var splitter = 134217729;
var resulterrbound = (3 + 8 * epsilon) * epsilon;
function sum(elen, e2, flen, f, h) {
  let Q, Qnew, hh, bvirt;
  let enow = e2[0];
  let fnow = f[0];
  let eindex = 0;
  let findex = 0;
  if (fnow > enow === fnow > -enow) {
    Q = enow;
    enow = e2[++eindex];
  } else {
    Q = fnow;
    fnow = f[++findex];
  }
  let hindex = 0;
  if (eindex < elen && findex < flen) {
    if (fnow > enow === fnow > -enow) {
      Qnew = enow + Q;
      hh = Q - (Qnew - enow);
      enow = e2[++eindex];
    } else {
      Qnew = fnow + Q;
      hh = Q - (Qnew - fnow);
      fnow = f[++findex];
    }
    Q = Qnew;
    if (hh !== 0) {
      h[hindex++] = hh;
    }
    while (eindex < elen && findex < flen) {
      if (fnow > enow === fnow > -enow) {
        Qnew = Q + enow;
        bvirt = Qnew - Q;
        hh = Q - (Qnew - bvirt) + (enow - bvirt);
        enow = e2[++eindex];
      } else {
        Qnew = Q + fnow;
        bvirt = Qnew - Q;
        hh = Q - (Qnew - bvirt) + (fnow - bvirt);
        fnow = f[++findex];
      }
      Q = Qnew;
      if (hh !== 0) {
        h[hindex++] = hh;
      }
    }
  }
  while (eindex < elen) {
    Qnew = Q + enow;
    bvirt = Qnew - Q;
    hh = Q - (Qnew - bvirt) + (enow - bvirt);
    enow = e2[++eindex];
    Q = Qnew;
    if (hh !== 0) {
      h[hindex++] = hh;
    }
  }
  while (findex < flen) {
    Qnew = Q + fnow;
    bvirt = Qnew - Q;
    hh = Q - (Qnew - bvirt) + (fnow - bvirt);
    fnow = f[++findex];
    Q = Qnew;
    if (hh !== 0) {
      h[hindex++] = hh;
    }
  }
  if (Q !== 0 || hindex === 0) {
    h[hindex++] = Q;
  }
  return hindex;
}
function estimate(elen, e2) {
  let Q = e2[0];
  for (let i = 1; i < elen; i++) Q += e2[i];
  return Q;
}
function vec(n2) {
  return new Float64Array(n2);
}

// node_modules/.pnpm/robust-predicates@3.0.2/node_modules/robust-predicates/esm/orient2d.js
var ccwerrboundA = (3 + 16 * epsilon) * epsilon;
var ccwerrboundB = (2 + 12 * epsilon) * epsilon;
var ccwerrboundC = (9 + 64 * epsilon) * epsilon * epsilon;
var B = vec(4);
var C1 = vec(8);
var C2 = vec(12);
var D = vec(16);
var u = vec(4);
function orient2dadapt(ax, ay, bx, by, cx, cy, detsum) {
  let acxtail, acytail, bcxtail, bcytail;
  let bvirt, c, ahi, alo, bhi, blo, _i, _j, _0, s1, s0, t1, t0, u32;
  const acx = ax - cx;
  const bcx = bx - cx;
  const acy = ay - cy;
  const bcy = by - cy;
  s1 = acx * bcy;
  c = splitter * acx;
  ahi = c - (c - acx);
  alo = acx - ahi;
  c = splitter * bcy;
  bhi = c - (c - bcy);
  blo = bcy - bhi;
  s0 = alo * blo - (s1 - ahi * bhi - alo * bhi - ahi * blo);
  t1 = acy * bcx;
  c = splitter * acy;
  ahi = c - (c - acy);
  alo = acy - ahi;
  c = splitter * bcx;
  bhi = c - (c - bcx);
  blo = bcx - bhi;
  t0 = alo * blo - (t1 - ahi * bhi - alo * bhi - ahi * blo);
  _i = s0 - t0;
  bvirt = s0 - _i;
  B[0] = s0 - (_i + bvirt) + (bvirt - t0);
  _j = s1 + _i;
  bvirt = _j - s1;
  _0 = s1 - (_j - bvirt) + (_i - bvirt);
  _i = _0 - t1;
  bvirt = _0 - _i;
  B[1] = _0 - (_i + bvirt) + (bvirt - t1);
  u32 = _j + _i;
  bvirt = u32 - _j;
  B[2] = _j - (u32 - bvirt) + (_i - bvirt);
  B[3] = u32;
  let det = estimate(4, B);
  let errbound = ccwerrboundB * detsum;
  if (det >= errbound || -det >= errbound) {
    return det;
  }
  bvirt = ax - acx;
  acxtail = ax - (acx + bvirt) + (bvirt - cx);
  bvirt = bx - bcx;
  bcxtail = bx - (bcx + bvirt) + (bvirt - cx);
  bvirt = ay - acy;
  acytail = ay - (acy + bvirt) + (bvirt - cy);
  bvirt = by - bcy;
  bcytail = by - (bcy + bvirt) + (bvirt - cy);
  if (acxtail === 0 && acytail === 0 && bcxtail === 0 && bcytail === 0) {
    return det;
  }
  errbound = ccwerrboundC * detsum + resulterrbound * Math.abs(det);
  det += acx * bcytail + bcy * acxtail - (acy * bcxtail + bcx * acytail);
  if (det >= errbound || -det >= errbound) return det;
  s1 = acxtail * bcy;
  c = splitter * acxtail;
  ahi = c - (c - acxtail);
  alo = acxtail - ahi;
  c = splitter * bcy;
  bhi = c - (c - bcy);
  blo = bcy - bhi;
  s0 = alo * blo - (s1 - ahi * bhi - alo * bhi - ahi * blo);
  t1 = acytail * bcx;
  c = splitter * acytail;
  ahi = c - (c - acytail);
  alo = acytail - ahi;
  c = splitter * bcx;
  bhi = c - (c - bcx);
  blo = bcx - bhi;
  t0 = alo * blo - (t1 - ahi * bhi - alo * bhi - ahi * blo);
  _i = s0 - t0;
  bvirt = s0 - _i;
  u[0] = s0 - (_i + bvirt) + (bvirt - t0);
  _j = s1 + _i;
  bvirt = _j - s1;
  _0 = s1 - (_j - bvirt) + (_i - bvirt);
  _i = _0 - t1;
  bvirt = _0 - _i;
  u[1] = _0 - (_i + bvirt) + (bvirt - t1);
  u32 = _j + _i;
  bvirt = u32 - _j;
  u[2] = _j - (u32 - bvirt) + (_i - bvirt);
  u[3] = u32;
  const C1len = sum(4, B, 4, u, C1);
  s1 = acx * bcytail;
  c = splitter * acx;
  ahi = c - (c - acx);
  alo = acx - ahi;
  c = splitter * bcytail;
  bhi = c - (c - bcytail);
  blo = bcytail - bhi;
  s0 = alo * blo - (s1 - ahi * bhi - alo * bhi - ahi * blo);
  t1 = acy * bcxtail;
  c = splitter * acy;
  ahi = c - (c - acy);
  alo = acy - ahi;
  c = splitter * bcxtail;
  bhi = c - (c - bcxtail);
  blo = bcxtail - bhi;
  t0 = alo * blo - (t1 - ahi * bhi - alo * bhi - ahi * blo);
  _i = s0 - t0;
  bvirt = s0 - _i;
  u[0] = s0 - (_i + bvirt) + (bvirt - t0);
  _j = s1 + _i;
  bvirt = _j - s1;
  _0 = s1 - (_j - bvirt) + (_i - bvirt);
  _i = _0 - t1;
  bvirt = _0 - _i;
  u[1] = _0 - (_i + bvirt) + (bvirt - t1);
  u32 = _j + _i;
  bvirt = u32 - _j;
  u[2] = _j - (u32 - bvirt) + (_i - bvirt);
  u[3] = u32;
  const C2len = sum(C1len, C1, 4, u, C2);
  s1 = acxtail * bcytail;
  c = splitter * acxtail;
  ahi = c - (c - acxtail);
  alo = acxtail - ahi;
  c = splitter * bcytail;
  bhi = c - (c - bcytail);
  blo = bcytail - bhi;
  s0 = alo * blo - (s1 - ahi * bhi - alo * bhi - ahi * blo);
  t1 = acytail * bcxtail;
  c = splitter * acytail;
  ahi = c - (c - acytail);
  alo = acytail - ahi;
  c = splitter * bcxtail;
  bhi = c - (c - bcxtail);
  blo = bcxtail - bhi;
  t0 = alo * blo - (t1 - ahi * bhi - alo * bhi - ahi * blo);
  _i = s0 - t0;
  bvirt = s0 - _i;
  u[0] = s0 - (_i + bvirt) + (bvirt - t0);
  _j = s1 + _i;
  bvirt = _j - s1;
  _0 = s1 - (_j - bvirt) + (_i - bvirt);
  _i = _0 - t1;
  bvirt = _0 - _i;
  u[1] = _0 - (_i + bvirt) + (bvirt - t1);
  u32 = _j + _i;
  bvirt = u32 - _j;
  u[2] = _j - (u32 - bvirt) + (_i - bvirt);
  u[3] = u32;
  const Dlen = sum(C2len, C2, 4, u, D);
  return D[Dlen - 1];
}
function orient2d(ax, ay, bx, by, cx, cy) {
  const detleft = (ay - cy) * (bx - cx);
  const detright = (ax - cx) * (by - cy);
  const det = detleft - detright;
  const detsum = Math.abs(detleft + detright);
  if (Math.abs(det) >= ccwerrboundA * detsum) return det;
  return -orient2dadapt(ax, ay, bx, by, cx, cy, detsum);
}

// node_modules/.pnpm/robust-predicates@3.0.2/node_modules/robust-predicates/esm/orient3d.js
var o3derrboundA = (7 + 56 * epsilon) * epsilon;
var o3derrboundB = (3 + 28 * epsilon) * epsilon;
var o3derrboundC = (26 + 288 * epsilon) * epsilon * epsilon;
var bc = vec(4);
var ca = vec(4);
var ab = vec(4);
var at_b = vec(4);
var at_c = vec(4);
var bt_c = vec(4);
var bt_a = vec(4);
var ct_a = vec(4);
var ct_b = vec(4);
var bct = vec(8);
var cat = vec(8);
var abt = vec(8);
var u2 = vec(4);
var _8 = vec(8);
var _8b = vec(8);
var _16 = vec(8);
var _12 = vec(12);
var fin = vec(192);
var fin2 = vec(192);

// node_modules/.pnpm/robust-predicates@3.0.2/node_modules/robust-predicates/esm/incircle.js
var iccerrboundA = (10 + 96 * epsilon) * epsilon;
var iccerrboundB = (4 + 48 * epsilon) * epsilon;
var iccerrboundC = (44 + 576 * epsilon) * epsilon * epsilon;
var bc2 = vec(4);
var ca2 = vec(4);
var ab2 = vec(4);
var aa = vec(4);
var bb = vec(4);
var cc = vec(4);
var u3 = vec(4);
var v = vec(4);
var axtbc = vec(8);
var aytbc = vec(8);
var bxtca = vec(8);
var bytca = vec(8);
var cxtab = vec(8);
var cytab = vec(8);
var abt2 = vec(8);
var bct2 = vec(8);
var cat2 = vec(8);
var abtt = vec(4);
var bctt = vec(4);
var catt = vec(4);
var _82 = vec(8);
var _162 = vec(16);
var _16b = vec(16);
var _16c = vec(16);
var _32 = vec(32);
var _32b = vec(32);
var _48 = vec(48);
var _64 = vec(64);
var fin3 = vec(1152);
var fin22 = vec(1152);

// node_modules/.pnpm/robust-predicates@3.0.2/node_modules/robust-predicates/esm/insphere.js
var isperrboundA = (16 + 224 * epsilon) * epsilon;
var isperrboundB = (5 + 72 * epsilon) * epsilon;
var isperrboundC = (71 + 1408 * epsilon) * epsilon * epsilon;
var ab3 = vec(4);
var bc3 = vec(4);
var cd = vec(4);
var de = vec(4);
var ea = vec(4);
var ac = vec(4);
var bd = vec(4);
var ce = vec(4);
var da = vec(4);
var eb = vec(4);
var abc = vec(24);
var bcd = vec(24);
var cde = vec(24);
var dea = vec(24);
var eab = vec(24);
var abd = vec(24);
var bce = vec(24);
var cda = vec(24);
var deb = vec(24);
var eac = vec(24);
var adet = vec(1152);
var bdet = vec(1152);
var cdet = vec(1152);
var ddet = vec(1152);
var edet = vec(1152);
var abdet = vec(2304);
var cddet = vec(2304);
var cdedet = vec(3456);
var deter = vec(5760);
var _83 = vec(8);
var _8b2 = vec(8);
var _8c = vec(8);
var _163 = vec(16);
var _24 = vec(24);
var _482 = vec(48);
var _48b = vec(48);
var _96 = vec(96);
var _192 = vec(192);
var _384x = vec(384);
var _384y = vec(384);
var _384z = vec(384);
var _768 = vec(768);
var xdet = vec(96);
var ydet = vec(96);
var zdet = vec(96);
var fin4 = vec(1152);

// node_modules/.pnpm/delaunator@5.1.0/node_modules/delaunator/index.js
var EPSILON = Math.pow(2, -52);
var EDGE_STACK = new Uint32Array(512);
var Delaunator = class _Delaunator {
  /**
   * Constructs a delaunay triangulation object given an array of points (`[x, y]` by default).
   * `getX` and `getY` are optional functions of the form `(point) => value` for custom point formats.
   *
   * @template P
   * @param {P[]} points
   * @param {(p: P) => number} [getX]
   * @param {(p: P) => number} [getY]
   */
  // @ts-expect-error TS2322
  static from(points, getX = defaultGetX, getY = defaultGetY) {
    const n2 = points.length;
    const coords = new Float64Array(n2 * 2);
    for (let i = 0; i < n2; i++) {
      const p2 = points[i];
      coords[2 * i] = getX(p2);
      coords[2 * i + 1] = getY(p2);
    }
    return new _Delaunator(coords);
  }
  /**
   * Constructs a delaunay triangulation object given an array of point coordinates of the form:
   * `[x0, y0, x1, y1, ...]` (use a typed array for best performance). Duplicate points are skipped.
   *
   * @param {T} coords
   */
  constructor(coords) {
    const n2 = coords.length >> 1;
    if (n2 > 0 && typeof coords[0] !== "number") throw new Error("Expected coords to contain numbers.");
    this.coords = coords;
    const maxTriangles = Math.max(2 * n2 - 5, 0);
    this._triangles = new Uint32Array(maxTriangles * 3);
    this._halfedges = new Int32Array(maxTriangles * 3);
    this._hashSize = Math.ceil(Math.sqrt(n2));
    this._hullPrev = new Uint32Array(n2);
    this._hullNext = new Uint32Array(n2);
    this._hullTri = new Uint32Array(n2);
    this._hullHash = new Int32Array(this._hashSize);
    this._ids = new Uint32Array(n2);
    this._dists = new Float64Array(n2);
    this.trianglesLen = 0;
    this._cx = 0;
    this._cy = 0;
    this._hullStart = 0;
    this.hull = this._triangles;
    this.triangles = this._triangles;
    this.halfedges = this._halfedges;
    this.update();
  }
  /**
   * Updates the triangulation if you modified `delaunay.coords` values in place, avoiding expensive memory allocations.
   * Useful for iterative relaxation algorithms such as Lloyd's.
   */
  update() {
    const { coords, _hullPrev: hullPrev, _hullNext: hullNext, _hullTri: hullTri, _hullHash: hullHash } = this;
    const n2 = coords.length >> 1;
    let minX = Infinity;
    let minY = Infinity;
    let maxX = -Infinity;
    let maxY = -Infinity;
    for (let i = 0; i < n2; i++) {
      const x = coords[2 * i];
      const y = coords[2 * i + 1];
      if (x < minX) minX = x;
      if (y < minY) minY = y;
      if (x > maxX) maxX = x;
      if (y > maxY) maxY = y;
      this._ids[i] = i;
    }
    const cx = (minX + maxX) / 2;
    const cy = (minY + maxY) / 2;
    let i0 = 0, i1 = 0, i2 = 0;
    for (let i = 0, minDist = Infinity; i < n2; i++) {
      const d2 = dist(cx, cy, coords[2 * i], coords[2 * i + 1]);
      if (d2 < minDist) {
        i0 = i;
        minDist = d2;
      }
    }
    const i0x = coords[2 * i0];
    const i0y = coords[2 * i0 + 1];
    for (let i = 0, minDist = Infinity; i < n2; i++) {
      if (i === i0) continue;
      const d2 = dist(i0x, i0y, coords[2 * i], coords[2 * i + 1]);
      if (d2 < minDist && d2 > 0) {
        i1 = i;
        minDist = d2;
      }
    }
    let i1x = coords[2 * i1];
    let i1y = coords[2 * i1 + 1];
    let minRadius = Infinity;
    for (let i = 0; i < n2; i++) {
      if (i === i0 || i === i1) continue;
      const r = circumradius(i0x, i0y, i1x, i1y, coords[2 * i], coords[2 * i + 1]);
      if (r < minRadius) {
        i2 = i;
        minRadius = r;
      }
    }
    let i2x = coords[2 * i2];
    let i2y = coords[2 * i2 + 1];
    if (minRadius === Infinity) {
      for (let i = 0; i < n2; i++) {
        this._dists[i] = coords[2 * i] - coords[0] || coords[2 * i + 1] - coords[1];
      }
      quicksort(this._ids, this._dists, 0, n2 - 1);
      const hull = new Uint32Array(n2);
      let j = 0;
      for (let i = 0, d0 = -Infinity; i < n2; i++) {
        const id = this._ids[i];
        const d2 = this._dists[id];
        if (d2 > d0) {
          hull[j++] = id;
          d0 = d2;
        }
      }
      this.hull = hull.subarray(0, j);
      this.triangles = new Uint32Array(0);
      this.halfedges = new Int32Array(0);
      return;
    }
    if (orient2d(i0x, i0y, i1x, i1y, i2x, i2y) < 0) {
      const i = i1;
      const x = i1x;
      const y = i1y;
      i1 = i2;
      i1x = i2x;
      i1y = i2y;
      i2 = i;
      i2x = x;
      i2y = y;
    }
    const center = circumcenter(i0x, i0y, i1x, i1y, i2x, i2y);
    this._cx = center.x;
    this._cy = center.y;
    for (let i = 0; i < n2; i++) {
      this._dists[i] = dist(coords[2 * i], coords[2 * i + 1], center.x, center.y);
    }
    quicksort(this._ids, this._dists, 0, n2 - 1);
    this._hullStart = i0;
    let hullSize = 3;
    hullNext[i0] = hullPrev[i2] = i1;
    hullNext[i1] = hullPrev[i0] = i2;
    hullNext[i2] = hullPrev[i1] = i0;
    hullTri[i0] = 0;
    hullTri[i1] = 1;
    hullTri[i2] = 2;
    hullHash.fill(-1);
    hullHash[this._hashKey(i0x, i0y)] = i0;
    hullHash[this._hashKey(i1x, i1y)] = i1;
    hullHash[this._hashKey(i2x, i2y)] = i2;
    this.trianglesLen = 0;
    this._addTriangle(i0, i1, i2, -1, -1, -1);
    for (let k = 0, xp = 0, yp = 0; k < this._ids.length; k++) {
      const i = this._ids[k];
      const x = coords[2 * i];
      const y = coords[2 * i + 1];
      if (k > 0 && Math.abs(x - xp) <= EPSILON && Math.abs(y - yp) <= EPSILON) continue;
      xp = x;
      yp = y;
      if (i === i0 || i === i1 || i === i2) continue;
      let start2 = 0;
      for (let j = 0, key = this._hashKey(x, y); j < this._hashSize; j++) {
        start2 = hullHash[(key + j) % this._hashSize];
        if (start2 !== -1 && start2 !== hullNext[start2]) break;
      }
      start2 = hullPrev[start2];
      let e2 = start2, q;
      while (q = hullNext[e2], orient2d(x, y, coords[2 * e2], coords[2 * e2 + 1], coords[2 * q], coords[2 * q + 1]) >= 0) {
        e2 = q;
        if (e2 === start2) {
          e2 = -1;
          break;
        }
      }
      if (e2 === -1) continue;
      let t = this._addTriangle(e2, i, hullNext[e2], -1, -1, hullTri[e2]);
      hullTri[i] = this._legalize(t + 2);
      hullTri[e2] = t;
      hullSize++;
      let n3 = hullNext[e2];
      while (q = hullNext[n3], orient2d(x, y, coords[2 * n3], coords[2 * n3 + 1], coords[2 * q], coords[2 * q + 1]) < 0) {
        t = this._addTriangle(n3, i, q, hullTri[i], -1, hullTri[n3]);
        hullTri[i] = this._legalize(t + 2);
        hullNext[n3] = n3;
        hullSize--;
        n3 = q;
      }
      if (e2 === start2) {
        while (q = hullPrev[e2], orient2d(x, y, coords[2 * q], coords[2 * q + 1], coords[2 * e2], coords[2 * e2 + 1]) < 0) {
          t = this._addTriangle(q, i, e2, -1, hullTri[e2], hullTri[q]);
          this._legalize(t + 2);
          hullTri[q] = t;
          hullNext[e2] = e2;
          hullSize--;
          e2 = q;
        }
      }
      this._hullStart = hullPrev[i] = e2;
      hullNext[e2] = hullPrev[n3] = i;
      hullNext[i] = n3;
      hullHash[this._hashKey(x, y)] = i;
      hullHash[this._hashKey(coords[2 * e2], coords[2 * e2 + 1])] = e2;
    }
    this.hull = new Uint32Array(hullSize);
    for (let i = 0, e2 = this._hullStart; i < hullSize; i++) {
      this.hull[i] = e2;
      e2 = hullNext[e2];
    }
    this.triangles = this._triangles.subarray(0, this.trianglesLen);
    this.halfedges = this._halfedges.subarray(0, this.trianglesLen);
  }
  /**
   * Calculate an angle-based key for the edge hash used for advancing convex hull.
   *
   * @param {number} x
   * @param {number} y
   * @private
   */
  _hashKey(x, y) {
    return Math.floor(pseudoAngle(x - this._cx, y - this._cy) * this._hashSize) % this._hashSize;
  }
  /**
   * Flip an edge in a pair of triangles if it doesn't satisfy the Delaunay condition.
   *
   * @param {number} a
   * @private
   */
  _legalize(a) {
    const { _triangles: triangles, _halfedges: halfedges, coords } = this;
    let i = 0;
    let ar = 0;
    while (true) {
      const b = halfedges[a];
      const a0 = a - a % 3;
      ar = a0 + (a + 2) % 3;
      if (b === -1) {
        if (i === 0) break;
        a = EDGE_STACK[--i];
        continue;
      }
      const b0 = b - b % 3;
      const al = a0 + (a + 1) % 3;
      const bl = b0 + (b + 2) % 3;
      const p0 = triangles[ar];
      const pr = triangles[a];
      const pl = triangles[al];
      const p1 = triangles[bl];
      const illegal = inCircle(
        coords[2 * p0],
        coords[2 * p0 + 1],
        coords[2 * pr],
        coords[2 * pr + 1],
        coords[2 * pl],
        coords[2 * pl + 1],
        coords[2 * p1],
        coords[2 * p1 + 1]
      );
      if (illegal) {
        triangles[a] = p1;
        triangles[b] = p0;
        const hbl = halfedges[bl];
        if (hbl === -1) {
          let e2 = this._hullStart;
          do {
            if (this._hullTri[e2] === bl) {
              this._hullTri[e2] = a;
              break;
            }
            e2 = this._hullPrev[e2];
          } while (e2 !== this._hullStart);
        }
        this._link(a, hbl);
        this._link(b, halfedges[ar]);
        this._link(ar, bl);
        const br = b0 + (b + 1) % 3;
        if (i < EDGE_STACK.length) {
          EDGE_STACK[i++] = br;
        }
      } else {
        if (i === 0) break;
        a = EDGE_STACK[--i];
      }
    }
    return ar;
  }
  /**
   * Link two half-edges to each other.
   * @param {number} a
   * @param {number} b
   * @private
   */
  _link(a, b) {
    this._halfedges[a] = b;
    if (b !== -1) this._halfedges[b] = a;
  }
  /**
   * Add a new triangle given vertex indices and adjacent half-edge ids.
   *
   * @param {number} i0
   * @param {number} i1
   * @param {number} i2
   * @param {number} a
   * @param {number} b
   * @param {number} c
   * @private
   */
  _addTriangle(i0, i1, i2, a, b, c) {
    const t = this.trianglesLen;
    this._triangles[t] = i0;
    this._triangles[t + 1] = i1;
    this._triangles[t + 2] = i2;
    this._link(t, a);
    this._link(t + 1, b);
    this._link(t + 2, c);
    this.trianglesLen += 3;
    return t;
  }
};
function pseudoAngle(dx, dy) {
  const p2 = dx / (Math.abs(dx) + Math.abs(dy));
  return (dy > 0 ? 3 - p2 : 1 + p2) / 4;
}
function dist(ax, ay, bx, by) {
  const dx = ax - bx;
  const dy = ay - by;
  return dx * dx + dy * dy;
}
function inCircle(ax, ay, bx, by, cx, cy, px, py) {
  const dx = ax - px;
  const dy = ay - py;
  const ex = bx - px;
  const ey = by - py;
  const fx = cx - px;
  const fy = cy - py;
  const ap = dx * dx + dy * dy;
  const bp = ex * ex + ey * ey;
  const cp = fx * fx + fy * fy;
  return dx * (ey * cp - bp * fy) - dy * (ex * cp - bp * fx) + ap * (ex * fy - ey * fx) < 0;
}
function circumradius(ax, ay, bx, by, cx, cy) {
  const dx = bx - ax;
  const dy = by - ay;
  const ex = cx - ax;
  const ey = cy - ay;
  const bl = dx * dx + dy * dy;
  const cl = ex * ex + ey * ey;
  const d2 = 0.5 / (dx * ey - dy * ex);
  const x = (ey * bl - dy * cl) * d2;
  const y = (dx * cl - ex * bl) * d2;
  return x * x + y * y;
}
function circumcenter(ax, ay, bx, by, cx, cy) {
  const dx = bx - ax;
  const dy = by - ay;
  const ex = cx - ax;
  const ey = cy - ay;
  const bl = dx * dx + dy * dy;
  const cl = ex * ex + ey * ey;
  const d2 = 0.5 / (dx * ey - dy * ex);
  const x = ax + (ey * bl - dy * cl) * d2;
  const y = ay + (dx * cl - ex * bl) * d2;
  return { x, y };
}
function quicksort(ids, dists, left, right) {
  if (right - left <= 20) {
    for (let i = left + 1; i <= right; i++) {
      const temp2 = ids[i];
      const tempDist = dists[temp2];
      let j = i - 1;
      while (j >= left && dists[ids[j]] > tempDist) ids[j + 1] = ids[j--];
      ids[j + 1] = temp2;
    }
  } else {
    const median = left + right >> 1;
    let i = left + 1;
    let j = right;
    swap(ids, median, i);
    if (dists[ids[left]] > dists[ids[right]]) swap(ids, left, right);
    if (dists[ids[i]] > dists[ids[right]]) swap(ids, i, right);
    if (dists[ids[left]] > dists[ids[i]]) swap(ids, left, i);
    const temp2 = ids[i];
    const tempDist = dists[temp2];
    while (true) {
      do
        i++;
      while (dists[ids[i]] < tempDist);
      do
        j--;
      while (dists[ids[j]] > tempDist);
      if (j < i) break;
      swap(ids, i, j);
    }
    ids[left + 1] = ids[j];
    ids[j] = temp2;
    if (right - i + 1 >= j - left) {
      quicksort(ids, dists, i, right);
      quicksort(ids, dists, left, j - 1);
    } else {
      quicksort(ids, dists, left, j - 1);
      quicksort(ids, dists, i, right);
    }
  }
}
function swap(arr, i, j) {
  const tmp = arr[i];
  arr[i] = arr[j];
  arr[j] = tmp;
}
function defaultGetX(p2) {
  return p2[0];
}
function defaultGetY(p2) {
  return p2[1];
}

// sphere-mesh.ts
var import_prng = __toESM(require_prng(), 1);

// dual-mesh/index.ts
var TriangleMesh = class _TriangleMesh {
  static t_from_s(s) {
    return s / 3 | 0;
  }
  static s_prev_s(s) {
    return s % 3 === 0 ? s + 2 : s - 1;
  }
  static s_next_s(s) {
    return s % 3 === 2 ? s - 2 : s + 1;
  }
  // public data
  numSides;
  numSolidSides;
  numRegions;
  numSolidRegions;
  numTriangles;
  numSolidTriangles;
  numBoundaryRegions;
  // internal data that has accessors
  _halfedges;
  _triangles;
  _s_of_r;
  _vertex_t;
  _vertex_r;
  _options;
  // any other information we need to carry
  /**
   * Constructor takes partial mesh information from Delaunator and
   * constructs the rest.
   */
  constructor(init) {
    if ("points" in init) {
      this.numBoundaryRegions = init.numBoundaryPoints ?? 0;
      this.numSolidSides = init.numSolidSides ?? 0;
      this._vertex_t = [];
      this.update(init);
    } else {
      Object.assign(this, init);
    }
  }
  /**
   * Update internal data structures from Delaunator 
   */
  update(init) {
    this._vertex_r = init.points;
    this._triangles = init.delaunator.triangles;
    this._halfedges = init.delaunator.halfedges;
    this._update();
  }
  /**
   * Update internal data structures to match the input mesh.
   *
   * Use if you have updated the triangles/halfedges with Delaunator
   * and want the dual mesh to match the updated data. Note that
   * this does NOT update boundary regions or ghost elements.
   */
  _update() {
    let { _triangles, _halfedges, _vertex_r, _vertex_t } = this;
    this.numSides = _triangles.length;
    this.numRegions = _vertex_r.length;
    this.numSolidRegions = this.numRegions - 1;
    this.numTriangles = this.numSides / 3;
    this.numSolidTriangles = this.numSolidSides / 3;
    if (this._vertex_t.length < this.numTriangles) {
      const numOldTriangles = _vertex_t.length;
      const numNewTriangles = this.numTriangles - numOldTriangles;
      _vertex_t = _vertex_t.concat(new Array(numNewTriangles));
      for (let t = numOldTriangles; t < this.numTriangles; t++) {
        _vertex_t[t] = [0, 0];
      }
      this._vertex_t = _vertex_t;
    }
    this._s_of_r = new Int32Array(this.numRegions);
    for (let s = 0; s < _triangles.length; s++) {
      let endpoint = _triangles[_TriangleMesh.s_next_s(s)];
      if (this._s_of_r[endpoint] === 0 || _halfedges[s] === -1) {
        this._s_of_r[endpoint] = s;
      }
    }
    for (let s = 0; s < _triangles.length; s += 3) {
      let t = s / 3, a = _vertex_r[_triangles[s]], b = _vertex_r[_triangles[s + 1]], c = _vertex_r[_triangles[s + 2]];
      if (this.is_ghost_s(s)) {
        let dx = b[0] - a[0], dy = b[1] - a[1];
        let scale2 = 10 / Math.sqrt(dx * dx + dy * dy);
        _vertex_t[t][0] = 0.5 * (a[0] + b[0]) + dy * scale2;
        _vertex_t[t][1] = 0.5 * (a[1] + b[1]) - dx * scale2;
      } else {
        _vertex_t[t][0] = (a[0] + b[0] + c[0]) / 3;
        _vertex_t[t][1] = (a[1] + b[1] + c[1]) / 3;
      }
    }
  }
  /**
   * Construct ghost elements to complete the graph.
   */
  static addGhostStructure(init) {
    const { triangles, halfedges } = init.delaunator;
    const numSolidSides = triangles.length;
    let numUnpairedSides = 0, firstUnpairedEdge = -1;
    let s_unpaired_r = [];
    for (let s = 0; s < numSolidSides; s++) {
      if (halfedges[s] === -1) {
        numUnpairedSides++;
        s_unpaired_r[triangles[s]] = s;
        firstUnpairedEdge = s;
      }
    }
    const r_ghost = init.points.length;
    let newpoints = init.points.concat([[NaN, NaN]]);
    let r_newstart_s = new Int32Array(numSolidSides + 3 * numUnpairedSides);
    r_newstart_s.set(triangles);
    let s_newopposite_s = new Int32Array(numSolidSides + 3 * numUnpairedSides);
    s_newopposite_s.set(halfedges);
    for (let i = 0, s = firstUnpairedEdge; i < numUnpairedSides; i++, s = s_unpaired_r[r_newstart_s[_TriangleMesh.s_next_s(s)]]) {
      let s_ghost = numSolidSides + 3 * i;
      s_newopposite_s[s] = s_ghost;
      s_newopposite_s[s_ghost] = s;
      r_newstart_s[s_ghost] = r_newstart_s[_TriangleMesh.s_next_s(s)];
      r_newstart_s[s_ghost + 1] = r_newstart_s[s];
      r_newstart_s[s_ghost + 2] = r_ghost;
      let k = numSolidSides + (3 * i + 4) % (3 * numUnpairedSides);
      s_newopposite_s[s_ghost + 2] = k;
      s_newopposite_s[k] = s_ghost + 2;
    }
    return {
      numSolidSides,
      numBoundaryPoints: init.numBoundaryPoints,
      points: newpoints,
      delaunator: {
        triangles: r_newstart_s,
        halfedges: s_newopposite_s
      }
    };
  }
  // Accessors
  x_of_r(r) {
    return this._vertex_r[r][0];
  }
  y_of_r(r) {
    return this._vertex_r[r][1];
  }
  x_of_t(t) {
    return this._vertex_t[t][0];
  }
  y_of_t(t) {
    return this._vertex_t[t][1];
  }
  pos_of_r(r, out2 = []) {
    out2.length = 2;
    out2[0] = this.x_of_r(r);
    out2[1] = this.y_of_r(r);
    return out2;
  }
  pos_of_t(t, out2 = []) {
    out2.length = 2;
    out2[0] = this.x_of_t(t);
    out2[1] = this.y_of_t(t);
    return out2;
  }
  r_begin_s(s) {
    return this._triangles[s];
  }
  r_end_s(s) {
    return this._triangles[_TriangleMesh.s_next_s(s)];
  }
  t_inner_s(s) {
    return _TriangleMesh.t_from_s(s);
  }
  t_outer_s(s) {
    return _TriangleMesh.t_from_s(this._halfedges[s]);
  }
  s_next_s(s) {
    return _TriangleMesh.s_next_s(s);
  }
  s_prev_s(s) {
    return _TriangleMesh.s_prev_s(s);
  }
  s_opposite_s(s) {
    return this._halfedges[s];
  }
  s_around_t(t, s_out = []) {
    s_out.length = 3;
    for (let i = 0; i < 3; i++) {
      s_out[i] = 3 * t + i;
    }
    return s_out;
  }
  r_around_t(t, r_out = []) {
    r_out.length = 3;
    for (let i = 0; i < 3; i++) {
      r_out[i] = this._triangles[3 * t + i];
    }
    return r_out;
  }
  t_around_t(t, t_out = []) {
    t_out.length = 3;
    for (let i = 0; i < 3; i++) {
      t_out[i] = this.t_outer_s(3 * t + i);
    }
    return t_out;
  }
  s_around_r(r, s_out = []) {
    const s0 = this._s_of_r[r];
    let incoming = s0;
    s_out.length = 0;
    do {
      s_out.push(this._halfedges[incoming]);
      let outgoing = _TriangleMesh.s_next_s(incoming);
      incoming = this._halfedges[outgoing];
    } while (incoming !== -1 && incoming !== s0);
    return s_out;
  }
  r_around_r(r, r_out = []) {
    const s0 = this._s_of_r[r];
    let incoming = s0;
    r_out.length = 0;
    do {
      r_out.push(this.r_begin_s(incoming));
      let outgoing = _TriangleMesh.s_next_s(incoming);
      incoming = this._halfedges[outgoing];
    } while (incoming !== -1 && incoming !== s0);
    return r_out;
  }
  t_around_r(r, t_out = []) {
    const s0 = this._s_of_r[r];
    let incoming = s0;
    t_out.length = 0;
    do {
      t_out.push(_TriangleMesh.t_from_s(incoming));
      let outgoing = _TriangleMesh.s_next_s(incoming);
      incoming = this._halfedges[outgoing];
    } while (incoming !== -1 && incoming !== s0);
    return t_out;
  }
  r_ghost() {
    return this.numRegions - 1;
  }
  is_ghost_s(s) {
    return s >= this.numSolidSides;
  }
  is_ghost_r(r) {
    return r === this.numRegions - 1;
  }
  is_ghost_t(t) {
    return this.is_ghost_s(3 * t);
  }
  is_boundary_s(s) {
    return this.is_ghost_s(s) && s % 3 === 0;
  }
  is_boundary_r(r) {
    return r < this.numBoundaryRegions;
  }
};

// sphere.ts
var SPHERE_RADIUS = 300;
function uvToDirection(u4, v2) {
  const lon = (u4 - 0.5) * 2 * Math.PI, lat = (0.5 - v2) * Math.PI;
  return [Math.cos(lat) * Math.sin(lon), Math.sin(lat), Math.cos(lat) * Math.cos(lon)];
}
function directionToUV(p2) {
  const length = Math.hypot(p2[0], p2[1], p2[2]);
  return [0.5 + Math.atan2(p2[0], p2[2]) / (2 * Math.PI), 0.5 - Math.asin(Math.max(-1, Math.min(1, p2[1] / length))) / Math.PI];
}
function sampleSphere(data, size, u4, v2) {
  const x = (u4 % 1 + 1) % 1 * size;
  const y = Math.max(0, Math.min(size - 1, v2 * (size - 1)));
  const x0 = Math.floor(x), y0 = Math.floor(y), y1 = Math.min(size - 1, y0 + 1);
  const fx = x - x0, fy = y - y0;
  const row = (r) => {
    if (r === 0 || r === size - 1) return data[r * size];
    return data[r * size + x0] * (1 - fx) + data[r * size + (x0 + 1) % size] * fx;
  };
  return row(y0) * (1 - fy) + row(y1) * fy;
}
function atlasTriangles(points) {
  let p2 = points.map((v2) => v2.slice());
  const pole = p2.findIndex((v2) => v2[1] < 1e-5 || v2[1] > 1e3 - 1e-5);
  if (pole >= 0) p2[pole][0] = p2[(pole + 1) % 3][0];
  if (Math.max(...p2.map((v2) => v2[0])) - Math.min(...p2.map((v2) => v2[0])) > 500) {
    for (const v2 of p2) if (v2[0] < 500) v2[0] += 1e3;
  }
  let tris = [p2];
  if (pole >= 0) {
    const a = p2[(pole + 1) % 3], b = p2[(pole + 2) % 3];
    const pa = p2[pole].slice(), pb = p2[pole].slice();
    pa[0] = a[0];
    pb[0] = b[0];
    tris = [[pa, a, b], [pa, b, pb]];
  }
  const result = tris.slice();
  if (p2.some((v2) => v2[0] > 1e3)) {
    for (const tri of tris) result.push(tri.map((v2) => [v2[0] - 1e3, ...v2.slice(1)]));
  }
  return result;
}
function angularDistance(a, b) {
  const cross = Math.hypot(a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]);
  return Math.atan2(cross, a[0] * b[0] + a[1] * b[1] + a[2] * b[2]);
}

// sphere-mesh.ts
var SphereMesh = class extends TriangleMesh {
  is_ghost_r(_r) {
    return false;
  }
  is_ghost_s(_s) {
    return false;
  }
  is_ghost_t(_t) {
    return false;
  }
};
function makeSphereMesh(count, mountainSpacing, seed) {
  const random = (0, import_prng.makeRandFloat)(seed);
  const directions = [[0, -1, 0]];
  const goldenAngle = Math.PI * (3 - Math.sqrt(5));
  const angularSpacing = Math.sqrt(4 * Math.PI / count);
  for (let i = 0; i < count - 2; i++) {
    const y = -1 + 2 * (i + 1) / (count - 1);
    const angle = i * goldenAngle;
    const radius = Math.sqrt(1 - y * y);
    const east = 0.3 * angularSpacing * (random() - 0.5);
    const north = 0.3 * angularSpacing * (random() - 0.5);
    const p2 = [
      radius * Math.sin(angle) + east * Math.cos(angle) - north * y * Math.sin(angle),
      y + north * radius,
      radius * Math.cos(angle) - east * Math.sin(angle) - north * y * Math.cos(angle)
    ];
    const length = Math.hypot(...p2);
    directions.push(p2.map((v2) => v2 / length));
  }
  const stereo = directions.map(([x, y, z]) => [x / (1 - y), z / (1 - y)]);
  const triangulation = Delaunator.from(stereo);
  const init = TriangleMesh.addGhostStructure({ points: stereo, delaunator: {
    triangles: Int32Array.from(triangulation.triangles),
    halfedges: triangulation.halfedges
  } });
  directions.push([0, 1, 0]);
  init.points = directions.map((p2) => {
    const uv = directionToUV(p2);
    return [uv[0] * 1e3, uv[1] * 1e3];
  });
  init.numSolidSides = init.delaunator.triangles.length;
  const mesh2 = new SphereMesh(init);
  mesh2.numSolidRegions = mesh2.numRegions;
  mesh2.xyz_r = Float32Array.from(directions.flat());
  mesh2.xyz_t = new Float32Array(3 * mesh2.numTriangles);
  mesh2.is_boundary_t = new Int8Array(mesh2.numTriangles);
  mesh2.length_s = new Float32Array(mesh2.numSides);
  for (let t = 0; t < mesh2.numTriangles; t++) {
    const r = mesh2.r_around_t(t);
    const p2 = [0, 0, 0];
    for (const v2 of r) for (let k = 0; k < 3; k++) p2[k] += directions[v2][k];
    const length = Math.hypot(...p2);
    for (let k = 0; k < 3; k++) mesh2.xyz_t[3 * t + k] = p2[k] /= length;
    const uv = directionToUV(p2);
    mesh2._vertex_t[t] = [1e3 * uv[0], 1e3 * uv[1]];
  }
  for (let s = 0; s < mesh2.numSides; s++) {
    mesh2.length_s[s] = SPHERE_RADIUS * angularDistance(directions[mesh2.r_begin_s(s)], directions[mesh2.r_end_s(s)]);
  }
  const order = Array.from({ length: count }, (_, i) => i);
  for (let i = order.length - 1; i > 0; i--) {
    const j = Math.floor(random() * (i + 1));
    [order[i], order[j]] = [order[j], order[i]];
  }
  const peaks = [], limit = Math.cos(mountainSpacing / SPHERE_RADIUS);
  for (const r of order) {
    const a = directions[r];
    if (peaks.every((q) => {
      const b = directions[q];
      return a[0] * b[0] + a[1] * b[1] + a[2] * b[2] < limit;
    })) peaks.push(r);
  }
  const t_peaks2 = peaks.map((r) => mesh2.t_inner_s(mesh2._s_of_r[r]));
  return { mesh: mesh2, t_peaks: t_peaks2 };
}

// mesh.ts
async function makeMesh(settings = config_default) {
  const count = Math.round(0.72 * 4 * Math.PI * SPHERE_RADIUS * SPHERE_RADIUS / (settings.spacing * settings.spacing));
  return makeSphereMesh(count, settings.mountainSpacing, settings.mesh.seed);
}

// node_modules/.pnpm/simplex-noise@4.0.3/node_modules/simplex-noise/dist/esm/simplex-noise.js
var SQRT3 = /* @__PURE__ */ Math.sqrt(3);
var SQRT5 = /* @__PURE__ */ Math.sqrt(5);
var F2 = 0.5 * (SQRT3 - 1);
var G2 = (3 - SQRT3) / 6;
var F3 = 1 / 3;
var G3 = 1 / 6;
var F4 = (SQRT5 - 1) / 4;
var G4 = (5 - SQRT5) / 20;
var fastFloor = (x) => Math.floor(x) | 0;
var grad3 = /* @__PURE__ */ new Float64Array([
  1,
  1,
  0,
  -1,
  1,
  0,
  1,
  -1,
  0,
  -1,
  -1,
  0,
  1,
  0,
  1,
  -1,
  0,
  1,
  1,
  0,
  -1,
  -1,
  0,
  -1,
  0,
  1,
  1,
  0,
  -1,
  1,
  0,
  1,
  -1,
  0,
  -1,
  -1
]);
function createNoise3D(random = Math.random) {
  const perm = buildPermutationTable(random);
  const permGrad3x = new Float64Array(perm).map((v2) => grad3[v2 % 12 * 3]);
  const permGrad3y = new Float64Array(perm).map((v2) => grad3[v2 % 12 * 3 + 1]);
  const permGrad3z = new Float64Array(perm).map((v2) => grad3[v2 % 12 * 3 + 2]);
  return function noise3D(x, y, z) {
    let n0, n1, n2, n3;
    const s = (x + y + z) * F3;
    const i = fastFloor(x + s);
    const j = fastFloor(y + s);
    const k = fastFloor(z + s);
    const t = (i + j + k) * G3;
    const X0 = i - t;
    const Y0 = j - t;
    const Z0 = k - t;
    const x0 = x - X0;
    const y0 = y - Y0;
    const z0 = z - Z0;
    let i1, j1, k1;
    let i2, j2, k2;
    if (x0 >= y0) {
      if (y0 >= z0) {
        i1 = 1;
        j1 = 0;
        k1 = 0;
        i2 = 1;
        j2 = 1;
        k2 = 0;
      } else if (x0 >= z0) {
        i1 = 1;
        j1 = 0;
        k1 = 0;
        i2 = 1;
        j2 = 0;
        k2 = 1;
      } else {
        i1 = 0;
        j1 = 0;
        k1 = 1;
        i2 = 1;
        j2 = 0;
        k2 = 1;
      }
    } else {
      if (y0 < z0) {
        i1 = 0;
        j1 = 0;
        k1 = 1;
        i2 = 0;
        j2 = 1;
        k2 = 1;
      } else if (x0 < z0) {
        i1 = 0;
        j1 = 1;
        k1 = 0;
        i2 = 0;
        j2 = 1;
        k2 = 1;
      } else {
        i1 = 0;
        j1 = 1;
        k1 = 0;
        i2 = 1;
        j2 = 1;
        k2 = 0;
      }
    }
    const x1 = x0 - i1 + G3;
    const y1 = y0 - j1 + G3;
    const z1 = z0 - k1 + G3;
    const x2 = x0 - i2 + 2 * G3;
    const y2 = y0 - j2 + 2 * G3;
    const z2 = z0 - k2 + 2 * G3;
    const x3 = x0 - 1 + 3 * G3;
    const y3 = y0 - 1 + 3 * G3;
    const z3 = z0 - 1 + 3 * G3;
    const ii = i & 255;
    const jj = j & 255;
    const kk = k & 255;
    let t0 = 0.6 - x0 * x0 - y0 * y0 - z0 * z0;
    if (t0 < 0)
      n0 = 0;
    else {
      const gi0 = ii + perm[jj + perm[kk]];
      t0 *= t0;
      n0 = t0 * t0 * (permGrad3x[gi0] * x0 + permGrad3y[gi0] * y0 + permGrad3z[gi0] * z0);
    }
    let t1 = 0.6 - x1 * x1 - y1 * y1 - z1 * z1;
    if (t1 < 0)
      n1 = 0;
    else {
      const gi1 = ii + i1 + perm[jj + j1 + perm[kk + k1]];
      t1 *= t1;
      n1 = t1 * t1 * (permGrad3x[gi1] * x1 + permGrad3y[gi1] * y1 + permGrad3z[gi1] * z1);
    }
    let t2 = 0.6 - x2 * x2 - y2 * y2 - z2 * z2;
    if (t2 < 0)
      n2 = 0;
    else {
      const gi2 = ii + i2 + perm[jj + j2 + perm[kk + k2]];
      t2 *= t2;
      n2 = t2 * t2 * (permGrad3x[gi2] * x2 + permGrad3y[gi2] * y2 + permGrad3z[gi2] * z2);
    }
    let t3 = 0.6 - x3 * x3 - y3 * y3 - z3 * z3;
    if (t3 < 0)
      n3 = 0;
    else {
      const gi3 = ii + 1 + perm[jj + 1 + perm[kk + 1]];
      t3 *= t3;
      n3 = t3 * t3 * (permGrad3x[gi3] * x3 + permGrad3y[gi3] * y3 + permGrad3z[gi3] * z3);
    }
    return 32 * (n0 + n1 + n2 + n3);
  };
}
function buildPermutationTable(random) {
  const tableSize = 512;
  const p2 = new Uint8Array(tableSize);
  for (let i = 0; i < tableSize / 2; i++) {
    p2[i] = i;
  }
  for (let i = 0; i < tableSize / 2 - 1; i++) {
    const r = i + ~~(random() * (256 - i));
    const aux = p2[i];
    p2[i] = p2[r];
    p2[r] = aux;
  }
  for (let i = 256; i < tableSize; i++) {
    p2[i] = p2[i - 256];
  }
  return p2;
}

// node_modules/.pnpm/flatqueue@2.0.3/node_modules/flatqueue/index.js
var FlatQueue = class {
  constructor() {
    this.ids = [];
    this.values = [];
    this.length = 0;
  }
  clear() {
    this.length = 0;
  }
  push(id, value) {
    let pos = this.length++;
    while (pos > 0) {
      const parent = pos - 1 >> 1;
      const parentValue = this.values[parent];
      if (value >= parentValue) break;
      this.ids[pos] = this.ids[parent];
      this.values[pos] = parentValue;
      pos = parent;
    }
    this.ids[pos] = id;
    this.values[pos] = value;
  }
  pop() {
    if (this.length === 0) return void 0;
    const top = this.ids[0];
    this.length--;
    if (this.length > 0) {
      const id = this.ids[0] = this.ids[this.length];
      const value = this.values[0] = this.values[this.length];
      const halfLength = this.length >> 1;
      let pos = 0;
      while (pos < halfLength) {
        let left = (pos << 1) + 1;
        const right = left + 1;
        let bestIndex = this.ids[left];
        let bestValue = this.values[left];
        const rightValue = this.values[right];
        if (right < this.length && rightValue < bestValue) {
          left = right;
          bestIndex = this.ids[right];
          bestValue = rightValue;
        }
        if (bestValue >= value) break;
        this.ids[pos] = bestIndex;
        this.values[pos] = bestValue;
        pos = left;
      }
      this.ids[pos] = id;
      this.values[pos] = value;
    }
    return top;
  }
  peek() {
    if (this.length === 0) return void 0;
    return this.ids[0];
  }
  peekValue() {
    if (this.length === 0) return void 0;
    return this.values[0];
  }
  shrink() {
    this.ids.length = this.values.length = this.length;
  }
};

// map.ts
var import_prng2 = __toESM(require_prng(), 1);
var mountain = {
  slope: 16
};
function calculateMountainDistance(mesh2, t_peaks2, spacing, jaggedness, randFloat, distance_t) {
  distance_t.fill(-1);
  let t_queue = t_peaks2.concat([]);
  for (const t of t_peaks2) distance_t[t] = 0;
  for (let i = 0; i < t_queue.length; i++) {
    let t_current = t_queue[i];
    for (let j = 0; j < 3; j++) {
      let s = 3 * t_current + j;
      let t_neighbor = mesh2.t_outer_s(s);
      if (distance_t[t_neighbor] === -1) {
        let increment = spacing * (1 + jaggedness * (randFloat() - randFloat()));
        distance_t[t_neighbor] = distance_t[t_current] + increment;
        t_queue.push(t_neighbor);
      }
    }
  }
}
function precalculateNoise(randFloat, mesh2) {
  const noise3D = createNoise3D(randFloat);
  let { numTriangles } = mesh2;
  let noise0_t = new Float32Array(numTriangles), noise1_t = new Float32Array(numTriangles), noise2_t = new Float32Array(numTriangles), noise4_t = new Float32Array(numTriangles), noise5_t = new Float32Array(numTriangles), noise6_t = new Float32Array(numTriangles);
  for (let t = 0; t < numTriangles; t++) {
    const nx = 1.5 * mesh2.xyz_t[3 * t], ny = 1.5 * mesh2.xyz_t[3 * t + 1], nz = 1.5 * mesh2.xyz_t[3 * t + 2];
    noise0_t[t] = noise3D(nx, ny, nz);
    noise1_t[t] = noise3D(2 * nx + 5, 2 * ny + 5, 2 * nz + 5);
    noise2_t[t] = noise3D(4 * nx + 7, 4 * ny + 7, 4 * nz + 7);
    noise4_t[t] = noise3D(16 * nx + 15, 16 * ny + 15, 16 * nz + 15);
    noise5_t[t] = noise3D(32 * nx + 31, 32 * ny + 31, 32 * nz + 31);
    noise6_t[t] = noise3D(64 * nx + 67, 64 * ny + 67, 64 * nz + 67);
  }
  return { noise0_t, noise1_t, noise2_t, noise4_t, noise5_t, noise6_t };
}
var Map2 = class {
  constructor(mesh2, t_peaks2, param) {
    this.mesh = mesh2;
    this.t_peaks = t_peaks2;
    this.spacing = param.spacing;
    this.elevation_t = new Float32Array(mesh2.numTriangles);
    this.baseElevation_t = new Float32Array(mesh2.numTriangles);
    this.elevation_r = new Float32Array(mesh2.numRegions);
    this.humidity_r = new Float32Array(mesh2.numRegions);
    this.moisture_t = new Float32Array(mesh2.numTriangles);
    this.rainfall_r = new Float32Array(mesh2.numRegions);
    this.s_downslope_t = new Int32Array(mesh2.numTriangles);
    this.t_order = new Int32Array(mesh2.numTriangles);
    this.flow_t = new Float32Array(mesh2.numTriangles);
    this.flow_s = new Float32Array(mesh2.numSides);
    this.r_wind_order = new Int32Array(mesh2.numRegions);
    this.wind_sort_r = new Float32Array(mesh2.numRegions);
    this.mountain_distance_t = new Float32Array(mesh2.numTriangles);
  }
  mesh;
  t_peaks;
  seed = -1;
  spacing;
  precomputed;
  mountainJaggedness = -Infinity;
  windAngleDeg = Infinity;
  elevation_t;
  baseElevation_t;
  elevation_r;
  humidity_r;
  moisture_t;
  rainfall_r;
  s_downslope_t;
  t_order;
  flow_t;
  flow_s;
  r_wind_order;
  wind_sort_r;
  mountain_distance_t;
  assignTriangleElevation(elevationParam, constraints) {
    let { mesh: mesh2, elevation_t, mountain_distance_t, precomputed } = this;
    let { numTriangles, numSolidTriangles } = mesh2;
    function constraintAt(x, y) {
      return sampleSphere(constraints.constraints, constraints.size, x, y);
    }
    for (let t = 0; t < numSolidTriangles; t++) {
      let e2 = constraintAt(mesh2.x_of_t(t) / 1e3, mesh2.y_of_t(t) / 1e3);
      elevation_t[t] = e2 + elevationParam.noisy_coastlines * (1 - e2 * e2 * e2 * e2) * (precomputed.noise4_t[t] + precomputed.noise5_t[t] / 2 + precomputed.noise6_t[t] / 4);
    }
    const mountain_slope = mountain.slope, mountain_sharpness = Math.pow(2, elevationParam.mountain_sharpness), { noise0_t, noise1_t, noise2_t, noise4_t } = precomputed;
    for (let t = 0; t < numTriangles; t++) {
      let e2 = elevation_t[t];
      if (e2 > 0) {
        let noisiness = 1 - 0.5 * (1 + noise0_t[t]);
        let eh = (1 + noisiness * noise4_t[t] + (1 - noisiness) * noise2_t[t]) * elevationParam.hill_height;
        if (eh < 0.01) {
          eh = 0.01;
        }
        let em = 1 - mountain_slope / mountain_sharpness * mountain_distance_t[t];
        if (em < 0.01) {
          em = 0.01;
        }
        let weight = e2 * e2;
        e2 = (1 - weight) * eh + weight * em;
      } else {
        e2 *= elevationParam.ocean_depth + noise1_t[t];
      }
      if (e2 < -1) {
        e2 = -1;
      }
      if (e2 > 1) {
        e2 = 1;
      }
      elevation_t[t] = e2;
    }
  }
  assignRegionElevation() {
    let { mesh: mesh2, elevation_t, elevation_r } = this;
    let { numRegions, _s_of_r, _halfedges } = mesh2;
    for (let r = 0; r < numRegions; r++) {
      let count = 0, e2 = 0, water = false;
      const s0 = _s_of_r[r];
      let s_incoming = s0;
      do {
        let t = s_incoming / 3 | 0;
        e2 += elevation_t[t];
        water = water || elevation_t[t] < 0;
        let s_outgoing = mesh2.s_next_s(s_incoming);
        s_incoming = _halfedges[s_outgoing];
        count++;
      } while (s_incoming !== s0);
      e2 /= count;
      if (water && e2 >= 0) {
        e2 = -1e-3;
      }
      elevation_r[r] = e2;
    }
  }
  assignElevation(elevationParam, constraints, offsets = null) {
    if (this.seed !== elevationParam.seed || this.mountainJaggedness !== elevationParam.mountain_jagged) {
      this.mountainJaggedness = elevationParam.mountain_jagged;
      calculateMountainDistance(
        this.mesh,
        this.t_peaks,
        this.spacing,
        this.mountainJaggedness,
        (0, import_prng2.makeRandFloat)(elevationParam.seed),
        this.mountain_distance_t
      );
    }
    if (this.seed !== elevationParam.seed) {
      this.seed = elevationParam.seed;
      this.precomputed = precalculateNoise((0, import_prng2.makeRandFloat)(elevationParam.seed), this.mesh);
    }
    this.assignTriangleElevation(elevationParam, constraints);
    this.baseElevation_t.set(this.elevation_t);
    if (offsets) {
      if (offsets.length !== this.elevation_t.length) throw new RangeError("Terrain layer size mismatch");
      for (let t = 0; t < offsets.length; t++) this.elevation_t[t] = Math.max(-1, Math.min(1, this.elevation_t[t] + offsets[t]));
    }
    this.assignRegionElevation();
  }
  assignRainfall(biomesParam) {
    const { mesh: mesh2, r_wind_order, wind_sort_r, humidity_r, rainfall_r, elevation_r } = this;
    const { numRegions, _s_of_r, _halfedges } = mesh2;
    if (biomesParam.wind_angle_deg != this.windAngleDeg) {
      this.windAngleDeg = biomesParam.wind_angle_deg;
      const windAngleRad = Math.PI / 180 * this.windAngleDeg;
      const windAngleVec = [Math.cos(windAngleRad), Math.sin(windAngleRad)];
      for (let r = 0; r < numRegions; r++) {
        r_wind_order[r] = r;
        wind_sort_r[r] = mesh2.xyz_r[3 * r] * windAngleVec[0] + mesh2.xyz_r[3 * r + 2] * windAngleVec[1];
      }
      r_wind_order.sort((r1, r2) => wind_sort_r[r1] - wind_sort_r[r2]);
    }
    for (let r of r_wind_order) {
      let count = 0, sum3 = 0;
      let s0 = _s_of_r[r], s_incoming = s0;
      do {
        let r_neighbor = mesh2.r_begin_s(s_incoming);
        if (wind_sort_r[r_neighbor] < wind_sort_r[r]) {
          count++;
          sum3 += humidity_r[r_neighbor];
        }
        let s_outgoing = mesh2.s_next_s(s_incoming);
        s_incoming = _halfedges[s_outgoing];
      } while (s_incoming !== s0);
      let humidity = 0, rainfall = 0;
      if (count > 0) {
        humidity = sum3 / count;
        rainfall += biomesParam.raininess * humidity;
      }
      if (mesh2.is_boundary_r(r)) {
        humidity = 1;
      }
      if (elevation_r[r] < 0) {
        let evaporation = biomesParam.evaporation * -elevation_r[r];
        humidity += evaporation;
      }
      if (humidity > 1 - elevation_r[r]) {
        let orographicRainfall = biomesParam.rain_shadow * (humidity - (1 - elevation_r[r]));
        rainfall += biomesParam.raininess * orographicRainfall;
        humidity -= orographicRainfall;
      }
      rainfall_r[r] = rainfall;
      humidity_r[r] = humidity;
    }
  }
  assignRivers(riversParam, preserveElevation = false) {
    let { mesh: mesh2, moisture_t, rainfall_r, elevation_t, s_downslope_t, t_order, flow_t, flow_s } = this;
    const original = preserveElevation ? elevation_t.slice() : null;
    assignDownslope(mesh2, elevation_t, s_downslope_t, t_order);
    assignMoisture(mesh2, rainfall_r, moisture_t);
    assignFlow(mesh2, riversParam, t_order, elevation_t, moisture_t, s_downslope_t, flow_t, flow_s);
    if (original) elevation_t.set(original);
  }
};
var queue = new FlatQueue();
function assignDownslope(mesh2, elevation_t, s_downslope_t, t_order) {
  let { numTriangles } = mesh2, queue_in = 0;
  queue.clear();
  s_downslope_t.fill(-999);
  for (let t = 0; t < numTriangles; t++) {
    if (elevation_t[t] < -0.1) {
      let s_best = -1, e_best = elevation_t[t];
      for (let j = 0; j < 3; j++) {
        let s = 3 * t + j, e2 = elevation_t[mesh2.t_outer_s(s)];
        if (e2 < e_best) {
          e_best = e2;
          s_best = s;
        }
      }
      t_order[queue_in++] = t;
      s_downslope_t[t] = s_best;
      queue.push(t, elevation_t[t]);
    }
  }
  if (queue_in === 0) {
    let sink = 0;
    for (let t = 1; t < numTriangles; t++) if (elevation_t[t] < elevation_t[sink]) sink = t;
    t_order[queue_in++] = sink;
    s_downslope_t[sink] = -1;
    queue.push(sink, elevation_t[sink]);
  }
  for (let queue_out = 0; queue_out < numTriangles; queue_out++) {
    let t_current = queue.pop();
    for (let j = 0; j < 3; j++) {
      let s = 3 * t_current + j;
      let t_neighbor = mesh2.t_outer_s(s);
      if (s_downslope_t[t_neighbor] === -999) {
        s_downslope_t[t_neighbor] = mesh2.s_opposite_s(s);
        t_order[queue_in++] = t_neighbor;
        queue.push(t_neighbor, elevation_t[t_neighbor]);
      }
    }
  }
}
function assignMoisture(mesh2, rainfall_r, moisture_t) {
  const { numTriangles } = mesh2;
  for (let t = 0; t < numTriangles; t++) {
    let moisture = 0;
    for (let i = 0; i < 3; i++) {
      let s = 3 * t + i, r = mesh2.r_begin_s(s);
      moisture += rainfall_r[r] / 3;
    }
    moisture_t[t] = moisture;
  }
}
function assignFlow(mesh2, riversParam, t_order, elevation_t, moisture_t, s_downslope_t, flow_t, flow_s) {
  let { numTriangles, _halfedges } = mesh2;
  flow_s.fill(0);
  for (let t = 0; t < numTriangles; t++) {
    if (elevation_t[t] >= 0) {
      flow_t[t] = riversParam.flow * moisture_t[t] * moisture_t[t];
    } else {
      flow_t[t] = 0;
    }
  }
  for (let i = t_order.length - 1; i >= 0; i--) {
    let t_tributary = t_order[i];
    let s_flow = s_downslope_t[t_tributary];
    if (s_flow >= 0) {
      let t_trunk = _halfedges[s_flow] / 3 | 0;
      flow_t[t_trunk] += flow_t[t_tributary];
      flow_s[s_flow] += flow_t[t_tributary];
      if (elevation_t[t_trunk] > elevation_t[t_tributary] && elevation_t[t_tributary] >= 0) {
        elevation_t[t_trunk] = elevation_t[t_tributary];
      }
    }
  }
}

// geometry.ts
function setMeshGeometry(mesh2, P) {
  let { numRegions, numTriangles } = mesh2;
  if (P.length !== 2 * (numRegions + numTriangles)) {
    throw "wrong size";
  }
  let p2 = 0;
  for (let r = 0; r < numRegions; r++) {
    P[p2++] = mesh2.is_ghost_r(r) ? 0 : mesh2.x_of_r(r);
    P[p2++] = mesh2.is_ghost_r(r) ? 0 : mesh2.y_of_r(r);
  }
  for (let t = 0; t < numTriangles; t++) {
    P[p2++] = mesh2.x_of_t(t);
    P[p2++] = mesh2.y_of_t(t);
  }
}
function setMapGeometry(map2, mountain_folds, I, P) {
  let { mesh: mesh2, flow_s, elevation_r, elevation_t, rainfall_r } = map2;
  let { numSolidSides, numRegions, numTriangles, is_boundary_t } = mesh2;
  if (I.length !== 3 * numSolidSides) {
    throw "wrong size";
  }
  if (P.length !== 2 * (numRegions + numTriangles)) {
    throw "wrong size";
  }
  let p2 = 0;
  for (let r = 0; r < numRegions; r++) {
    P[p2++] = elevation_r[r];
    P[p2++] = rainfall_r[r];
  }
  for (let t = 0; t < numTriangles; t++) {
    P[p2++] = (1 - mountain_folds * Math.sqrt(Math.max(0, elevation_t[t]))) * elevation_t[t];
    let s0 = 3 * t;
    let r1 = mesh2.r_begin_s(s0), r2 = mesh2.r_begin_s(s0 + 1), r3 = mesh2.r_begin_s(s0 + 2);
    P[p2++] = 1 / 3 * (rainfall_r[r1] + rainfall_r[r2] + rainfall_r[r3]);
  }
  let i = 0;
  for (let s = 0; s < numSolidSides; s++) {
    let s_opposite = mesh2.s_opposite_s(s), r1 = mesh2.r_begin_s(s), r2 = mesh2.r_begin_s(s_opposite), t1 = mesh2.t_inner_s(s), t2 = mesh2.t_inner_s(s_opposite);
    let is_valley = false;
    if (elevation_r[r1] < 0 || elevation_r[r2] < 0) is_valley = true;
    if (flow_s[s] > 0 || flow_s[s_opposite] > 0) is_valley = true;
    if (is_boundary_t[t1] || is_boundary_t[t2]) is_valley = false;
    if (is_valley) {
      I[i++] = r1;
      I[i++] = numRegions + t2;
      I[i++] = numRegions + t1;
    } else {
      I[i++] = r1;
      I[i++] = r2;
      I[i++] = numRegions + t1;
    }
  }
  if (I.length !== i) {
    throw "wrong size";
  }
  if (P.length !== p2) {
    throw "wrong size";
  }
}
var riverAtlasCache = /* @__PURE__ */ new WeakMap();
function setRiverGeometry(map2, spacing, riversParam, P) {
  const MIN_FLOW = Math.exp(riversParam.lg_min_flow);
  const RIVER_WIDTH = Math.exp(riversParam.lg_river_width);
  let { mesh: mesh2, s_downslope_t, flow_s } = map2;
  let { numSolidTriangles, length_s } = mesh2;
  let atlas = riverAtlasCache.get(mesh2);
  if (!atlas) {
    atlas = [];
    riverAtlasCache.set(mesh2, atlas);
  }
  function add(s1, s2, s3, width1, width2) {
    let primitive = atlas[s1];
    if (!primitive) {
      const vertices = [s1, s2, s3].map((s, i) => {
        const r = mesh2.r_begin_s(s);
        return [mesh2.x_of_r(r), mesh2.y_of_r(r), 0, 0, +(i === 0), +(i === 1), +(i === 2)];
      });
      primitive = new Float32Array(atlasTriangles(vertices).flat(2));
      atlas[s1] = primitive;
    }
    if (p2 + primitive.length > P.length) throw new Error("River atlas buffer overflow");
    P.set(primitive, p2);
    for (let j = 0; j < primitive.length; j += 7) {
      P[p2 + j + 2] = width1;
      P[p2 + j + 3] = width2;
    }
    p2 += primitive.length;
  }
  function riverSize(s, flow) {
    if (s < 0) {
      return 1;
    }
    let width = Math.sqrt(flow - MIN_FLOW) * spacing * RIVER_WIDTH;
    return Math.min(riversParam.max_width ?? Infinity, width / length_s[s]);
  }
  let p2 = 0;
  for (let t = 0; t < numSolidTriangles; t++) {
    let s_out = s_downslope_t[t];
    let outflow = flow_s[s_out];
    if (s_out < 0 || outflow <= MIN_FLOW) continue;
    let s_in1 = mesh2.s_next_s(s_out);
    let s_in2 = mesh2.s_next_s(s_in1);
    let flow_in1 = flow_s[mesh2.s_opposite_s(s_in1)];
    let flow_in2 = flow_s[mesh2.s_opposite_s(s_in2)];
    if (flow_in1 > MIN_FLOW) {
      add(s_out, s_in1, s_in2, riverSize(s_out, outflow), riverSize(s_in1, flow_in1));
    }
    if (flow_in2 > MIN_FLOW) {
      add(s_in2, s_out, s_in1, riverSize(s_in2, flow_in2), riverSize(s_out, outflow));
    }
    if (riversParam.headwaters && flow_in1 <= MIN_FLOW && flow_in2 <= MIN_FLOW) add(s_out, s_in1, s_in2, riverSize(s_out, outflow), 0);
  }
  if (p2 > P.length) throw new Error("River atlas buffer overflow");
  return p2 / 21;
}
var geometry_default = { setMeshGeometry, setMapGeometry, setRiverGeometry };

// sphere-view.ts
var MIN_ZOOM = 0.05;
var MAX_ZOOM = 2;

// terrain-parameters.ts
var initialParams = {
  elevation: [
    ["seed", 187, 1, 1 << 30],
    ["island", 0.5, 0, 1],
    ["noisy_coastlines", 0.01, 0, 0.1],
    ["hill_height", 0.02, 0, 0.1],
    ["mountain_jagged", 0, 0, 1],
    ["mountain_sharpness", 9.8, 9.1, 12.5],
    ["mountain_folds", 0.05, 0, 0.5],
    ["ocean_depth", 1.4, 1, 3]
  ],
  biomes: [
    ["wind_angle_deg", 0, 0, 360],
    ["raininess", 0.9, 0, 2],
    ["rain_shadow", 0.5, 0.1, 2],
    ["evaporation", 0.5, 0, 1]
  ],
  rivers: [
    ["lg_min_flow", 2.7, -5, 5],
    ["lg_river_width", -2.4, -5, 5],
    ["flow", 0.2, 0, 1]
  ],
  render: [
    ["sphere_radius", SPHERE_RADIUS, 100, 1e3],
    ["zoom", 100 / 350, MIN_ZOOM, MAX_ZOOM],
    ["x", 500, 0, 1e3],
    ["y", 500, 0, 1e3],
    ["light_angle_deg", 80, 0, 360],
    ["slope", 2, 0, 5],
    ["flat", 2.5, 0, 5],
    ["ambient", 0.25, 0, 1],
    ["overhead", 30, 0, 60],
    ["tilt_deg", 0, 0, 90],
    ["rotate_deg", 0, -180, 180],
    ["mountain_height", 50, 0, 250],
    ["outline_depth", 1, 0, 2],
    ["outline_strength", 15, 0, 30],
    ["outline_threshold", 0, 0, 100],
    ["outline_coast", 0, 0, 1],
    ["outline_water", 13, 0, 20],
    // things start going wrong when this is high
    ["biome_colors", 1, 0, 1],
    ["fused_rivers", 1, 0, 1],
    ["fused_river_min_flow", 1e3, 0, 2e4],
    ["fused_river_width", 0.025, 1e-3, 0.2],
    ["fused_river_max_width", 0.35, 0.01, 0.85]
  ]
};

// planet.ts
var G = 66743e-15;
var TAU = 2 * Math.PI;
var DEFAULT_PLANET = Object.freeze({
  schemaVersion: 1,
  radiusM: 63710084e-1,
  densityKgM3: 5513.4,
  reliefM: 1e4,
  oceanDepthM: 11e3,
  siderealPeriodS: 86164.09054,
  retrograde: false,
  obliquityRad: 23.43928 * Math.PI / 180
});
function finiteInRange(value, name, min, max = Number.MAX_VALUE) {
  if (!Number.isFinite(value) || value < min || value > max) throw new RangeError(`${name} is outside its supported range`);
}
function derivePlanet(config) {
  if (config.schemaVersion !== 1) throw new RangeError("Unsupported planet configuration");
  for (const key of ["radiusM", "densityKgM3", "reliefM", "oceanDepthM", "siderealPeriodS"]) {
    finiteInRange(config[key], key, Number.MIN_VALUE);
  }
  finiteInRange(config.obliquityRad, "obliquity", 0, Math.PI / 2);
  const volumeM3 = 4 * Math.PI / 3 * config.radiusM ** 3;
  const massKg = volumeM3 * config.densityKgM3, muM3s2 = G * massKg;
  const surfaceAreaM2 = 4 * Math.PI * config.radiusM ** 2;
  const gravityMps2 = muM3s2 / config.radiusM ** 2;
  const escapeMps = Math.sqrt(2 * muM3s2 / config.radiusM);
  const angularSpeedRadS = TAU / config.siderealPeriodS;
  const rotationRatio = angularSpeedRadS ** 2 * config.radiusM / gravityMps2;
  for (const v2 of [volumeM3, massKg, muM3s2, surfaceAreaM2, gravityMps2, escapeMps, rotationRatio]) {
    if (!Number.isFinite(v2)) throw new RangeError("Planet diagnostics overflow");
  }
  return { massKg, muM3s2, surfaceAreaM2, gravityMps2, escapeMps, rotationRatio };
}

// astronomy.ts
var AU_M = 149597870700;
var SOLAR_GM = 13271244004127942e4;
var SOLAR_LUMINOSITY_W = 3828e23;
var STEFAN_BOLTZMANN = 5670374419e-17;
var DEFAULT_ORBIT = Object.freeze({
  distanceM: AU_M,
  bondAlbedo: 0.3,
  spinPhaseRad: 0,
  orbitPhaseRad: 0
});
function deriveOrbit(planet, orbit) {
  const p2 = derivePlanet(planet);
  finiteInRange(orbit.distanceM, "orbital distance", Number.MIN_VALUE);
  finiteInRange(orbit.bondAlbedo, "Bond albedo", 0, 1);
  if (!Number.isFinite(orbit.spinPhaseRad) || !Number.isFinite(orbit.orbitPhaseRad)) throw new RangeError("Invalid phase");
  const yearS = TAU * Math.sqrt(orbit.distanceM ** 3 / (SOLAR_GM + p2.muM3s2));
  const fluxWm2 = SOLAR_LUMINOSITY_W / (4 * Math.PI * orbit.distanceM ** 2);
  const equilibriumK = Math.pow((1 - orbit.bondAlbedo) * fluxWm2 / (4 * STEFAN_BOLTZMANN), 0.25);
  const spinRate = (planet.retrograde ? -1 : 1) / planet.siderealPeriodS, orbitRate = 1 / yearS;
  const relativeRate = Math.abs(spinRate - orbitRate);
  const solarDayS = relativeRate <= 1e-12 * Math.max(Math.abs(spinRate), orbitRate) ? Infinity : 1 / relativeRate;
  if (!Number.isFinite(yearS) || yearS <= 0 || !Number.isFinite(fluxWm2) || !Number.isFinite(equilibriumK)) throw new RangeError("Orbit diagnostics overflow");
  return { yearS, fluxWm2, equilibriumK, solarDayS };
}
function wrapAngle(angle) {
  return (angle % TAU + TAU) % TAU;
}
function sunState(planet, orbit, timeS) {
  finiteInRange(timeS, "simulation time", 0);
  const { yearS, fluxWm2 } = deriveOrbit(planet, orbit);
  const spinAngleRad = wrapAngle(orbit.spinPhaseRad + (planet.retrograde ? -1 : 1) * TAU * (timeS % planet.siderealPeriodS / planet.siderealPeriodS));
  const orbitAngleRad = wrapAngle(orbit.orbitPhaseRad + TAU * (timeS % yearS / yearS));
  const x = Math.cos(planet.obliquityRad) * Math.sin(orbitAngleRad);
  const y = Math.sin(planet.obliquityRad) * Math.sin(orbitAngleRad);
  const z = Math.cos(orbitAngleRad), c = Math.cos(spinAngleRad), s = Math.sin(spinAngleRad);
  const direction = [c * x - s * z, y, s * x + c * z];
  return { direction, spinAngleRad, orbitAngleRad, declinationRad: Math.asin(Math.max(-1, Math.min(1, y))), fluxWm2 };
}

// terrain-document.ts
var MAX_TERRAIN_FILE_BYTES = 8 * 1024 * 1024;
function meshIdentity(mesh2, param) {
  let a = 2166136261, b = 5381;
  for (const field2 of [mesh2.xyz_r, mesh2.xyz_t, mesh2._triangles, mesh2._halfedges]) {
    const bytes = new Uint8Array(field2.buffer, field2.byteOffset, field2.byteLength);
    for (const byte of bytes) {
      a = Math.imul(a ^ byte, 16777619);
      b = Math.imul(b, 33) ^ byte;
    }
  }
  return { regions: mesh2.numRegions, triangles: mesh2.numTriangles, spacing: param.spacing, mountainSpacing: param.mountainSpacing, seed: param.mesh.seed, fingerprint: `${a >>> 0}-${b >>> 0}` };
}
function object(value) {
  if (!value || typeof value !== "object" || Array.isArray(value)) throw new Error("Expected a document object");
  return value;
}
function number(value, name, min, max, integer = false) {
  if (typeof value !== "number" || !Number.isFinite(value) || value < min || value > max || integer && !Number.isInteger(value)) throw new Error(`Invalid ${name}`);
  return value;
}
function bool(value) {
  if (typeof value !== "boolean") throw new Error("Expected boolean");
  return value;
}
function array(value, name, length, min, max) {
  if (!Array.isArray(value) || value.length !== length) throw new Error(`Invalid ${name} length`);
  return value.map((x) => number(x, name, min, max));
}
function decodeTerrainDocument(text2, expected, constraintSize) {
  if (text2.length > MAX_TERRAIN_FILE_BYTES || new TextEncoder().encode(text2).length > MAX_TERRAIN_FILE_BYTES) throw new Error("Terrain file exceeds 8 MiB");
  const d2 = object(JSON.parse(text2));
  if (d2.format !== "mapgen4-sphere-terrain" || d2.version !== 1) throw new Error("Unsupported terrain document");
  const mesh2 = object(d2.mesh);
  for (const key of Object.keys(expected)) if (mesh2[key] !== expected[key]) throw new Error("Terrain file uses a different mesh");
  const c = object(d2.constraints);
  if (c.size !== constraintSize) throw new Error("Unsupported painting resolution");
  const constraints = { size: constraintSize, painted: bool(c.painted), values: array(c.values, "painting", constraintSize ** 2, -1, 1) };
  const offsets = d2.offsets === null ? null : array(d2.offsets, "offsets", expected.triangles, -2, 2);
  let report = null;
  if (d2.report !== null) {
    const r = object(d2.report);
    report = {
      years: number(r.years, "geological years", 0, 1e15),
      sourceTimeS: number(r.sourceTimeS, "source time", 0, Number.MAX_SAFE_INTEGER),
      clipped: number(r.clipped, "clipped triangles", 0, expected.triangles, true),
      mobileKm3: number(r.mobileKm3, "mobile sediment", 0, 1e30),
      oceanKm3: number(r.oceanKm3, "ocean sediment", 0, 1e30)
    };
    if (r.importedFrom !== void 0) {
      if (typeof r.importedFrom !== "string" || !r.importedFrom.trim() || r.importedFrom.length > 200) throw new Error("Invalid elevation source");
      report.importedFrom = r.importedFrom;
    }
  }
  if (offsets === null !== (report === null)) throw new Error("Application layer and report must be paired");
  const parameters = {}, p2 = object(d2.parameters);
  for (const [phase2, fields] of Object.entries(initialParams)) {
    const source2 = object(p2[phase2]);
    parameters[phase2] = {};
    const legacy = { fused_rivers: 1, fused_river_min_flow: 300, fused_river_width: 0.07, fused_river_max_width: 0.85 };
    for (const [key, , min, max] of fields) parameters[phase2][key] = number(source2[key] === void 0 ? legacy[key] : source2[key], key, min, max, key === "seed" || key === "fused_rivers");
  }
  let drainage;
  if (d2.drainage !== void 0) {
    const b = object(d2.drainage);
    if (typeof b.source !== "string" || !b.source.trim() || b.source.length > 300) throw new Error("Invalid drainage source");
    const basinId = array(b.basinId, "drainage basin", expected.triangles, 0, 2147483647), terminal = array(b.terminal, "drainage terminal", expected.triangles, 0, 1);
    if (basinId.some((v2, i) => !Number.isInteger(v2) || !Number.isInteger(terminal[i]) || terminal[i] > 0 && v2 === 0)) throw new Error("Invalid drainage labels");
    drainage = { source: b.source, basinId, terminal };
    if (b.inlandLakeId !== void 0) {
      const lake = array(b.inlandLakeId, "inland lake", expected.triangles, 0, 2147483647);
      if (lake.some((v2) => !Number.isInteger(v2))) throw new Error("Invalid inland lake labels");
      drainage.inlandLakeId = lake;
    }
  }
  const s = object(d2.settings), planet = object(s.planet), orbit = object(s.orbit);
  if (planet.schemaVersion !== 1) throw new Error("Unsupported physical settings");
  const physical = {
    schemaVersion: 1,
    radiusM: number(planet.radiusM, "radius", 1e4, 1e8),
    densityKgM3: number(planet.densityKgM3, "density", 100, 3e4),
    reliefM: number(planet.reliefM, "relief", 1, 1e5),
    oceanDepthM: number(planet.oceanDepthM, "ocean depth", 1, 1e5),
    siderealPeriodS: number(planet.siderealPeriodS, "sidereal period", 1800, 36e8),
    retrograde: bool(planet.retrograde),
    obliquityRad: number(planet.obliquityRad, "obliquity", 0, Math.PI / 2)
  };
  const orbital = {
    distanceM: number(orbit.distanceM, "orbit distance", 0.1 * AU_M, 20 * AU_M),
    bondAlbedo: number(orbit.bondAlbedo, "albedo", 0, 1),
    spinPhaseRad: number(orbit.spinPhaseRad, "spin phase", 0, TAU),
    orbitPhaseRad: number(orbit.orbitPhaseRad, "orbit phase", 0, TAU)
  };
  if (s.camera !== "space" && s.camera !== "surface") throw new Error("Invalid camera");
  return {
    format: "mapgen4-sphere-terrain",
    version: 1,
    mesh: { ...expected },
    constraints,
    offsets,
    report,
    parameters,
    ...drainage ? { drainage } : {},
    settings: { planet: physical, orbit: orbital, timeS: number(s.timeS, "time", 0, Number.MAX_SAFE_INTEGER), camera: s.camera }
  };
}

// circulation-scheme.ts
var schemes = ["signed-pressure", "full-drag", "thermal-pressure", "balanced-pressure", "boundary-pressure"];
function isCirculationScheme(value) {
  return typeof value === "string" && schemes.includes(value);
}
function fullWindDrag(scheme) {
  return scheme !== void 0 && scheme !== "signed-pressure";
}
function circulationOffsetFactor(scheme, modern) {
  return fullWindDrag(scheme) ? 2.5 : modern ? 1.5 : 0.5;
}

// thermal.ts
var DEFAULT_THERMAL = Object.freeze({
  emissivity: 0.61,
  landHeatCapacity: 2e6,
  oceanDepthM: 10,
  diffusion: 0.55
});
function makeThermalGrid(width = 48, height = 24) {
  if (!Number.isInteger(width) || !Number.isInteger(height) || width < 4 || height < 2 || width * height > 16384) throw new RangeError("Invalid thermal grid");
  const count = width * height, dx = 2 / height, dl = 2 * Math.PI / width;
  const sinLat = Float64Array.from({ length: height }, (_, j) => 1 - (j + 0.5) * dx);
  const edges = [];
  for (let j = 0; j < height; j++) for (let i = 0; i < width; i++) {
    const a = j * width + i;
    edges.push({ a, b: j * width + (i + 1) % width, geometry: dx / ((1 - sinLat[j] ** 2) * dl) });
    if (j + 1 < height) edges.push({ a, b: a + width, geometry: (1 - (1 - (j + 1) * dx) ** 2) * dl / dx });
  }
  return { width, height, count, solidAngle: dx * dl, sinLat, edges };
}
function thermalCell(grid, u4, v2) {
  const i = Math.floor((u4 % 1 + 1) % 1 * grid.width);
  const j = Math.max(0, Math.min(grid.height - 1, Math.floor((1 - Math.cos(v2 * Math.PI)) / 2 * grid.height)));
  return j * grid.width + i;
}
function sampleTerrainGrid(grid, directions, elevation2) {
  const n2 = directions.length / 3;
  if (n2 < 1 || !Number.isInteger(n2) || elevation2.length < n2) throw new RangeError("Missing terrain snapshot");
  const count = new Uint32Array(grid.count), land = new Float64Array(grid.count), height = new Float64Array(grid.count);
  for (let r = 0; r < n2; r++) {
    const u4 = 0.5 + Math.atan2(directions[3 * r], directions[3 * r + 2]) / (2 * Math.PI);
    const j = Math.max(0, Math.min(grid.height - 1, Math.floor((1 - directions[3 * r + 1]) / 2 * grid.height)));
    const k = j * grid.width + Math.floor((u4 % 1 + 1) % 1 * grid.width);
    count[k]++;
    land[k] += elevation2[r] > 0 ? 1 : 0;
    height[k] += Math.max(0, Math.min(1, elevation2[r]));
  }
  for (let k = 0; k < grid.count; k++) {
    if (count[k]) {
      height[k] = land[k] > 0 ? height[k] / land[k] : 0;
      land[k] /= count[k];
      continue;
    }
    const y = grid.sinLat[Math.floor(k / grid.width)], lon = ((k % grid.width + 0.5) / grid.width - 0.5) * 2 * Math.PI;
    const x = Math.sqrt(1 - y * y) * Math.sin(lon), z = Math.sqrt(1 - y * y) * Math.cos(lon);
    let best = -Infinity, nearest = 0;
    for (let r = 0; r < n2; r++) {
      const dot = x * directions[3 * r] + y * directions[3 * r + 1] + z * directions[3 * r + 2];
      if (dot > best) {
        best = dot;
        nearest = r;
      }
    }
    land[k] = elevation2[nearest] > 0 ? 1 : 0;
    height[k] = Math.max(0, Math.min(1, elevation2[nearest]));
  }
  return { landFraction: land, landElevation: height };
}
function dailyMeanInsolation(sinLat, declination, flux) {
  const a = sinLat * Math.sin(declination), b = Math.sqrt(Math.max(0, 1 - sinLat * sinLat)) * Math.cos(declination);
  if (b < 1e-14) return flux * Math.max(0, a);
  const h = Math.acos(Math.max(-1, Math.min(1, -a / b)));
  return flux * Math.max(0, (h * a + b * Math.sin(h)) / Math.PI);
}
function heatTransport(grid, temperature, diffusion, out2 = new Float64Array(grid.count)) {
  out2.fill(0);
  for (const e2 of grid.edges) {
    const q = diffusion * e2.geometry * (temperature[e2.b] - temperature[e2.a]) / grid.solidAngle;
    out2[e2.a] += q;
    out2[e2.b] -= q;
  }
  return out2;
}
var ThermalModel = class {
  constructor(planet, orbit, config, land, epochS = 0, grid = makeThermalGrid(), reference2, initialEnergyJm2) {
    this.epochS = epochS;
    this.grid = grid;
    const derived = deriveOrbit(planet, orbit);
    finiteInRange(epochS, "thermal epoch", 0);
    finiteInRange(config.emissivity, "effective emissivity", 0.1, 1);
    finiteInRange(config.landHeatCapacity, "land heat capacity", 1e5, 1e8);
    finiteInRange(config.oceanDepthM, "ocean mixed-layer depth", 0.1, 100);
    finiteInRange(config.diffusion, "heat transport coefficient", 0, 5);
    if (config.separateReservoirs !== void 0 && typeof config.separateReservoirs !== "boolean") throw new RangeError("Invalid separate reservoir switch");
    if (config.airRadiationFraction !== void 0) finiteInRange(config.airRadiationFraction, "air radiative fraction", 0, 1);
    if (land.length !== grid.count) throw new RangeError("Thermal land grid mismatch");
    this.planet = { ...planet };
    this.orbit = { ...orbit };
    this.config = { ...config };
    this.yearS = derived.yearS;
    this.fluxWm2 = derived.fluxWm2;
    this.transport = config.diffusion * (DEFAULT_PLANET.radiusM / planet.radiusM) ** 2;
    const initial2 = derived.equilibriumK / Math.pow(config.emissivity, 0.25);
    this.temperatureK = new Float64Array(grid.count).fill(initial2);
    this.landTemperatureK = config.separateReservoirs ? this.temperatureK.slice() : this.temperatureK;
    this.oceanTemperatureK = config.separateReservoirs ? this.temperatureK.slice() : this.temperatureK;
    this.absorbedWm2 = new Float64Array(grid.count);
    this.radiationScale = new Float64Array(grid.count).fill(1);
    if (reference2) {
      if ([reference2.temperatureK, reference2.radiationScale, reference2.absorbedWm2].some((a) => a.length !== grid.count)) throw new RangeError("Thermal initial state size mismatch");
      for (let i = 0; i < grid.count; i++) {
        finiteInRange(reference2.temperatureK[i], "initial temperature", 0);
        finiteInRange(reference2.radiationScale[i], "altitude factor", 0.55, 1);
        finiteInRange(reference2.absorbedWm2[i], "initial absorbed sunlight", 0);
      }
      this.temperatureK.set(reference2.temperatureK);
      this.radiationScale.set(reference2.radiationScale);
      this.absorbedWm2.set(reference2.absorbedWm2);
      if (config.separateReservoirs) for (const key of ["landTemperatureK", "oceanTemperatureK"]) {
        const source2 = reference2[key] ?? reference2.temperatureK;
        if (source2.length !== grid.count) throw new RangeError("Thermal surface initial state size mismatch");
        for (let i = 0; i < grid.count; i++) finiteInRange(source2[i], "initial surface temperature", 0);
        this[key].set(source2);
      }
    }
    this.land = Float64Array.from(land, (f) => {
      finiteInRange(f, "land fraction", 0, 1);
      return f;
    });
    this.landCapacity = Float64Array.from(this.land, (f) => f * config.landHeatCapacity);
    this.oceanCapacity = Float64Array.from(this.land, (f) => (1 - f) * config.oceanDepthM * 42e5);
    this.capacity = Float64Array.from(this.land, (_, i) => config.separateReservoirs ? 1e7 : this.landCapacity[i] + this.oceanCapacity[i]);
    this.tendency = new Float64Array(grid.count);
    this.albedo = new Float64Array(grid.count).fill(orbit.bondAlbedo);
    const loss = new Float64Array(grid.count);
    for (const e2 of grid.edges) {
      const k = this.transport * e2.geometry / grid.solidAngle;
      loss[e2.a] += k;
      loss[e2.b] += k;
    }
    const maxT = Math.max(initial2, Math.pow(this.fluxWm2 / (config.emissivity * STEFAN_BOLTZMANN), 0.25));
    let stable = Infinity;
    for (let i = 0; i < grid.count; i++) {
      const derivative = 4 * config.emissivity * STEFAN_BOLTZMANN * maxT ** 3;
      const airFraction = config.airRadiationFraction ?? 0;
      stable = Math.min(stable, 0.45 * this.capacity[i] / (loss[i] + (config.separateReservoirs ? airFraction : 1) * derivative / this.radiationScale[i] ** 4));
      if (config.separateReservoirs) {
        if (this.land[i] > 0) stable = Math.min(stable, 0.45 * config.landHeatCapacity / ((1 - airFraction) * derivative / this.radiationScale[i] ** 4));
        if (this.land[i] < 1) stable = Math.min(stable, 0.45 * config.oceanDepthM * 42e5 / ((1 - airFraction) * derivative));
      }
    }
    this.maxStableStepS = stable;
    this.stepS = Math.min(1800, this.yearS / 720, stable);
    this.initialEnergyJm2 = initialEnergyJm2 ?? this.energy();
  }
  epochS;
  grid;
  surfaceSolver = null;
  oceanSurfaceSolver = null;
  temperatureK;
  absorbedWm2;
  capacity;
  landTemperatureK;
  oceanTemperatureK;
  /** Sensible heat capacities per whole cell area; absent surfaces have zero capacity. */
  landCapacity;
  oceanCapacity;
  land;
  initialEnergyJm2;
  yearS;
  fluxWm2;
  transport;
  radiationScale;
  planet;
  orbit;
  config;
  tendency;
  stepS;
  maxStableStepS;
  steps = 0;
  radiationJm2 = 0;
  exchangeJm2 = 0;
  exchangeCorrection = 0;
  radiationCorrection = 0;
  albedo;
  /** Optional independent surface reflectivity; albedo remains the area mean. */
  surfaceAlbedo = null;
  get timeS() {
    return this.epochS + this.steps * this.stepS;
  }
  energy() {
    return this.temperatureK.reduce((sum3, t, i) => sum3 + this.capacity[i] * t + (this.config.separateReservoirs ? this.landCapacity[i] * this.landTemperatureK[i] + this.oceanCapacity[i] * this.oceanTemperatureK[i] : 0), 0) / this.grid.count;
  }
  checkpoint() {
    return { temperatureK: this.temperatureK.slice(), ...this.config.separateReservoirs ? { landTemperatureK: this.landTemperatureK.slice(), oceanTemperatureK: this.oceanTemperatureK.slice() } : {}, absorbedWm2: this.absorbedWm2.slice(), steps: this.steps, radiationJm2: this.radiationJm2, exchangeJm2: this.exchangeJm2, radiationCorrection: this.radiationCorrection, exchangeCorrection: this.exchangeCorrection, albedo: this.albedo.slice() };
  }
  restore(state) {
    if (this.config.separateReservoirs) {
      if (state.landTemperatureK?.length !== this.grid.count || state.oceanTemperatureK?.length !== this.grid.count) throw new RangeError("Missing separate thermal reservoirs");
      this.landTemperatureK.set(state.landTemperatureK);
      this.oceanTemperatureK.set(state.oceanTemperatureK);
    } else if (state.landTemperatureK !== void 0 || state.oceanTemperatureK !== void 0) throw new RangeError("Unexpected separate thermal reservoirs");
    this.temperatureK.set(state.temperatureK);
    this.absorbedWm2.set(state.absorbedWm2);
    this.steps = state.steps;
    this.radiationJm2 = state.radiationJm2;
    this.exchangeJm2 = state.exchangeJm2;
    this.exchangeCorrection = state.exchangeCorrection;
    this.radiationCorrection = state.radiationCorrection;
    this.albedo.set(state.albedo);
  }
  /** Internal coupled transfers, positive into sensible heat. */
  applyHeat(energyJm2) {
    this.applyReservoirHeat(energyJm2, this.temperatureK, this.capacity);
  }
  applyLandHeat(energyJm2) {
    this.config.separateReservoirs ? this.applyReservoirHeat(energyJm2, this.landTemperatureK, this.landCapacity) : this.applyHeat(energyJm2);
  }
  applyOceanHeat(energyJm2) {
    this.config.separateReservoirs ? this.applyReservoirHeat(energyJm2, this.oceanTemperatureK, this.oceanCapacity) : this.applyHeat(energyJm2);
  }
  applySurfaceCellHeat(i, land, ocean) {
    if (land !== 0) {
      if (this.landCapacity[i] === 0) throw new Error("Land heat requires surface");
      this.landTemperatureK[i] += land / this.landCapacity[i];
    }
    if (ocean !== 0) {
      if (this.oceanCapacity[i] === 0) throw new Error("Ocean heat requires surface");
      this.oceanTemperatureK[i] += ocean / this.oceanCapacity[i];
    }
    const increment = (land + ocean) / this.grid.count - this.exchangeCorrection, total = this.exchangeJm2 + increment;
    this.exchangeCorrection = total - this.exchangeJm2 - increment;
    this.exchangeJm2 = total;
  }
  applyReservoirHeat(energyJm2, temperature, capacity) {
    if (energyJm2.length !== this.grid.count) throw new RangeError("Heat grid mismatch");
    let sum3 = 0;
    for (let i = 0; i < this.grid.count; i++) {
      if (capacity[i] > 0) temperature[i] += energyJm2[i] / capacity[i];
      else if (energyJm2[i] !== 0) throw new RangeError("Heat transfer requires an existing surface reservoir");
      sum3 += energyJm2[i];
    }
    const increment = sum3 / this.grid.count - this.exchangeCorrection, total = this.exchangeJm2 + increment;
    this.exchangeCorrection = total - this.exchangeJm2 - increment;
    this.exchangeJm2 = total;
  }
  advanceTo(targetS, maxSteps = 32, afterStep) {
    finiteInRange(targetS, "thermal time", this.epochS);
    const targetSteps = Math.floor((targetS - this.epochS) / this.stepS + 1e-8);
    const end = Math.min(targetSteps, this.steps + maxSteps);
    for (; this.steps < end; this.steps++) {
      this.step();
      afterStep?.(this.stepS, this.temperatureK, this.absorbedWm2);
    }
    return this.steps >= targetSteps;
  }
  step() {
    const { grid, temperatureK: t, config } = this;
    const phase2 = this.orbit.orbitPhaseRad + 2 * Math.PI * ((this.timeS + this.stepS / 2) % this.yearS / this.yearS);
    const declination = Math.asin(Math.sin(this.planet.obliquityRad) * Math.sin(phase2));
    const q = new Float64Array(grid.height);
    for (let j = 0; j < grid.height; j++) for (let k = 0; k < 4; k++) q[j] += dailyMeanInsolation(1 - 2 * (j + (k + 0.5) / 4) / grid.height, declination, this.fluxWm2) / 4;
    const normalizer = this.fluxWm2 * 0.25 * grid.height / q.reduce((a, b) => a + b, 0);
    heatTransport(grid, t, this.transport, this.tendency);
    let radiation = 0;
    for (let i = 0; i < grid.count; i++) {
      this.absorbedWm2[i] = (1 - this.albedo[i]) * q[Math.floor(i / grid.width)] * normalizer;
      if (config.separateReservoirs) {
        const airFraction = config.airRadiationFraction ?? 0;
        const airEmission = airFraction * config.emissivity * STEFAN_BOLTZMANN * t[i] ** 4 * (this.land[i] / this.radiationScale[i] ** 4 + 1 - this.land[i]);
        radiation -= airEmission;
        t[i] += this.stepS * (this.tendency[i] - airEmission) / this.capacity[i];
        if (this.surfaceSolver) {
          radiation += this.surfaceSolver.stepSurface(i, this.stepS, q[Math.floor(i / grid.width)] * normalizer);
          continue;
        }
        for (const ocean of [false, true]) {
          const fraction = ocean ? 1 - this.land[i] : this.land[i], surface = ocean ? this.oceanTemperatureK : this.landTemperatureK, capacity = ocean ? this.oceanCapacity : this.landCapacity;
          if (fraction === 0) continue;
          if (ocean && this.oceanSurfaceSolver) {
            radiation += this.oceanSurfaceSolver.stepOceanSurface(i, this.stepS);
            continue;
          }
          const albedo = this.surfaceAlbedo ? ocean ? this.surfaceAlbedo.ocean[i] : this.surfaceAlbedo.land[i] : this.albedo[i];
          const net = fraction * ((1 - albedo) * q[Math.floor(i / grid.width)] * normalizer - (1 - airFraction) * config.emissivity * STEFAN_BOLTZMANN * (surface[i] / (ocean ? 1 : this.radiationScale[i])) ** 4);
          radiation += net;
          surface[i] += this.stepS * net / capacity[i];
          const ca3 = this.capacity[i], cs = capacity[i], rate = 10 * fraction * (1 / ca3 + 1 / cs);
          const heat = (surface[i] - t[i]) * -Math.expm1(-this.stepS * rate) / (1 / ca3 + 1 / cs);
          surface[i] -= heat / cs;
          t[i] += heat / ca3;
        }
      } else {
        const net = this.absorbedWm2[i] - config.emissivity * STEFAN_BOLTZMANN * (t[i] / this.radiationScale[i]) ** 4;
        radiation += net;
        t[i] += this.stepS * (net + this.tendency[i]) / this.capacity[i];
      }
    }
    const increment = radiation / grid.count * this.stepS - this.radiationCorrection, total = this.radiationJm2 + increment;
    this.radiationCorrection = total - this.radiationJm2 - increment;
    this.radiationJm2 = total;
  }
  diagnostics() {
    let mean = 0, min = Infinity, max = -Infinity;
    for (const t of this.temperatureK) {
      mean += t;
      min = Math.min(min, t);
      max = Math.max(max, t);
    }
    return {
      meanK: mean / this.grid.count,
      minK: min,
      maxK: max,
      timeS: this.timeS,
      budgetResidualJm2: this.energy() - this.initialEnergyJm2 - this.radiationJm2 - this.exchangeJm2
    };
  }
};

// lake-storage.ts
var LakeStorage = class {
  constructor(patches) {
    this.patches = patches;
    this.min = Math.min(...patches.flatMap((p2) => p2.vertices.map((v2) => v2[2])));
    this.max = Math.max(...patches.flatMap((p2) => p2.vertices.map((v2) => v2[2])));
    this.coefficients = new Float64Array(patches.length * 7);
    let mean = 0;
    for (let i = 0; i < patches.length; i++) {
      const [a, b, c] = patches[i].vertices.map((v2) => v2[2]).sort((a2, b2) => a2 - b2), m2 = (a + b + c) / 3, w2 = patches[i].weight;
      this.coefficients.set([a, b, c, m2, 1 / (3 * (b - a) * (c - a)), 1 / (3 * (c - a) * (c - b)), w2], i * 7);
      mean += w2 * m2;
    }
    this.mean = mean;
  }
  patches;
  min;
  max;
  coefficients;
  mean;
  depth(h) {
    let result = 0;
    const p2 = this.coefficients;
    for (let i = 0; i < p2.length; i += 7) {
      let d2 = 0;
      if (h >= p2[i + 2]) d2 = h - p2[i + 3];
      else if (h > p2[i]) {
        if (h <= p2[i + 1]) d2 = (h - p2[i]) ** 3 * p2[i + 4];
        else d2 = h - p2[i + 3] + (p2[i + 2] - h) ** 3 * p2[i + 5];
      }
      result += p2[i + 6] * d2;
    }
    return result;
  }
  level(depthM) {
    if (depthM <= 0) return this.min;
    if (depthM + this.mean >= this.max) return depthM + this.mean;
    let lo = this.min, hi = this.max + depthM;
    for (let i = 0; i < 36; i++) {
      const mid = (lo + hi) / 2;
      if (this.depth(mid) < depthM) lo = mid;
      else hi = mid;
    }
    return (lo + hi) / 2;
  }
};

// terrain-water.ts
function oceanTransfer(water, amount) {
  if (water.addOceanWater) water.addOceanWater(amount);
  else water.oceanGlobalKgM2 += amount;
}
var TerrainWater = class {
  constructor(network, water) {
    this.network = network;
    const n2 = network.cell.length;
    this.lakeBeds = Array.from({ length: n2 }, (_, t) => (network.inlandLakeId?.[t] ?? 0) > 0 && network.bedPatches?.[t]?.length ? new LakeStorage(network.bedPatches[t]) : null);
    this.volumeM3 = new Float64Array(n2);
    this.fluxM3S = new Float64Array(n2);
    this.receiverSide = new Int32Array(n2).fill(-1);
    this.headM = new Float64Array(n2);
    this.delta = new Float64Array(n2);
    this.byCell = Array.from({ length: water.grid.count }, () => []);
    this.cellArea = new Float64Array(water.grid.count);
    for (let i = 0; i < n2; i++) if (network.cell[i] >= 0) {
      const k = network.cell[i];
      this.byCell[k].push(i);
      this.cellArea[k] += network.areaM2[i];
    }
    this.previousSurface = new Float64Array(water.grid.count);
    this.reconcile(water);
    this.refreshHeads();
  }
  network;
  partition = null;
  clearPartition() {
    this.partition = null;
  }
  setPartition(triangle, mass, parent) {
    const byPatch = Array.from({ length: mass.length }, () => []), area = new Float64Array(mass.length);
    for (let t = 0; t < triangle.length; t++) if (triangle[t] >= 0) {
      byPatch[triangle[t]].push(t);
      area[triangle[t]] += this.network.areaM2[t];
    }
    const previous = new Float64Array(mass.length), byParent = Array.from({ length: this.byCell.length }, () => []);
    for (let a = 0; a < parent.length; a++) byParent[parent[a]].push(a);
    this.partition = { triangle, mass, parent, byPatch, byParent, area, previous };
    for (let t = 0; t < triangle.length; t++) if (triangle[t] >= 0) previous[triangle[t]] += this.volumeM3[t];
  }
  volumeM3;
  fluxM3S;
  receiverSide;
  headM;
  byCell;
  cellArea;
  previousSurface;
  delta;
  lakeBeds;
  reconcile(water) {
    const scale2 = water.cellAreaM2 / 1e3;
    if (this.partition) {
      const p2 = this.partition;
      for (let k = 0; k < water.grid.count; k++) {
        let unresolved = 0, represented = 0, representedArea = 0;
        for (const a of p2.byParent[k]) {
          if (p2.byPatch[a].length) {
            represented += p2.mass[a];
            representedArea += p2.area[a];
          } else unresolved += p2.mass[a];
        }
        for (const a of p2.byParent[k]) if (p2.byPatch[a].length) {
          const target = (p2.mass[a] + (represented > 0 ? unresolved * p2.mass[a] / represented : representedArea > 0 ? unresolved * p2.area[a] / representedArea : 0)) * scale2, cells = p2.byPatch[a], total = cells.reduce((s, t) => s + this.volumeM3[t], 0), change = target - p2.previous[a];
          if (change > 0) {
            const ratio = total > 0 ? p2.previous[a] / total : 0;
            for (const t of cells) this.volumeM3[t] = this.volumeM3[t] * ratio + change * this.network.areaM2[t] / p2.area[a];
          } else {
            const ratio = total > 0 ? target / total : 0;
            for (const t of cells) this.volumeM3[t] *= ratio;
          }
          p2.previous[a] = target;
        }
      }
      this.previousSurface = water.surfaceKgM2.slice();
      return;
    }
    for (let k = 0; k < water.grid.count; k++) {
      const target = water.surfaceKgM2[k], change = (target - this.previousSurface[k]) * scale2, cells = this.byCell[k];
      if (target === 0) {
        for (const i of cells) this.volumeM3[i] = 0;
        continue;
      }
      const total = cells.reduce((sum3, i) => sum3 + this.volumeM3[i], 0);
      if (change > 0) {
        const fraction = total > 0 ? this.previousSurface[k] * scale2 / total : 0;
        for (const i of cells) this.volumeM3[i] = this.volumeM3[i] * fraction + change * this.network.areaM2[i] / this.cellArea[k];
      } else {
        const fraction = total > 0 ? target * scale2 / total : 0;
        for (const i of cells) this.volumeM3[i] *= fraction;
      }
    }
    this.previousSurface = water.surfaceKgM2.slice();
  }
  synchronize(water) {
    this.reconcile(water);
    this.refreshHeads();
    if (this.partition) {
      const p2 = this.partition;
      p2.previous.fill(0);
      for (let t = 0; t < p2.triangle.length; t++) if (p2.triangle[t] >= 0) p2.previous[p2.triangle[t]] += this.volumeM3[t];
    }
  }
  storedAt(t, level) {
    return this.network.areaM2[t] * (this.lakeBeds[t]?.depth(level) ?? Math.max(0, level - this.network.bedM[t]));
  }
  refreshHeads() {
    for (let i = 0; i < this.volumeM3.length; i++) {
      const depth = this.volumeM3[i] / this.network.areaM2[i];
      this.headM[i] = this.lakeBeds[i]?.level(depth) ?? this.network.bedM[i] + depth;
    }
  }
  /** Explicit observed initial condition, never an automatic refill. Replace
   * lake volumes and debit the finite ocean donor, preserving global water.
   * Liquid mass has no sensible enthalpy in this reservoir-routing model. */
  initializeLakeLevels(water, levels) {
    if (this.partition) throw new Error("Initialize lake inventory before surface refinement");
    const requested = /* @__PURE__ */ new Map();
    for (const { lakeId, levelM } of levels) {
      if (!Number.isSafeInteger(lakeId) || lakeId <= 0 || !Number.isFinite(levelM) || requested.has(lakeId)) throw new Error("Invalid lake level");
      requested.set(lakeId, levelM);
    }
    const values = this.volumeM3.slice(), change = new Float64Array(water.grid.count), seen = /* @__PURE__ */ new Set();
    let deltaM3 = 0;
    for (let t = 0; t < values.length; t++) {
      const id = this.network.inlandLakeId?.[t] ?? 0, level = requested.get(id);
      if (level === void 0) continue;
      seen.add(id);
      const target = this.storedAt(t, level), delta = target - values[t];
      values[t] = target;
      change[this.network.cell[t]] += delta * 1e3 / water.cellAreaM2;
      deltaM3 += delta;
    }
    if (seen.size !== requested.size) throw new Error("Unknown lake inventory");
    const globalDelta = deltaM3 * 1e3 / (water.cellAreaM2 * water.grid.count);
    if (globalDelta > water.oceanGlobalKgM2) throw new Error("Insufficient ocean inventory for observed lake level");
    for (let k = 0; k < change.length; k++) water.surfaceKgM2[k] += change[k];
    oceanTransfer(water, -globalDelta);
    this.volumeM3.set(values);
    this.previousSurface = water.surfaceKgM2.slice();
    this.refreshHeads();
    this.fluxM3S.fill(0);
    this.receiverSide.fill(-1);
    water.dischargeM3S.fill(0);
  }
  route(water, dt2, speedMps, diagnose = false) {
    this.reconcile(water);
    this.refreshHeads();
    this.delta.fill(0);
    this.fluxM3S.fill(0);
    this.receiverSide.fill(-1);
    water.dischargeM3S.fill(0);
    const { cell, areaM2, neighbors } = this.network, n2 = cell.length, conversion = 1e3 / water.cellAreaM2, coarseDelta = new Float64Array(water.grid.count);
    let oceanM3 = 0;
    for (let i = 0; i < n2; i++) {
      if (cell[i] < 0 || this.volumeM3[i] <= 0) continue;
      let target = null, best = this.headM[i];
      for (const edge of neighbors[i]) {
        const head = Math.max(edge.sillM, edge.to < 0 ? 0 : this.headM[edge.to]);
        if (head < best) {
          target = edge;
          best = head;
        }
      }
      if (!target) continue;
      const j = target.to;
      let available = Math.min(this.volumeM3[i], (this.headM[i] - best) / (1 / areaM2[i] + (j < 0 ? 0 : 1 / areaM2[j])));
      if (this.lakeBeds[i] && best < this.lakeBeds[i].max || j >= 0 && this.lakeBeds[j] && best < this.lakeBeds[j].max) {
        if (j < 0) available = Math.max(0, this.volumeM3[i] - this.storedAt(i, best));
        else {
          let lo = Math.min(this.headM[i], this.headM[j]), hi = this.headM[i], total = this.volumeM3[i] + this.volumeM3[j];
          for (let iter = 0; iter < 32; iter++) {
            const mid = (lo + hi) / 2;
            if (this.storedAt(i, mid) + this.storedAt(j, mid) < total) lo = mid;
            else hi = mid;
          }
          available = Math.max(0, this.volumeM3[i] - this.storedAt(i, Math.max(target.sillM, (lo + hi) / 2)));
        }
      }
      const amount = available * Math.min(0.45, -Math.expm1(-dt2 * speedMps / target.distanceM));
      this.fluxM3S[i] = amount / dt2;
      this.receiverSide[i] = target.side;
      this.delta[i] -= amount;
      coarseDelta[cell[i]] -= amount * conversion;
      if (j < 0) {
        oceanM3 += amount;
        water.dischargeM3S[cell[i]] += amount / dt2;
      } else {
        this.delta[j] += amount;
        coarseDelta[cell[j]] += amount * conversion;
        if (cell[i] !== cell[j]) water.dischargeM3S[cell[i]] += amount / dt2;
      }
    }
    if (!diagnose) {
      for (let i = 0; i < n2; i++) this.volumeM3[i] += this.delta[i];
      for (let k = 0; k < water.grid.count; k++) water.surfaceKgM2[k] += coarseDelta[k];
      oceanTransfer(water, oceanM3 * conversion / water.grid.count);
    }
    this.previousSurface = water.surfaceKgM2.slice();
    this.refreshHeads();
    if (this.partition) {
      const p2 = this.partition;
      p2.previous.fill(0);
      for (let t = 0; t < n2; t++) if (p2.triangle[t] >= 0) p2.previous[p2.triangle[t]] += this.volumeM3[t];
    }
  }
  checkpoint() {
    return { volumeM3: this.volumeM3.slice(), fluxM3S: this.fluxM3S.slice(), receiverSide: this.receiverSide.slice() };
  }
  restore(s, water) {
    if (s.volumeM3.length !== this.volumeM3.length || s.fluxM3S.length !== this.volumeM3.length || s.receiverSide.length !== this.volumeM3.length) throw new Error("Terrain water size mismatch");
    for (let i = 0; i < s.volumeM3.length; i++) {
      if (!Number.isFinite(s.volumeM3[i]) || s.volumeM3[i] < 0 || !Number.isFinite(s.fluxM3S[i]) || s.fluxM3S[i] < 0) throw new Error("Invalid terrain water");
      if (s.receiverSide[i] !== -1 && !this.network.neighbors[i].some((e2) => e2.side === s.receiverSide[i])) throw new Error("Invalid terrain outlet");
      if (this.network.cell[i] < 0 && (s.volumeM3[i] !== 0 || s.fluxM3S[i] !== 0)) throw new Error("Ocean triangle cannot hold terrestrial water");
    }
    for (let k = 0; k < water.grid.count; k++) if (this.byCell[k].length) {
      const amount = this.byCell[k].reduce((sum3, i) => sum3 + s.volumeM3[i], 0) * 1e3 / water.cellAreaM2;
      if (Math.abs(amount - water.surfaceKgM2[k]) > Math.max(1e-8, water.surfaceKgM2[k] * 1e-9)) throw new Error("Fine and coarse water stores differ");
    }
    this.volumeM3.set(s.volumeM3);
    this.fluxM3S.set(s.fluxM3S);
    this.receiverSide.set(s.receiverSide);
    this.previousSurface = water.surfaceKgM2.slice();
    this.refreshHeads();
    if (this.partition) {
      const p2 = this.partition;
      p2.previous.fill(0);
      for (let t = 0; t < p2.triangle.length; t++) if (p2.triangle[t] >= 0) p2.previous[p2.triangle[t]] += this.volumeM3[t];
    }
  }
  diagnostics(water) {
    let representedM3 = 0, unresolvedM3 = 0, partitionResidualM3 = 0, maxDepthM = 0, maxFlowM3S = 0;
    for (let k = 0; k < water.grid.count; k++) {
      const coarse2 = water.surfaceKgM2[k] * water.cellAreaM2 / 1e3;
      if (!this.byCell[k].length) unresolvedM3 += coarse2;
      else {
        representedM3 += coarse2;
        partitionResidualM3 += this.byCell[k].reduce((sum3, i) => sum3 + this.volumeM3[i], 0) - coarse2;
      }
    }
    for (let i = 0; i < this.volumeM3.length; i++) {
      maxDepthM = Math.max(maxDepthM, this.volumeM3[i] / this.network.areaM2[i]);
      maxFlowM3S = Math.max(maxFlowM3S, this.fluxM3S[i]);
    }
    return { representedM3, unresolvedM3, partitionResidualM3, maxDepthM, maxFlowM3S };
  }
};
function terrainRoutingNetwork(mesh2, elevation2, grid, radiusM, reliefM, quadElements, inlandLakeId, oceanDepthM = reliefM) {
  const n2 = mesh2.numTriangles, cell = new Int32Array(n2).fill(-1), areaM2 = new Float64Array(n2), bedM = new Float64Array(n2), neighbors = Array.from({ length: n2 }, () => []);
  const bedPatches = Array.from({ length: n2 }, () => []);
  const xyz = (r) => [mesh2.xyz_r[3 * r], mesh2.xyz_r[3 * r + 1], mesh2.xyz_r[3 * r + 2]], dot = (a, b) => a[0] * b[0] + a[1] * b[1] + a[2] * b[2];
  const cross = (a, b) => [a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]];
  const angle = (a, b) => Math.acos(Math.max(-1, Math.min(1, dot(a, b))));
  const area = (a, b, c) => 2 * Math.atan2(Math.abs(dot(a, cross(b, c))), 1 + dot(a, b) + dot(b, c) + dot(c, a)) * radiusM ** 2;
  const vertex = (p2, height2) => [...directionToUV(p2).map((v2) => 1e3 * v2), height2];
  const lake = Int32Array.from({ length: n2 }, (_, t) => elevation2[mesh2.numRegions + t] <= 0 ? inlandLakeId?.[t] ?? 0 : 0);
  const height = (e2) => e2 * (e2 >= 0 ? reliefM : oceanDepthM);
  for (let t = 0; t < n2; t++) {
    const [a, b, c] = [0, 1, 2].map((j) => xyz(mesh2.r_begin_s(3 * t + j))), det = a[0] * (b[1] * c[2] - b[2] * c[1]) + a[1] * (b[2] * c[0] - b[0] * c[2]) + a[2] * (b[0] * c[1] - b[1] * c[0]);
    areaM2[t] = 2 * Math.atan2(Math.abs(det), 1 + dot(a, b) + dot(b, c) + dot(c, a)) * radiusM ** 2;
    const e2 = elevation2[mesh2.numRegions + t];
    bedM[t] = lake[t] > 0 ? height(e2) : Math.max(0, e2 * reliefM);
    if (e2 > 0 || lake[t] > 0) {
      const uv = directionToUV(mesh2.xyz_t.subarray(3 * t, 3 * t + 3));
      cell[t] = thermalCell(grid, ...uv);
    }
  }
  for (let t = 0; t < n2; t++) if (cell[t] >= 0) for (let j = 0; j < 3; j++) {
    const s = 3 * t + j, to = mesh2.t_outer_s(s), a = mesh2.r_begin_s(s), b = mesh2.r_begin_s(mesh2.s_next_s(s));
    let cos = 0;
    for (let c = 0; c < 3; c++) cos += mesh2.xyz_t[3 * t + c] * mesh2.xyz_t[3 * to + c];
    const distanceM = radiusM * Math.acos(Math.max(-1, Math.min(1, cos)));
    const pa = xyz(a), pb = xyz(b), pt = Array.from(mesh2.xyz_t.subarray(3 * t, 3 * t + 3)), pn = Array.from(mesh2.xyz_t.subarray(3 * to, 3 * to + 3));
    const va = vertex(pa, lake[t] > 0 ? height(elevation2[a]) : elevation2[a] * reliefM), vb = vertex(pb, lake[t] > 0 ? height(elevation2[b]) : elevation2[b] * reliefM), vt = vertex(pt, bedM[t]);
    let sillM = Math.min(va[2], vb[2]);
    if (quadElements && quadElements[3 * s + 1] >= mesh2.numRegions) {
      let pc = cross(cross(pa, pb), cross(pt, pn));
      const norm = Math.hypot(...pc), sign = dot(pc, pa) >= 0 ? 1 : -1;
      pc = pc.map((v2) => v2 * sign / norm);
      const f = angle(pt, pc) / angle(pt, pn), h = (1 - f) * (lake[t] > 0 ? bedM[t] : elevation2[mesh2.numRegions + t] * reliefM) + f * (lake[to] > 0 ? bedM[to] : elevation2[mesh2.numRegions + to] * reliefM), vc = vertex(pc, h);
      sillM = Math.min(sillM, h);
      bedPatches[t].push({ vertices: [vt, va, vc], weight: area(pt, pa, pc) }, { vertices: [vt, vc, vb], weight: area(pt, pc, pb) });
    } else bedPatches[t].push({ vertices: [vt, va, vb], weight: area(pt, pa, pb) });
    neighbors[t].push({ to: cell[to] >= 0 ? to : -1, sillM: lake[t] > 0 && lake[to] > 0 ? sillM : Math.max(0, sillM), distanceM: Math.max(1e-6, distanceM), side: s });
  }
  for (const patches of bedPatches) {
    const sum3 = patches.reduce((s, p2) => s + p2.weight, 0);
    for (const p2 of patches) p2.weight /= sum3;
  }
  return { cell, areaM2, bedM, neighbors, bedPatches, inlandLakeId: lake };
}

// glacier.ts
var ICE_DENSITY = 917;
var GLACIER_YEAR = 365.25 * 86400;
var GlacierModel = class {
  constructor(water, gravityMps2, bedrockM) {
    this.water = water;
    this.gravityMps2 = gravityMps2;
    const { grid, radiusM } = water, n2 = grid.count;
    finiteInRange(gravityMps2, "ice gravity", Number.MIN_VALUE);
    if (bedrockM && (bedrockM.length !== n2 || bedrockM.some((v2) => !Number.isFinite(v2) || v2 < -12e3 || v2 > 1e6))) throw new Error("Invalid glacier bedrock");
    this.bedrockM = bedrockM?.slice() ?? water.heightM.slice();
    this.observedBed = !!bedrockM;
    this.erodedM = new Float64Array(n2);
    this.sedimentM = new Float64Array(n2);
    this.depositedM = new Float64Array(n2);
    this.speedMps = new Float64Array(n2);
    this.outflowM3S = new Float64Array(n2);
    const xyz = Array.from({ length: n2 }, (_, i) => {
      const y = grid.sinLat[Math.floor(i / grid.width)], lon = 2 * Math.PI * ((i % grid.width + 0.5) / grid.width - 0.5), r = Math.sqrt(1 - y * y);
      return [r * Math.sin(lon), y, r * Math.cos(lon)];
    });
    this.distances = Float64Array.from(grid.edges, (e2) => radiusM * Math.acos(Math.max(-1, Math.min(1, xyz[e2.a].reduce((s, v2, i) => s + v2 * xyz[e2.b][i], 0)))));
  }
  water;
  gravityMps2;
  erodedM;
  sedimentM;
  depositedM;
  speedMps;
  outflowM3S;
  limitedCells = 0;
  erodedVolumeM = null;
  distances;
  bedrockM;
  observedBed;
  thickness(i) {
    const w2 = this.water;
    return w2.land[i] > 0 ? w2.landIceKgM2[i] / (ICE_DENSITY * w2.land[i]) : 0;
  }
  step(dt2, temperatureK) {
    finiteInRange(dt2, "glacier step", Number.MIN_VALUE);
    const w2 = this.water, n2 = w2.grid.count;
    const compact = -Math.expm1(-dt2 / (30 * GLACIER_YEAR));
    for (let i = 0; i < n2; i++) if (!w2.surfaceSolver && w2.land[i] > 0 && temperatureK[i] < 273.15) {
      const amount = Math.max(0, w2.snowKgM2[i] - 50 * w2.land[i]) * compact;
      w2.snowKgM2[i] -= amount;
      w2.addLandIce(i, amount);
    }
    const flux = new Float64Array(w2.grid.edges.length), outgoing = new Float64Array(n2), widths = new Float64Array(flux.length);
    this.speedMps.fill(0);
    this.outflowM3S.fill(0);
    this.limitedCells = 0;
    w2.grid.edges.forEach((e2, k) => {
      if (w2.land[e2.a] <= 0 || w2.land[e2.b] <= 0) return;
      const ha = this.bedrockM[e2.a] + this.thickness(e2.a), hb = this.bedrockM[e2.b] + this.thickness(e2.b), from = ha > hb ? e2.a : e2.b, to = ha > hb ? e2.b : e2.a, H = this.thickness(from);
      if (H <= 0 || ha === hb) return;
      const distance = this.distances[k], slope = Math.abs(ha - hb) / distance;
      const softness = 24e-25 * Math.exp(Math.max(-4, Math.min(0, (temperatureK[from] - 273.15) * 0.08)));
      const speed = Math.min(2e4 / GLACIER_YEAR, 2 * softness / 5 * (ICE_DENSITY * this.gravityMps2) ** 3 * H ** 4 * slope ** 3);
      widths[k] = e2.geometry * distance * Math.min(w2.land[from], w2.land[to]);
      const requested = dt2 * speed * H * widths[k] * ICE_DENSITY / w2.cellAreaM2;
      const equalize = Math.abs(ha - hb) / (1 / (ICE_DENSITY * w2.land[from]) + 1 / (ICE_DENSITY * w2.land[to]));
      const amount = Math.min(requested, 0.25 * equalize);
      if (amount < requested) this.limitedCells++;
      flux[k] = (from === e2.a ? 1 : -1) * amount;
      outgoing[from] += amount;
    });
    const factors = outgoing.map((v2, i) => v2 > 0 ? Math.min(1, 0.45 * w2.landIceKgM2[i] / v2) : 1), delta = new Float64Array(n2), solidDelta = new Float64Array(n2);
    w2.grid.edges.forEach((e2, k) => {
      const from = flux[k] >= 0 ? e2.a : e2.b, to = flux[k] >= 0 ? e2.b : e2.a, amount = Math.abs(flux[k]) * factors[from];
      if (amount <= 0) return;
      delta[from] -= amount;
      delta[to] += amount;
      const solid = this.sedimentM[from] * amount / w2.landIceKgM2[from];
      solidDelta[from] -= solid;
      solidDelta[to] += solid;
      const flow = amount * w2.cellAreaM2 / (ICE_DENSITY * dt2);
      this.outflowM3S[from] += flow;
      this.speedMps[from] = Math.max(this.speedMps[from], flow / (this.thickness(from) * widths[k]));
    });
    for (let i = 0; i < n2; i++) {
      w2.addLandIce(i, delta[i]);
      this.sedimentM[i] += solidDelta[i];
      const H = this.thickness(i), erode = Math.min(Math.max(0, this.bedrockM[i] - this.erodedM[i]), dt2 * this.speedMps[i] * 1e-4 * H / (H + 50));
      this.erodedM[i] += erode;
      this.sedimentM[i] += erode * w2.land[i];
      if (this.erodedVolumeM) this.erodedVolumeM[i] += erode * w2.land[i];
      if (w2.landIceKgM2[i] === 0) {
        this.depositedM[i] += this.sedimentM[i];
        this.sedimentM[i] = 0;
      }
    }
  }
  checkpoint() {
    return { erodedM: this.erodedM.slice(), sedimentM: this.sedimentM.slice(), depositedM: this.depositedM.slice(), speedMps: this.speedMps.slice(), outflowM3S: this.outflowM3S.slice(), limitedCells: this.limitedCells, ...this.erodedVolumeM ? { erodedVolumeM: this.erodedVolumeM.slice() } : {}, ...this.observedBed ? { bedrockM: this.bedrockM.slice() } : {} };
  }
  restore(s) {
    if (this.observedBed && !s.bedrockM) throw new Error("Missing saved glacier bedrock");
    if (s.bedrockM && (s.bedrockM.length !== this.bedrockM.length || s.bedrockM.some((v2, i) => !Number.isFinite(v2) || Math.abs(v2 - this.bedrockM[i]) > 1e-9))) throw new Error("Saved glacier bedrock does not match initial ice surface and inventory");
    for (const key of ["erodedM", "sedimentM", "depositedM", "speedMps", "outflowM3S"]) {
      if (s[key].length !== this.water.grid.count || s[key].some((v2) => !Number.isFinite(v2) || v2 < 0)) throw new Error("Invalid glacial field");
    }
    if (s.erodedM.some((v2, i) => v2 > Math.max(0, this.bedrockM[i]) + 1e-8)) throw new Error("Glacial erosion exceeds available bed");
    if (!Number.isInteger(s.limitedCells) || s.limitedCells < 0 || s.limitedCells > this.water.grid.edges.length) throw new Error("Invalid glacier limiter count");
    if (s.erodedVolumeM && (s.erodedVolumeM.length !== this.water.grid.count || s.erodedVolumeM.some((v2) => !Number.isFinite(v2) || v2 < 0))) throw new Error("Invalid erosion volume history");
    if (!s.erodedVolumeM && s.erodedM.some((v2, i) => this.water.land[i] === 0 && (v2 !== 0 || s.sedimentM[i] !== 0 || s.depositedM[i] !== 0 || s.speedMps[i] !== 0 || s.outflowM3S[i] !== 0))) throw new Error("Grounded glacier state requires land");
    const residual = s.erodedM.reduce((sum3, v2, i) => sum3 - (s.erodedVolumeM?.[i] ?? v2 * this.water.land[i]) + s.sedimentM[i] + s.depositedM[i], 0), solid = s.erodedM.reduce((sum3, v2, i) => sum3 + (s.erodedVolumeM?.[i] ?? v2 * this.water.land[i]), 0);
    if (Math.abs(residual) > Math.max(1e-9, solid * 1e-10)) throw new Error("Glacial solid budget mismatch");
    for (const key of ["erodedM", "sedimentM", "depositedM", "speedMps", "outflowM3S"]) this[key].set(s[key]);
    this.limitedCells = s.limitedCells;
    this.erodedVolumeM = s.erodedVolumeM?.slice() ?? null;
  }
  diagnostics() {
    const w2 = this.water;
    let maxThicknessM = 0, maxSpeedMyr = 0, solidResidualM = 0, mobileM = 0, depositedM = 0;
    for (let i = 0; i < w2.grid.count; i++) {
      maxThicknessM = Math.max(maxThicknessM, this.thickness(i));
      maxSpeedMyr = Math.max(maxSpeedMyr, this.speedMps[i] * GLACIER_YEAR);
      solidResidualM += -(this.erodedVolumeM?.[i] ?? this.erodedM[i] * w2.land[i]) + this.sedimentM[i] + this.depositedM[i];
      mobileM += this.sedimentM[i];
      depositedM += this.depositedM[i];
    }
    return { maxThicknessM, maxSpeedMyr, solidResidualM: solidResidualM / w2.grid.count, mobileKm3: mobileM * w2.cellAreaM2 / 1e9, depositedKm3: depositedM * w2.cellAreaM2 / 1e9, limitedCells: this.limitedCells };
  }
};

// water.ts
var DEFAULT_WATER = Object.freeze({
  evaporationFraction: 0.5,
  soilCapacityKgM2: 150,
  initialOceanDepthM: 1e3,
  windMps: 10,
  moistureDiffusivityM2s: 1e6,
  routingSpeedMps: 1
});
function moistureCapacity(t) {
  return 20 * Math.exp(0.06 * (Math.max(250, Math.min(330, t)) - 288.15));
}
var DAY = 86400;
var WATER_DENSITY = 1e3;
var VAPORIZATION_J_KG = 245e4;
var FUSION_J_KG = 334e3;
var WaterModel = class {
  constructor(grid, radiusM, land, heightM, initialTemperatureK, config, reference2, initialTotalMm) {
    this.grid = grid;
    this.radiusM = radiusM;
    finiteInRange(radiusM, "water radius", 1);
    finiteInRange(config.evaporationFraction, "evaporation fraction", 0, 1);
    finiteInRange(config.soilCapacityKgM2, "soil capacity", 1, 1e3);
    finiteInRange(config.initialOceanDepthM, "initial ocean depth", 0, 1e4);
    finiteInRange(config.windMps, "zonal wind", -100, 100);
    finiteInRange(config.moistureDiffusivityM2s, "moisture mixing", 0, 1e7);
    finiteInRange(config.routingSpeedMps, "surface routing speed", 0.01, 10);
    if (config.compensatedOceanTransfers !== void 0 && typeof config.compensatedOceanTransfers !== "boolean") throw new RangeError("Invalid ocean accumulation switch");
    if (config.upliftScheme !== void 0 && !["advective", "eddy-front"].includes(config.upliftScheme)) throw new RangeError("Invalid uplift scheme");
    for (const key of ["consistentLiftTemperature", "buoyantConvection", "coldFrontDisplacement"]) if (config[key] !== void 0 && typeof config[key] !== "boolean") throw new RangeError("Invalid lift switch");
    if ([land, heightM, initialTemperatureK].some((a) => a.length !== grid.count)) throw new RangeError("Water grid mismatch");
    this.land = Float64Array.from(land, (f) => {
      finiteInRange(f, "water land fraction", 0, 1);
      return f;
    });
    this.heightM = Float64Array.from(heightM, (h) => {
      finiteInRange(h, "land altitude", 0, 1e6);
      return h;
    });
    this.config = { ...config };
    this.cellAreaM2 = grid.solidAngle * radiusM ** 2;
    this.inlandWaterFraction = new Float64Array(grid.count);
    this.atmosphereKgM2 = Float64Array.from(initialTemperatureK, (t) => {
      finiteInRange(t, "water temperature", 0);
      return 0.5 * moistureCapacity(t);
    });
    this.soilKgM2 = Float64Array.from(land, (f) => f * config.soilCapacityKgM2 * 0.5);
    this.surfaceKgM2 = new Float64Array(grid.count);
    this.snowKgM2 = new Float64Array(grid.count);
    this.landIceKgM2 = new Float64Array(grid.count);
    this.seaIceKgM2 = new Float64Array(grid.count);
    this.meltKgM2S = new Float64Array(grid.count);
    this.landIceCorrection = new Float64Array(grid.count);
    this.shelfLandIceKgM2 = new Float64Array(grid.count);
    this.shelfSeaIceKgM2 = new Float64Array(grid.count);
    this.precipitationKgM2S = new Float64Array(grid.count);
    this.evaporationKgM2S = new Float64Array(grid.count);
    this.dischargeM3S = new Float64Array(grid.count);
    this.vaporTransportKgM2 = new Float64Array(grid.count);
    this.faceVaporTransportKgM2 = new Float64Array(grid.edges.length);
    this.faceAdvectiveVaporKgM2 = new Float64Array(grid.edges.length);
    this.faceDiffusiveVaporKgM2 = new Float64Array(grid.edges.length);
    this.landPrecipitationKgM2S = new Float64Array(grid.count);
    this.oceanPrecipitationKgM2S = new Float64Array(grid.count);
    this.precipitationComponents = { saturation: new Float64Array(grid.count), convection: new Float64Array(grid.count), front: new Float64Array(grid.count), convergence: new Float64Array(grid.count), orographic: new Float64Array(grid.count) };
    this.landPrecipitationComponents = { saturation: new Float64Array(grid.count), convection: new Float64Array(grid.count), front: new Float64Array(grid.count), convergence: new Float64Array(grid.count), orographic: new Float64Array(grid.count) };
    this.transportRain = { orographicAdvection: new Float64Array(grid.count), orographicDiffusion: new Float64Array(grid.count), frontAdvection: new Float64Array(grid.count), frontDiffusion: new Float64Array(grid.count), coldFrontAdvection: new Float64Array(grid.count) };
    this.oceanGlobalKgM2 = config.initialOceanDepthM * WATER_DENSITY * (1 - this.land.reduce((a, b) => a + b, 0) / grid.count);
    this.delta = new Float64Array(grid.count);
    this.oceanDemand = new Float64Array(grid.count);
    this.convergence = new Float64Array(grid.count);
    this.upslope = new Float64Array(grid.count);
    const outgoing = new Float64Array(grid.count), dl = 2 * Math.PI / grid.width;
    this.airRates = Float64Array.from(grid.edges, (e2) => config.moistureDiffusivityM2s / radiusM ** 2 * e2.geometry / grid.solidAngle);
    const dx = 2 / grid.height;
    this.windFactors = Float64Array.from(grid.edges, (e2) => {
      const row = Math.floor(e2.a / grid.width);
      return Math.floor(e2.b / grid.width) === row ? 1 / (radiusM * Math.sqrt(1 - grid.sinLat[row] ** 2) * dl) : -Math.sqrt(Math.max(0, 1 - (1 - (row + 1) * dx) ** 2)) / (radiusM * dx);
    });
    this.windRates = new Float64Array(grid.edges.length);
    this.windEastMps = new Float64Array(grid.count);
    this.windNorthMps = new Float64Array(grid.count);
    this.setWinds(reference2?.windEastMps ?? new Float64Array(grid.count).fill(config.windMps), reference2?.windNorthMps ?? new Float64Array(grid.count));
    const xyz = Array.from({ length: grid.count }, (_, i) => {
      const y = grid.sinLat[Math.floor(i / grid.width)], lon = ((i % grid.width + 0.5) / grid.width - 0.5) * 2 * Math.PI, r = Math.sqrt(1 - y * y);
      return [r * Math.sin(lon), y, r * Math.cos(lon)];
    });
    this.neighbors = Array.from({ length: grid.count }, () => []);
    this.edgeDistanceM = new Float64Array(grid.edges.length);
    let shortest = Infinity;
    grid.edges.forEach((e2, k) => {
      const mixingBound = this.airRates[k] * (config.moistureScheme === "transport" ? 10 : 1);
      outgoing[e2.a] += mixingBound;
      outgoing[e2.b] += mixingBound;
      const windLimit = Math.abs(config.windMps * this.windFactors[k]);
      outgoing[e2.a] += windLimit;
      outgoing[e2.b] += windLimit;
      const dot = xyz[e2.a].reduce((sum3, v2, i) => sum3 + v2 * xyz[e2.b][i], 0), distanceM = radiusM * Math.acos(Math.max(-1, Math.min(1, dot)));
      this.edgeDistanceM[k] = distanceM;
      this.neighbors[e2.a].push({ cell: e2.b, distanceM });
      this.neighbors[e2.b].push({ cell: e2.a, distanceM });
      shortest = Math.min(shortest, distanceM);
    });
    let maxRate = 0;
    for (let i = 0; i < grid.count; i++) maxRate = Math.max(maxRate, outgoing[i]);
    this.maxStepS = Math.min(config.moistureScheme === "transport" ? Infinity : maxRate > 0 ? 0.45 / maxRate : Infinity, 0.45 * shortest / config.routingSpeedMps, 21600);
    if (reference2) {
      if (reference2.atmosphereKgM2 && reference2.atmosphereKgM2.length !== grid.count) throw new RangeError("Water reference vapor size mismatch");
      const fields = ["humidityFraction", "soilFraction", "surfaceMm", "rainMmDay", "evaporationMmDay"];
      for (const key of fields) {
        if (reference2[key].length !== grid.count) throw new RangeError("Water reference size mismatch");
        for (const v2 of reference2[key]) finiteInRange(v2, key, 0, key.endsWith("Fraction") ? 1 : 1e6);
      }
      for (let i = 0; i < grid.count; i++) {
        const column = reference2.atmosphereKgM2?.[i] ?? reference2.humidityFraction[i] * moistureCapacity(initialTemperatureK[i]);
        finiteInRange(column, "reference vapor", 0, 1e6);
        this.atmosphereKgM2[i] = column;
        this.soilKgM2[i] = land[i] * config.soilCapacityKgM2 * reference2.soilFraction[i];
        this.surfaceKgM2[i] = land[i] * reference2.surfaceMm[i];
        this.precipitationKgM2S[i] = reference2.rainMmDay[i] / DAY;
        this.evaporationKgM2S[i] = reference2.evaporationMmDay[i] / DAY;
      }
      this.diagnoseRouting();
    }
    if (config.moistureScheme === "transport") {
      const demand = (this.atmosphereKgM2.reduce((s, v2) => s + v2, 0) + this.soilKgM2.reduce((s, v2) => s + v2, 0) + this.surfaceKgM2.reduce((s, v2) => s + v2, 0)) / grid.count;
      const fraction = demand > 0 ? Math.min(1, this.oceanGlobalKgM2 / demand) : 0;
      for (const store of [this.atmosphereKgM2, this.soilKgM2, this.surfaceKgM2]) for (let i = 0; i < grid.count; i++) store[i] *= fraction;
      this.oceanGlobalKgM2 = Math.max(0, this.oceanGlobalKgM2 - demand * fraction);
    }
    for (let i = 0; i < grid.count; i++) {
      this.landPrecipitationKgM2S[i] = this.precipitationKgM2S[i] * this.land[i];
      this.oceanPrecipitationKgM2S[i] = this.precipitationKgM2S[i] - this.landPrecipitationKgM2S[i];
    }
    this.initialTotalMm = initialTotalMm ?? this.total();
  }
  grid;
  radiusM;
  surfaceSolver = null;
  snowfallKgM2S = null;
  glacier = null;
  glacierBedM = null;
  pendingGlacier = null;
  attachGlacier(gravityMps2) {
    this.glacier = new GlacierModel(this, gravityMps2, this.glacierBedM);
    if (this.pendingGlacier) {
      this.glacier.restore(this.pendingGlacier);
      this.pendingGlacier = null;
    }
  }
  routing = null;
  /** Derived from confirmed inland bathymetry, never an additional store. */
  inlandWaterFraction;
  pendingRouting = null;
  attachRouting(network) {
    this.inlandWaterFraction.fill(0);
    for (let t = 0; t < network.cell.length; t++) if (network.cell[t] >= 0 && (network.inlandLakeId?.[t] ?? 0) > 0) this.inlandWaterFraction[network.cell[t]] += network.areaM2[t] / this.cellAreaM2;
    for (let k = 0; k < this.grid.count; k++) this.inlandWaterFraction[k] = Math.min(1 - this.land[k], this.inlandWaterFraction[k]);
    this.routing = new TerrainWater(network, this);
    if (this.pendingRouting) {
      this.routing.restore(this.pendingRouting, this);
      this.pendingRouting = null;
    } else this.routing.route(this, this.maxStepS, this.config.routingSpeedMps, true);
  }
  atmosphereKgM2;
  soilKgM2;
  surfaceKgM2;
  precipitationKgM2S;
  /** Deposited land/ocean amounts per WHOLE cell area. Initial estimates and
   * old coarse saves are uniform. Check landPrecipitationKnown for old refined saves. */
  landPrecipitationKgM2S;
  oceanPrecipitationKgM2S;
  /** Old refined remapping did not retain the recorded land/sea split.
   * A bounded estimate must never be serialized or labeled as an actual rate. */
  landPrecipitationKnown = true;
  evaporationKgM2S;
  /** Actual net vapor exchange during the latest step; not a persisted store. */
  vaporTransportKgM2;
  /** Signed a-to-b vapor transport at each face during the actual step,
   * before recipient condensation and after windward rainout. */
  faceVaporTransportKgM2;
  /** Unsaved signed face flux attribution; their sum is the actual face flux. */
  faceAdvectiveVaporKgM2;
  faceDiffusiveVaporKgM2;
  /** Actual step precipitation by mechanism. Lift shares partition the
   * incremental column rain; these diagnostics are not additional stocks. */
  precipitationComponents;
  landPrecipitationComponents;
  /** Unsaved causal attribution of intercepted finite parcels. */
  transportRain;
  precipitationComponentsValid = false;
  dischargeM3S;
  snowKgM2;
  landIceKgM2;
  /** Floating freshwater ice; the DEM mask selects its thermal surface only. */
  shelfLandIceKgM2;
  shelfSeaIceKgM2;
  landIceCorrection;
  addLandIce(i, amount) {
    if (amount === -this.landIceKgM2[i]) {
      this.landIceKgM2[i] = 0;
      this.landIceCorrection[i] = 0;
      return;
    }
    const increment = amount - this.landIceCorrection[i], total = this.landIceKgM2[i] + increment;
    this.landIceCorrection[i] = total - this.landIceKgM2[i] - increment;
    this.landIceKgM2[i] = total;
  }
  seaIceKgM2;
  meltKgM2S;
  cellAreaM2;
  maxStepS;
  land;
  heightM;
  config;
  windEastMps;
  windNorthMps;
  initialTotalMm;
  oceanGlobalKgM2 = 0;
  oceanCorrection = 0;
  /** A real signed reservoir transfer; compensation retains roundoff only. */
  addOceanWater(amount) {
    if (!this.config.compensatedOceanTransfers) {
      this.oceanGlobalKgM2 += amount;
      return;
    }
    if (!Number.isFinite(amount)) throw new RangeError("Invalid ocean transfer");
    if (amount <= -this.oceanGlobalKgM2) {
      if (amount < -this.oceanGlobalKgM2 - 4 * Number.EPSILON * Math.max(1, this.oceanGlobalKgM2)) throw new RangeError("Ocean transfer exceeds finite inventory");
      this.oceanGlobalKgM2 = 0;
      this.oceanCorrection = 0;
      return;
    }
    const increment = amount - this.oceanCorrection, total = this.oceanGlobalKgM2 + increment;
    this.oceanCorrection = total - this.oceanGlobalKgM2 - increment;
    this.oceanGlobalKgM2 = total;
  }
  elapsedS = 0;
  delta;
  oceanDemand;
  airRates;
  windRates;
  windFactors;
  convergence;
  upslope;
  edgeDistanceM;
  neighbors;
  diagnoseRouting() {
    if (this.routing) {
      this.routing.route(this, this.maxStepS, this.config.routingSpeedMps, true);
      return;
    }
    const surface = this.surfaceKgM2.slice(), ocean = this.oceanGlobalKgM2, correction = this.oceanCorrection;
    this.routeSurface(this.maxStepS);
    this.surfaceKgM2.set(surface);
    this.oceanGlobalKgM2 = ocean;
    this.oceanCorrection = correction;
  }
  setWinds(east, north) {
    if (east.length !== this.grid.count || north.length !== this.grid.count) throw new RangeError("Wind field size mismatch");
    const limit = Math.abs(this.config.windMps) + 1e-9;
    for (let i = 0; i < this.grid.count; i++) {
      finiteInRange(east[i], "east wind", -limit, limit);
      finiteInRange(north[i], "north wind", -limit, limit);
    }
    this.windEastMps.set(east);
    this.windNorthMps.set(north);
    this.convergence.fill(0);
    this.upslope.fill(0);
    this.grid.edges.forEach((e2, k) => {
      const wind = this.windFactors[k] > 0 ? east : north;
      this.windRates[k] = 0.5 * (wind[e2.a] + wind[e2.b]) * this.windFactors[k];
      const rate = this.windRates[k], from = rate >= 0 ? e2.a : e2.b, to = rate >= 0 ? e2.b : e2.a;
      this.convergence[e2.a] -= rate;
      this.convergence[e2.b] += rate;
      this.upslope[to] += Math.abs(rate) * Math.max(0, this.heightM[to] - this.heightM[from]);
    });
  }
  total() {
    return this.oceanGlobalKgM2 + this.atmosphereKgM2.reduce((sum3, v2, i) => sum3 + v2 + this.soilKgM2[i] + this.surfaceKgM2[i] + this.snowKgM2[i] + this.seaIceKgM2[i] + this.landIceKgM2[i] + this.shelfLandIceKgM2[i] + this.shelfSeaIceKgM2[i], 0) / this.grid.count;
  }
  seedShelves(landRequest, seaRequest) {
    const n2 = this.grid.count;
    if (landRequest.length !== n2 || seaRequest.length !== n2) throw new RangeError("Ice shelf grid mismatch");
    let demand = 0;
    for (let i = 0; i < n2; i++) {
      finiteInRange(landRequest[i], "initial land-mask shelf ice", 0);
      finiteInRange(seaRequest[i], "initial sea-mask shelf ice", 0);
      if (landRequest[i] > 0 && this.land[i] === 0 || seaRequest[i] > 0 && this.land[i] === 1) throw new RangeError("Ice shelf requires its thermal surface");
      demand += (landRequest[i] + seaRequest[i]) / n2;
    }
    const fraction = demand > 0 ? Math.min(1, this.oceanGlobalKgM2 / demand) : 0;
    if (this.config.compensatedOceanTransfers) this.addOceanWater(-Math.min(this.oceanGlobalKgM2, demand * fraction));
    else this.oceanGlobalKgM2 = Math.max(0, this.oceanGlobalKgM2 - demand * fraction);
    for (let i = 0; i < n2; i++) {
      this.shelfLandIceKgM2[i] += landRequest[i] * fraction;
      this.shelfSeaIceKgM2[i] += seaRequest[i] * fraction;
    }
  }
  seedLandIce(request) {
    const n2 = this.grid.count, remaining = new Float64Array(n2);
    let demand = 0;
    for (let i = 0; i < n2; i++) {
      let left = this.land[i] > 0 ? request[i] : 0;
      finiteInRange(left, "initial land ice", 0);
      for (const store of [this.snowKgM2, this.surfaceKgM2, this.soilKgM2]) {
        const amount = Math.min(left, store[i]);
        store[i] -= amount;
        this.addLandIce(i, amount);
        left -= amount;
      }
      remaining[i] = left;
      demand += left / n2;
    }
    const fraction = demand > 0 ? Math.min(1, this.oceanGlobalKgM2 / demand) : 0;
    this.addOceanWater(-demand * fraction);
    for (let i = 0; i < n2; i++) this.addLandIce(i, remaining[i] * fraction);
    this.diagnoseRouting();
  }
  /** Allocate generated ice from real stores, with no elapsed time or new water. */
  seedFrozen(snow2, ice2) {
    const n2 = this.grid.count;
    let demand = 0;
    const deficit = new Float64Array(n2);
    for (let i = 0; i < n2; i++) {
      const top = Math.min(snow2[i], this.surfaceKgM2[i]);
      const soil = Math.min(Math.max(0, snow2[i] - top), this.soilKgM2[i]), amount = top + soil;
      this.surfaceKgM2[i] -= top;
      this.soilKgM2[i] -= soil;
      this.snowKgM2[i] += amount;
      deficit[i] = Math.max(0, snow2[i] - amount);
      demand += (deficit[i] + ice2[i]) / n2;
    }
    const fraction = demand > 0 ? Math.min(1, this.oceanGlobalKgM2 / demand) : 0;
    this.addOceanWater(-demand * fraction);
    for (let i = 0; i < n2; i++) {
      this.snowKgM2[i] += deficit[i] * fraction;
      this.seaIceKgM2[i] += ice2[i] * fraction;
    }
    this.diagnoseRouting();
  }
  step(dt2, temperatureK, absorbedWm2, coupling) {
    if (this.pendingRouting) throw new Error("Attach restored terrain before advancing water");
    if (this.pendingGlacier) throw new Error("Attach restored glacier before advancing water");
    finiteInRange(dt2, "water time step", Number.MIN_VALUE, this.maxStepS * (1 + 1e-10));
    if (temperatureK.length !== this.grid.count || absorbedWm2.length !== this.grid.count) throw new RangeError("Water forcing grid mismatch");
    const n2 = this.grid.count, { config, land } = this;
    this.precipitationComponentsValid = false;
    for (const a of Object.values(this.precipitationComponents)) a.fill(0);
    for (const a of Object.values(this.transportRain)) a.fill(0);
    const split = !!(coupling?.landTemperatureK && coupling?.oceanTemperatureK);
    this.snowfallKgM2S ??= new Float64Array(n2);
    let oceanRequest = 0;
    coupling?.landHeatJm2?.fill(0);
    coupling?.oceanHeatJm2?.fill(0);
    for (let i = 0; i < n2; i++) {
      const t = temperatureK[i], q = absorbedWm2[i];
      finiteInRange(t, "water temperature", 0);
      finiteInRange(q, "absorbed sunlight", 0);
      const landT = coupling?.landTemperatureK?.[i] ?? t, oceanT = coupling?.oceanTemperatureK?.[i] ?? t;
      finiteInRange(landT, "land evaporation temperature", 0);
      finiteInRange(oceanT, "ocean evaporation temperature", 0);
      const landLiquid = Math.max(0, Math.min(1, (landT - 273.15) / 5)), oceanLiquid = config.liquidOceanEvaporation ? 1 : Math.max(0, Math.min(1, (oceanT - 273.15) / 5));
      const deficit = Math.max(0, 1 - this.atmosphereKgM2[i] / moistureCapacity(t));
      const potential = dt2 * config.evaporationFraction * q / VAPORIZATION_J_KG;
      if (this.surfaceSolver) {
        const e2 = this.surfaceSolver.evaporate(i, dt2, potential, deficit);
        this.atmosphereKgM2[i] += e2.landEvap + e2.lakeEvap;
        this.evaporationKgM2S[i] = (e2.landEvap + e2.lakeEvap) / dt2;
        this.oceanDemand[i] = e2.oceanDemand;
        oceanRequest += e2.oceanDemand / n2;
        continue;
      }
      const landDeficit = config.moistureScheme === "transport" && split ? Math.max(0, 1 - this.atmosphereKgM2[i] / moistureCapacity(landT)) : deficit;
      const oceanDeficit = config.moistureScheme === "transport" && split ? Math.max(0, 1 - this.atmosphereKgM2[i] / moistureCapacity(oceanT)) : deficit;
      const alb = coupling?.surfaceAlbedo, landPotential = alb && alb.mean[i] < 1 ? potential * (1 - alb.land[i]) / (1 - alb.mean[i]) : potential, oceanPotential = alb && alb.mean[i] < 1 ? potential * (1 - alb.ocean[i]) / (1 - alb.mean[i]) : potential;
      const landDemand = landPotential * landDeficit * landLiquid * land[i] * (coupling?.landEvaporation[i] ?? 1);
      const lakeDemand = oceanPotential * oceanDeficit * Math.max(0, Math.min(1, (oceanT - 273.15) / 5)) * this.inlandWaterFraction[i];
      const surface = Math.min(this.surfaceKgM2[i], landDemand + lakeDemand), lakeEvap = Math.min(surface, lakeDemand);
      const soil = Math.min(this.soilKgM2[i], Math.max(0, landDemand - (surface - lakeEvap)));
      this.surfaceKgM2[i] -= surface;
      this.soilKgM2[i] -= soil;
      this.atmosphereKgM2[i] += surface + soil;
      this.evaporationKgM2S[i] = (surface + soil) / dt2;
      if (split && coupling?.landHeatJm2 && coupling.oceanHeatJm2) {
        coupling.landHeatJm2[i] = -VAPORIZATION_J_KG * (surface - lakeEvap + soil);
        coupling.oceanHeatJm2[i] = -VAPORIZATION_J_KG * lakeEvap;
      }
      this.oceanDemand[i] = oceanPotential * oceanDeficit * oceanLiquid * (1 - land[i] - this.inlandWaterFraction[i]) * (1 - (coupling?.oceanFrozenCover?.[i] ?? coupling?.iceCover[i] ?? 0));
      oceanRequest += this.oceanDemand[i] / n2;
    }
    const fraction = oceanRequest > 0 ? Math.min(1, this.oceanGlobalKgM2 / oceanRequest) : 0;
    if (this.config.compensatedOceanTransfers) this.addOceanWater(-Math.min(this.oceanGlobalKgM2, oceanRequest * fraction));
    else this.oceanGlobalKgM2 = Math.max(0, this.oceanGlobalKgM2 - oceanRequest * fraction);
    for (let i = 0; i < n2; i++) {
      const amount = this.oceanDemand[i] * fraction;
      this.atmosphereKgM2[i] += amount;
      this.evaporationKgM2S[i] += amount / dt2;
      if (this.surfaceSolver) {
        this.surfaceSolver.oceanEvaporate(i, amount);
        continue;
      }
      if (split && coupling?.oceanHeatJm2) coupling.oceanHeatJm2[i] -= VAPORIZATION_J_KG * amount;
    }
    this.delta.fill(0);
    this.faceVaporTransportKgM2.fill(0);
    this.faceAdvectiveVaporKgM2.fill(0);
    this.faceDiffusiveVaporKgM2.fill(0);
    this.vaporTransportKgM2.set(this.atmosphereKgM2);
    const scales = this.heightM.map((h, i) => {
      if (!config.consistentLiftTemperature) return Math.max(0.55, Math.exp(-65e-4 * h * land[i] / 288.15));
      const scale2 = Math.max(0.55, Math.exp(-65e-4 * h / 288.15));
      return (land[i] / scale2 ** 4 + 1 - land[i]) ** -0.25;
    });
    const commonTemperature = Float64Array.from(temperatureK, (t, i) => t / scales[i]);
    const eddyFactor = (a, b, lat) => 1 + 9 * Math.min(1, Math.abs(commonTemperature[b] - commonTemperature[a]) / 8) * Math.max(0, (lat - 0.25) / 0.75);
    const orographicRain = new Float64Array(n2), frontalRain = new Float64Array(n2);
    if (config.moistureScheme === "transport") {
      const transferParcel = (k, from, to, amount, vapor2 = this.atmosphereKgM2[from], diffusive = false) => {
        const ascent = diffusive && config.upliftScheme ? 0 : Math.max(0, this.heightM[to] - this.heightM[from]);
        const uphillT = temperatureK[from] - 65e-4 * ascent;
        const orographicFraction = ascent > 0 && vapor2 > 0 ? land[to] * Math.max(0, 1 - moistureCapacity(uphillT) / vapor2) : 0;
        const cooling = Math.max(0, Math.min(temperatureK[from] - temperatureK[to], commonTemperature[from] - commonTemperature[to]));
        const frontLift = cooling * 98e-4 / (98e-4 - 65e-4);
        const totalFraction = cooling > 0 && vapor2 > 0 ? Math.max(orographicFraction, 1 - moistureCapacity(uphillT - frontLift) / vapor2) : orographicFraction;
        const mountain2 = amount * orographicFraction, front = amount * (totalFraction - orographicFraction);
        this.atmosphereKgM2[from] -= amount;
        this.atmosphereKgM2[to] += amount - mountain2 - front;
        const beforeFace = land[from] * mountain2;
        orographicRain[from] += beforeFace;
        orographicRain[to] += mountain2 - beforeFace;
        frontalRain[to] += front;
        const oro = diffusive ? this.transportRain.orographicDiffusion : this.transportRain.orographicAdvection, fr = diffusive ? this.transportRain.frontDiffusion : this.transportRain.frontAdvection;
        oro[from] += beforeFace / dt2;
        oro[to] += (mountain2 - beforeFace) / dt2;
        fr[to] += front / dt2;
        const flux = (from === this.grid.edges[k].a ? 1 : -1) * (amount - beforeFace);
        this.faceVaporTransportKgM2[k] += flux;
        (diffusive ? this.faceDiffusiveVaporKgM2 : this.faceAdvectiveVaporKgM2)[k] += flux;
      };
      const exchange = (k) => {
        const e2 = this.grid.edges[k], lat = Math.abs(this.grid.sinLat[Math.floor(e2.a / this.grid.width)]);
        const mixing = this.airRates[k] * eddyFactor(e2.a, e2.b, lat);
        const fraction2 = -Math.expm1(-mixing * dt2) / 2, a = this.atmosphereKgM2[e2.a], b = this.atmosphereKgM2[e2.b];
        if (config.upliftScheme === "advective") {
          const amount = fraction2 * (a - b);
          this.atmosphereKgM2[e2.a] -= amount;
          this.atmosphereKgM2[e2.b] += amount;
          this.faceVaporTransportKgM2[k] += amount;
          this.faceDiffusiveVaporKgM2[k] += amount;
        } else {
          transferParcel(k, e2.a, e2.b, fraction2 * a, a, true);
          transferParcel(k, e2.b, e2.a, fraction2 * b, b, true);
        }
      };
      const advect = (k) => {
        const e2 = this.grid.edges[k], rate = this.windRates[k], from = rate >= 0 ? e2.a : e2.b, to = rate >= 0 ? e2.b : e2.a;
        const displacement = -Math.expm1(-Math.abs(rate) * dt2 / 2);
        if (config.coldFrontDisplacement) {
          const contrast = Math.max(0, Math.min(temperatureK[to] - temperatureK[from], commonTemperature[to] - commonTemperature[from]));
          const lift = contrast * 98e-4 / (98e-4 - 65e-4), resident = this.atmosphereKgM2[to];
          const rain2 = contrast > 0 ? displacement * Math.max(0, resident - moistureCapacity(temperatureK[to] - lift)) : 0;
          this.atmosphereKgM2[to] -= rain2;
          frontalRain[to] += rain2;
          this.transportRain.coldFrontAdvection[to] += rain2 / dt2;
        }
        const vapor2 = this.atmosphereKgM2[from], amount = displacement * vapor2;
        transferParcel(k, from, to, amount);
      };
      for (let k = 0; k < this.grid.edges.length; k++) {
        exchange(k);
        advect(k);
      }
      for (let k = this.grid.edges.length - 1; k >= 0; k--) {
        advect(k);
        exchange(k);
      }
    } else {
      this.grid.edges.forEach((e2, k) => {
        const q = dt2 * this.airRates[k] * (this.atmosphereKgM2[e2.b] - this.atmosphereKgM2[e2.a]);
        this.delta[e2.a] += q;
        this.delta[e2.b] -= q;
        const rate = this.windRates[k], from = rate >= 0 ? e2.a : e2.b, to = rate >= 0 ? e2.b : e2.a;
        const amount = dt2 * Math.abs(rate) * this.atmosphereKgM2[from];
        this.delta[from] -= amount;
        this.delta[to] += amount;
        this.faceVaporTransportKgM2[k] += -q + (rate >= 0 ? amount : -amount);
        this.faceDiffusiveVaporKgM2[k] += -q;
        this.faceAdvectiveVaporKgM2[k] += rate >= 0 ? amount : -amount;
      });
    }
    const rainFraction = -Math.expm1(-dt2 / 21600), drainFraction = -Math.expm1(-dt2 / (3 * DAY));
    for (let i = 0; i < n2; i++) {
      this.atmosphereKgM2[i] += this.delta[i];
      this.vaporTransportKgM2[i] = this.atmosphereKgM2[i] - this.vaporTransportKgM2[i] + orographicRain[i] + frontalRain[i];
      const convergenceDay = Math.max(0, this.convergence[i]) * DAY;
      const parcelT = temperatureK[i];
      const heating = Math.max(0, Math.min(1, absorbedWm2[i] / 250));
      const humidity = this.atmosphereKgM2[i] / moistureCapacity(parcelT);
      const moistParcel = Math.max(0, Math.min(1, humidity));
      const subsidence = 16 * DAY * Math.max(0, -this.convergence[i]);
      const vapor2 = this.atmosphereKgM2[i], saturated = Math.max(0, vapor2 - moistureCapacity(parcelT)) * rainFraction;
      const cloud = (surface, depth) => {
        const buoyant = Math.max(0, Math.min(1, (surface - parcelT) / 8)), thermalInstability = Math.max(0, Math.min(1, (surface - 290) / 12)), unstable = config.buoyantConvection ? 1 : thermalInstability;
        const convection = depth * unstable * heating * moistParcel * buoyant, convergence = (6 + 10 * thermalInstability) * convergenceDay;
        const liftK = Math.max(0, Math.min(24, convection + convergence - subsidence)), rain3 = Math.max(0, vapor2 - moistureCapacity(parcelT - liftK)) * rainFraction, extra = Math.max(0, rain3 - saturated), requested = convection + convergence;
        return { rain: rain3, convection: requested > 0 ? extra * convection / requested : 0, convergence: requested > 0 ? extra * convergence / requested : 0 };
      };
      const modern = config.moistureScheme === "transport";
      const lc = modern ? cloud(coupling?.landTemperatureK?.[i] ?? temperatureK[i], 13) : { rain: saturated, convection: 0, convergence: 0 };
      const oc = modern ? cloud(coupling?.oceanTemperatureK?.[i] ?? temperatureK[i], 6.5) : { rain: saturated, convection: 0, convergence: 0 };
      const landColumn = land[i] * lc.rain, seaColumn = (1 - land[i]) * oc.rain, columnRain = modern ? landColumn + seaColumn : saturated;
      this.atmosphereKgM2[i] -= columnRain;
      const rain2 = columnRain + orographicRain[i] + frontalRain[i];
      this.precipitationKgM2S[i] = rain2 / dt2;
      const saturation = Math.min(columnRain, saturated);
      this.precipitationComponents.saturation[i] = saturation / dt2;
      this.precipitationComponents.orographic[i] = orographicRain[i] / dt2;
      this.precipitationComponents.front[i] = frontalRain[i] / dt2;
      this.precipitationComponents.convection[i] = (land[i] * lc.convection + (1 - land[i]) * oc.convection) / dt2;
      this.precipitationComponents.convergence[i] = (land[i] * lc.convergence + (1 - land[i]) * oc.convergence) / dt2;
      const landRain = modern ? landColumn + orographicRain[i] + land[i] * frontalRain[i] : rain2 * land[i], seaRain = modern ? seaColumn + (1 - land[i]) * frontalRain[i] : rain2 * (1 - land[i]);
      this.landPrecipitationKgM2S[i] = landRain / dt2;
      this.oceanPrecipitationKgM2S[i] = seaRain / dt2;
      this.landPrecipitationComponents.saturation[i] = land[i] * saturation / dt2;
      this.landPrecipitationComponents.convection[i] = land[i] * lc.convection / dt2;
      this.landPrecipitationComponents.convergence[i] = land[i] * lc.convergence / dt2;
      this.landPrecipitationComponents.front[i] = land[i] * frontalRain[i] / dt2;
      this.landPrecipitationComponents.orographic[i] = orographicRain[i] / dt2;
      if (this.surfaceSolver) {
        const snow3 = this.surfaceSolver.precipitate(i, rain2, dt2, modern ? landRain : void 0);
        this.snowfallKgM2S[i] = snow3 / dt2;
        if (coupling) coupling.heatJm2[i] = VAPORIZATION_J_KG * rain2 + FUSION_J_KG * snow3;
        continue;
      }
      const lakeRain = modern ? 1 - land[i] > 0 ? seaRain * this.inlandWaterFraction[i] / (1 - land[i]) : 0 : rain2 * this.inlandWaterFraction[i];
      this.addOceanWater((modern ? seaRain - lakeRain : rain2 * (1 - land[i] - this.inlandWaterFraction[i])) / n2);
      this.surfaceKgM2[i] += lakeRain;
      const phaseT = config.moistureScheme === "transport" && split ? coupling.landTemperatureK[i] : temperatureK[i];
      const snow2 = coupling && phaseT < 273.15 ? landRain : 0;
      this.snowfallKgM2S[i] = snow2 / dt2;
      this.snowKgM2[i] += snow2;
      if (coupling) coupling.heatJm2[i] = VAPORIZATION_J_KG * (rain2 - (split && coupling.landHeatJm2 && coupling.oceanHeatJm2 ? 0 : this.evaporationKgM2S[i] * dt2)) + FUSION_J_KG * snow2;
      const liquidRain = landRain - snow2;
      const capacity = config.soilCapacityKgM2 * land[i], infiltration = Math.min(liquidRain, capacity - this.soilKgM2[i]);
      this.soilKgM2[i] += infiltration;
      this.surfaceKgM2[i] += liquidRain - infiltration;
      const drainage = Math.max(0, this.soilKgM2[i] - 0.7 * capacity) * drainFraction;
      this.soilKgM2[i] -= drainage;
      this.surfaceKgM2[i] += drainage;
    }
    if (!coupling) this.routeSurface(dt2);
    this.elapsedS += dt2;
    this.precipitationComponentsValid = true;
    this.landPrecipitationKnown = true;
  }
  /** Reservoir routing, not a shallow-water solver. A basin has no forced
   * outlet; its stored head must exceed a neighboring saddle before spilling. */
  routeSurface(dt2) {
    if (this.pendingRouting) throw new Error("Attach restored terrain before routing water");
    if (this.routing) {
      this.routing.route(this, dt2, this.config.routingSpeedMps);
      return;
    }
    const n2 = this.grid.count;
    this.delta.fill(0);
    this.dischargeM3S.fill(0);
    const head = (i) => this.land[i] > 0 ? this.heightM[i] + this.surfaceKgM2[i] / (WATER_DENSITY * this.land[i]) : 0;
    for (let i = 0; i < n2; i++) {
      if (this.surfaceKgM2[i] <= 0 || this.land[i] === 0) continue;
      const sourceHead = head(i);
      let target = -1, best = sourceHead, distance = Math.sqrt(this.cellAreaM2), outletFraction = 1;
      if (this.land[i] < 1 && sourceHead > 0) {
        target = -2;
        best = 0;
        outletFraction = 1 - this.land[i];
      }
      for (const neighbor of this.neighbors[i]) {
        const f = this.land[neighbor.cell], h = head(neighbor.cell);
        if (f > 0 && h < best) {
          best = h;
          target = neighbor.cell;
          distance = neighbor.distanceM;
          outletFraction = f;
        }
        if (f < 1 && 0 < best) {
          best = 0;
          target = -2;
          distance = neighbor.distanceM;
          outletFraction = 1 - f;
        }
      }
      if (target === -1) continue;
      const inverseStorage = 1 / (WATER_DENSITY * this.land[i]) + (target >= 0 ? 1 / (WATER_DENSITY * this.land[target]) : 0);
      const available = Math.min(this.surfaceKgM2[i], (sourceHead - best) / inverseStorage);
      const amount = available * -Math.expm1(-dt2 * this.config.routingSpeedMps / distance) * outletFraction;
      this.delta[i] -= amount;
      if (target === -2) this.addOceanWater(amount / n2);
      else this.delta[target] += amount;
      this.dischargeM3S[i] = amount * this.cellAreaM2 / WATER_DENSITY / dt2;
    }
    for (let i = 0; i < n2; i++) this.surfaceKgM2[i] += this.delta[i];
  }
  checkpoint() {
    return {
      snowfallKgM2S: this.snowfallKgM2S?.slice() ?? null,
      atmosphereKgM2: this.atmosphereKgM2.slice(),
      soilKgM2: this.soilKgM2.slice(),
      surfaceKgM2: this.surfaceKgM2.slice(),
      ...this.config.moistureScheme === "transport" && this.landPrecipitationKnown ? { landPrecipitationKgM2S: this.landPrecipitationKgM2S.slice() } : {},
      precipitationKgM2S: this.precipitationKgM2S.slice(),
      evaporationKgM2S: this.evaporationKgM2S.slice(),
      dischargeM3S: this.dischargeM3S.slice(),
      snowKgM2: this.snowKgM2.slice(),
      seaIceKgM2: this.seaIceKgM2.slice(),
      meltKgM2S: this.meltKgM2S.slice(),
      oceanGlobalKgM2: this.oceanGlobalKgM2,
      ...this.config.compensatedOceanTransfers ? { oceanCorrection: this.oceanCorrection } : {},
      elapsedS: this.elapsedS,
      windEastMps: this.windEastMps.slice(),
      windNorthMps: this.windNorthMps.slice(),
      routing: this.routing?.checkpoint() ?? structuredClone(this.pendingRouting),
      landIceKgM2: this.landIceKgM2.slice(),
      landIceCorrection: this.landIceCorrection.slice(),
      glacier: this.glacier?.checkpoint() ?? structuredClone(this.pendingGlacier),
      shelfLandIceKgM2: this.shelfLandIceKgM2.slice(),
      shelfSeaIceKgM2: this.shelfSeaIceKgM2.slice()
    };
  }
  restore(state, oldRefinedLandEstimate2) {
    for (const a of [this.vaporTransportKgM2, this.faceVaporTransportKgM2, this.faceAdvectiveVaporKgM2, this.faceDiffusiveVaporKgM2]) a.fill(0);
    this.precipitationComponentsValid = false;
    for (const a of [...Object.values(this.precipitationComponents), ...Object.values(this.landPrecipitationComponents), ...Object.values(this.transportRain)]) a.fill(0);
    this.landPrecipitationKgM2S.fill(0);
    this.oceanPrecipitationKgM2S.fill(0);
    this.snowfallKgM2S = state.snowfallKgM2S?.slice() ?? null;
    for (const key of ["atmosphereKgM2", "soilKgM2", "surfaceKgM2", "precipitationKgM2S", "evaporationKgM2S", "dischargeM3S", "snowKgM2", "seaIceKgM2", "meltKgM2S"]) this[key].set(state[key]);
    this.landPrecipitationKnown = !!state.landPrecipitationKgM2S || !oldRefinedLandEstimate2;
    for (let i = 0; i < this.grid.count; i++) {
      this.landPrecipitationKgM2S[i] = state.landPrecipitationKgM2S?.[i] ?? oldRefinedLandEstimate2?.[i] ?? this.precipitationKgM2S[i] * this.land[i];
      this.oceanPrecipitationKgM2S[i] = Math.max(0, this.precipitationKgM2S[i] - this.landPrecipitationKgM2S[i]);
    }
    this.oceanGlobalKgM2 = state.oceanGlobalKgM2;
    this.oceanCorrection = this.config.compensatedOceanTransfers ? state.oceanCorrection ?? 0 : 0;
    this.elapsedS = state.elapsedS;
    this.setWinds(state.windEastMps, state.windNorthMps);
    this.landIceKgM2.set(state.landIceKgM2);
    this.landIceCorrection.set(state.landIceCorrection);
    this.shelfLandIceKgM2.set(state.shelfLandIceKgM2);
    this.shelfSeaIceKgM2.set(state.shelfSeaIceKgM2);
    if (state.glacier) {
      if (this.glacier) this.glacier.restore(state.glacier);
      else this.pendingGlacier = structuredClone(state.glacier);
    } else {
      this.glacier = null;
      this.pendingGlacier = null;
    }
    if (state.routing) {
      if (this.routing) this.routing.restore(state.routing, this);
      else this.pendingRouting = structuredClone(state.routing);
    } else {
      this.routing = null;
      this.pendingRouting = null;
    }
  }
  diagnostics() {
    const mean = (a) => a.reduce((sum3, v2) => sum3 + v2, 0) / this.grid.count, totalMm = this.total();
    return {
      shelfIceMm: mean(this.shelfLandIceKgM2) + mean(this.shelfSeaIceKgM2),
      landIceMm: mean(this.landIceKgM2),
      snowMm: mean(this.snowKgM2),
      iceMm: mean(this.seaIceKgM2),
      meltMmDay: DAY * mean(this.meltKgM2S),
      totalMm,
      residualMm: totalMm - this.initialTotalMm,
      atmosphereMm: mean(this.atmosphereKgM2),
      soilMm: mean(this.soilKgM2),
      surfaceMm: mean(this.surfaceKgM2),
      oceanMm: this.oceanGlobalKgM2,
      rainMmDay: DAY * mean(this.precipitationKgM2S),
      evaporationMmDay: DAY * mean(this.evaporationKgM2S),
      maxDischargeM3S: Math.max(...this.dischargeM3S)
    };
  }
};

// circulation.ts
function rotatingDrag(u4, v2, ax, ay, f, drag, dt2) {
  const d2 = drag * drag + f * f;
  if (d2 === 0) return [u4 + ax * dt2, v2 + ay * dt2];
  const x = (drag * ax + f * ay) / d2, y = (drag * ay - f * ax) / d2, decay = Math.exp(-drag * dt2), c = Math.cos(f * dt2), s = Math.sin(f * dt2);
  return [x + decay * (c * (u4 - x) + s * (v2 - y)), y + decay * (c * (v2 - y) - s * (u4 - x))];
}
var AtmosphericCirculation = class {
  constructor(thermal, water, scheme, boundaryLayerDepthM, pressureLayerDepthM) {
    this.thermal = thermal;
    this.water = water;
    this.scheme = scheme;
    this.boundaryLayerDepthM = boundaryLayerDepthM;
    this.pressureLayerDepthM = pressureLayerDepthM;
    if (scheme !== void 0 && !isCirculationScheme(scheme)) throw new Error("Invalid circulation scheme");
    if (scheme && (!thermal.config.separateReservoirs || water.config.moistureScheme !== "transport")) throw new Error("Pressure circulation requires separate transport reservoirs");
    if (boundaryLayerDepthM !== void 0 && (!fullWindDrag(scheme) || !Number.isFinite(boundaryLayerDepthM) || boundaryLayerDepthM < 100 || boundaryLayerDepthM > 5e3)) throw new Error("Invalid pressure boundary-layer depth");
    if (pressureLayerDepthM !== void 0 && (!scheme || !Number.isFinite(pressureLayerDepthM) || pressureLayerDepthM < 100 || pressureLayerDepthM > 5e3)) throw new Error("Invalid thermal pressure-layer depth");
    this.eastMps = new Float64Array(thermal.grid.count);
    this.northMps = new Float64Array(thermal.grid.count);
  }
  thermal;
  water;
  scheme;
  boundaryLayerDepthM;
  pressureLayerDepthM;
  eastMps;
  northMps;
  checkpoint() {
    return { eastMps: this.eastMps.slice(), northMps: this.northMps.slice() };
  }
  restore(s) {
    const n2 = this.thermal.grid.count, limit = this.perturbationLimit;
    if (s.eastMps.length !== n2 || s.northMps.length !== n2 || s.eastMps.some((v2, i) => !Number.isFinite(v2) || !Number.isFinite(s.northMps[i]) || Math.hypot(v2, s.northMps[i]) > limit + 1e-9)) throw new Error("Invalid circulation perturbation");
    this.eastMps.set(s.eastMps);
    this.northMps.set(s.northMps);
  }
  get fullDrag() {
    return fullWindDrag(this.scheme);
  }
  get balanced() {
    return this.scheme === "balanced-pressure" || this.scheme === "boundary-pressure";
  }
  get perturbationLimit() {
    return Math.abs(this.water.config.windMps) * circulationOffsetFactor(this.scheme, this.water.config.moistureScheme === "transport" && !!this.thermal.config.separateReservoirs);
  }
  validateWinds(timeS) {
    const m2 = this.thermal, w2 = this.water, limit = Math.abs(w2.config.windMps), base = circulationWinds(m2.grid, m2.planet, m2.orbit, timeS, w2.land, w2.config.windMps);
    for (let i = 0; i < m2.grid.count; i++) if (Math.abs(w2.windEastMps[i] - Math.max(-limit, Math.min(limit, base.eastMps[i] + this.eastMps[i]))) > 1e-10 || Math.abs(w2.windNorthMps[i] - Math.max(-limit, Math.min(limit, base.northMps[i] + this.northMps[i]))) > 1e-10) throw new Error("Saved wind does not match circulation memory");
  }
  step(dt2, timeS) {
    if (dt2 === 0) return;
    const m2 = this.thermal, w2 = this.water, g = m2.grid, { width, height } = g, r = m2.planet.radiusM, limit = Math.abs(w2.config.windMps);
    const modern = w2.config.moistureScheme === "transport" && m2.config.separateReservoirs;
    const pressureScale = this.pressureLayerDepthM === void 0 ? 50 : derivePlanet(m2.planet).gravityMps2 * this.pressureLayerDepthM / 288.15;
    const virtual = m2.temperatureK.map((_, i) => {
      const mixing = w2.atmosphereKgM2[i] / (m2.capacity[i] / 1004);
      return (mixing + 0.622) / (0.622 * (1 + mixing));
    });
    const commonSurface = m2.temperatureK.map((_, i) => (w2.land[i] * m2.landTemperatureK[i] / m2.radiationScale[i] + (1 - w2.land[i]) * m2.oceanTemperatureK[i]) * virtual[i]);
    const boundary = m2.temperatureK.map((t, i) => commonSurface[i] - t * (w2.land[i] / m2.radiationScale[i] ** 4 + 1 - w2.land[i]) ** 0.25 * virtual[i]);
    const marineBoundary = new Float64Array(height);
    const marine = new Float64Array(height), weight = new Float64Array(height), terrestrial = new Float64Array(height);
    if (modern) {
      for (let j = 0; j < height; j++) for (let x = 0; x < width; x++) {
        const i = j * width + x;
        weight[j] += 1 - w2.land[i];
        marine[j] += (1 - w2.land[i]) * m2.oceanTemperatureK[i] * virtual[i];
        marineBoundary[j] += (1 - w2.land[i]) * boundary[i];
        terrestrial[j] += m2.landTemperatureK[i] / m2.radiationScale[i] * virtual[i] / width;
      }
      for (let j = 0; j < height; j++) if (weight[j] > 0) {
        marine[j] /= weight[j];
        marineBoundary[j] /= weight[j];
      }
      for (let j = 0; j < height; j++) if (weight[j] === 0) {
        let north = j - 1, south = j + 1;
        while (north >= 0 && weight[north] === 0) north--;
        while (south < height && weight[south] === 0) south++;
        marine[j] = north >= 0 && south < height ? marine[north] + (marine[south] - marine[north]) * (g.sinLat[j] - g.sinLat[north]) / (g.sinLat[south] - g.sinLat[north]) : terrestrial[j];
        marineBoundary[j] = north >= 0 && south < height ? marineBoundary[north] + (marineBoundary[south] - marineBoundary[north]) * (g.sinLat[j] - g.sinLat[north]) / (g.sinLat[south] - g.sinLat[north]) : 0;
      }
    }
    const phi = m2.temperatureK.map((t, i) => {
      if (!modern) return -25 * t / m2.radiationScale[i];
      if (this.balanced) {
        const row = Math.floor(i / width);
        return -pressureScale * (this.scheme === "boundary-pressure" ? boundary[i] - marineBoundary[row] : commonSurface[i] - marine[row]);
      }
      if (this.scheme === "signed-pressure" || this.scheme === "thermal-pressure") {
        return -pressureScale * commonSurface[i];
      }
      const parcel = w2.land[i] * m2.landTemperatureK[i] + (1 - w2.land[i]) * m2.oceanTemperatureK[i];
      return -pressureScale * (marine[Math.floor(i / width)] + Math.max(0, parcel * virtual[i] - t));
    });
    const wind = circulationWinds(g, m2.planet, m2.orbit, timeS, w2.land, w2.config.windMps);
    const background = this.balanced ? circulationWinds(g, m2.planet, m2.orbit, timeS, new Float64Array(g.count), w2.config.windMps) : null;
    const omega = 2 * Math.PI / m2.planet.siderealPeriodS * (m2.planet.retrograde ? -1 : 1);
    for (let j = 0; j < height; j++) for (let x = 0; x < width; x++) {
      const i = j * width + x, lat = Math.asin(g.sinLat[j]), west = j * width + (x + width - 1) % width, east = j * width + (x + 1) % width;
      const north = Math.max(0, j - 1) * width + x, south = Math.min(height - 1, j + 1) * width + x;
      const dx = 2 * r * Math.cos(lat) * 2 * Math.PI / width, dy = r * (Math.asin(g.sinLat[Math.max(0, j - 1)]) - Math.asin(g.sinLat[Math.min(height - 1, j + 1)]));
      const ax = -(phi[east] - phi[west]) / dx, ay = -(phi[north] - phi[south]) / dy;
      const drag = (1 + 2 * w2.land[i]) / ((modern ? 0.25 : 2) * 86400), coriolis = 2 * omega * g.sinLat[j];
      const stress = this.boundaryLayerDepthM === void 0 ? 0 : ((1 - w2.land[i]) * 13e-4 + w2.land[i] * 3e-3) / this.boundaryLayerDepthM;
      const beforeDrag = this.boundaryLayerDepthM === void 0 ? 1 : 1 / (1 + stress * Math.hypot(w2.windEastMps[i], w2.windNorthMps[i]) * dt2 / 2);
      const bg = background?.eastMps[i] ?? 0, marineDrag = this.boundaryLayerDepthM === void 0 ? 1 / (0.25 * 86400) : 13e-4 * Math.abs(bg) / this.boundaryLayerDepthM;
      let [u4, v2] = this.fullDrag ? rotatingDrag(w2.windEastMps[i] * beforeDrag, w2.windNorthMps[i] * beforeDrag, ax + bg * marineDrag, ay + coriolis * bg, coriolis, this.boundaryLayerDepthM === void 0 ? drag : 0, dt2) : modern ? rotatingDrag(w2.windEastMps[i] - wind.eastMps[i], w2.windNorthMps[i], ax, ay, coriolis, drag, dt2) : rotatingDrag(this.eastMps[i], this.northMps[i], ax, ay, coriolis, drag, dt2);
      if (this.fullDrag) {
        if (this.boundaryLayerDepthM !== void 0) {
          const afterDrag = 1 / (1 + stress * Math.hypot(u4, v2) * dt2 / 2);
          u4 *= afterDrag;
          v2 *= afterDrag;
        }
        u4 = Math.max(-limit, Math.min(limit, u4));
        v2 = Math.max(-limit, Math.min(limit, v2));
        this.eastMps[i] = u4 - wind.eastMps[i];
        this.northMps[i] = v2 - wind.northMps[i];
        wind.eastMps[i] = u4;
        wind.northMps[i] = v2;
        continue;
      }
      if (modern) v2 -= wind.northMps[i];
      const scale2 = Math.min(1, this.perturbationLimit / Math.max(1e-30, Math.hypot(u4, v2)));
      u4 *= scale2;
      v2 *= scale2;
      this.eastMps[i] = u4;
      this.northMps[i] = v2;
      wind.eastMps[i] = Math.max(-limit, Math.min(limit, wind.eastMps[i] + u4));
      wind.northMps[i] = Math.max(-limit, Math.min(limit, wind.northMps[i] + v2));
    }
    w2.setWinds(wind.eastMps, wind.northMps);
  }
};

// ocean.ts
var OceanTransport = class {
  constructor(thermal, water, dynamic = false, underIce = false) {
    this.thermal = thermal;
    this.water = water;
    this.dynamic = dynamic;
    this.underIce = underIce;
    const { grid } = thermal, { width: w2, height: h, count: n2 } = grid;
    this.eastMps = new Float64Array(n2);
    this.northMps = new Float64Array(n2);
    this.heatWm2 = new Float64Array(n2);
    for (let j = 0; j < h; j++) for (let x = 0; x < w2; x++) this.faces.push({ a: j * w2 + x, b: j * w2 + (x + 1) % w2, east: true });
    for (let j = 0; j < h - 1; j++) for (let x = 0; x < w2; x++) this.faces.push({ a: j * w2 + x, b: (j + 1) * w2 + x, east: false });
    for (let j = 0; j < h - 1; j++) for (let x = 0; x < w2; x++) this.loops.push({
      cells: [j * w2 + x, j * w2 + (x + 1) % w2, (j + 1) * w2 + (x + 1) % w2, (j + 1) * w2 + x],
      faces: [j * w2 + x, n2 + j * w2 + (x + 1) % w2, (j + 1) * w2 + x, n2 + j * w2 + x],
      latitude: Math.asin(1 - 2 * (j + 1) / h),
      longitude: 2 * Math.PI * (x + 1) / w2
    });
    this.circulationMps = new Float64Array(this.loops.length);
  }
  thermal;
  water;
  dynamic;
  underIce;
  eastMps;
  northMps;
  heatWm2;
  faces = [];
  loops = [];
  circulationMps;
  checkpoint() {
    return this.dynamic ? { circulationMps: this.circulationMps.slice() } : null;
  }
  restore(s, strengthMps) {
    if (!this.dynamic || s.circulationMps.length !== this.loops.length || s.circulationMps.some((v2) => !Number.isFinite(v2) || Math.abs(v2) > strengthMps / 4 + 1e-12)) throw new Error("Invalid ocean circulation memory");
    this.circulationMps.set(s.circulationMps);
  }
  step(dt2, strengthMps) {
    const m2 = this.thermal, w2 = this.water, n2 = m2.grid.count, length = w2.radiusM * Math.sqrt(m2.grid.solidAngle);
    const capacity = m2.config.separateReservoirs ? m2.oceanCapacity : m2.capacity, temperature = m2.oceanTemperatureK;
    const waterCapacity = 42e5 * m2.config.oceanDepthM, flow = new Float64Array(this.faces.length), outgoing = new Float64Array(n2);
    for (let l = 0; l < this.loops.length; l++) {
      const loop = this.loops[l];
      const wet = w2.oceanGlobalKgM2 > 0 ? Math.min(...loop.cells.map((i) => this.underIce ? 1 - w2.land[i] : (1 - w2.land[i]) * Math.max(0, 1 - Math.max(w2.seaIceKgM2[i] / (917 * 0.5 * Math.max(1e-12, 1 - w2.land[i])), w2.shelfSeaIceKgM2[i] / (917 * 5 * Math.max(1e-12, 1 - w2.land[i])))))) : 0;
      const wind = loop.cells.reduce((sum3, i) => sum3 + w2.windEastMps[i], 0) / 4;
      let circulation = strengthMps * Math.tanh(wind / 5) * Math.sin(2 * loop.latitude) * Math.sin(loop.longitude) * wet / 4;
      if (this.dynamic) {
        const [a, b, c, d2] = loop.cells, u4 = w2.windEastMps, v2 = w2.windNorthMps;
        const windLoop = (u4[a] + u4[b] - u4[c] - u4[d2] - v2[b] - v2[c] + v2[d2] + v2[a]) / 8;
        const target = strengthMps * Math.tanh(windLoop / 2) / 4;
        if (dt2 > 0) this.circulationMps[l] += (target - this.circulationMps[l]) * -Math.expm1(-dt2 / (5 * 86400));
        circulation = this.circulationMps[l] * wet;
      }
      const q = waterCapacity * circulation / length;
      loop.faces.forEach((f, k) => {
        flow[f] += k < 2 ? q : -q;
      });
    }
    this.faces.forEach((e2, k) => {
      outgoing[flow[k] >= 0 ? e2.a : e2.b] += Math.abs(flow[k]);
    });
    let scale2 = 1;
    const transportStepS = dt2 || Math.min(m2.stepS, w2.maxStepS);
    for (let i = 0; i < n2; i++) if (outgoing[i] > 0) scale2 = Math.min(scale2, 0.45 * capacity[i] / (transportStepS * outgoing[i]));
    this.eastMps.fill(0);
    this.northMps.fill(0);
    this.heatWm2.fill(0);
    this.faces.forEach((e2, k) => {
      const q = flow[k] * scale2, donor = q >= 0 ? e2.a : e2.b, heat = q * (temperature[donor] - 273.15);
      this.heatWm2[e2.a] -= heat;
      this.heatWm2[e2.b] += heat;
      const velocity = q / waterCapacity * length, field2 = e2.east ? this.eastMps : this.northMps;
      field2[e2.a] += (e2.east ? 1 : -1) * velocity / 2;
      field2[e2.b] += (e2.east ? 1 : -1) * velocity / 2;
    });
    if (dt2 > 0) m2.applyOceanHeat(this.heatWm2.map((q) => q * dt2));
  }
};

// sea-ice-thermodynamics.ts
var SEA_ICE_FREEZE_K = 271.35;
var ICE_CONDUCTIVITY = 2.1656;
var ICE_DENSITY2 = 917;
var COVER_THICKNESS_M = 0.5;
var EXCHANGE = 10;
function seaIceSurfaceExchange(x) {
  const cover = x.marineArea > 0 ? Math.min(1, x.iceKgM2 / (ICE_DENSITY2 * COVER_THICKNESS_M * x.marineArea)) : 0;
  const iceArea = x.marineArea * cover, openArea = x.wetArea - iceArea;
  const waterAbsorptivity = 1 - (x.waterAlbedo ?? 0), iceAbsorptivity = 1 - (x.iceAlbedo ?? 0);
  const absorbedWeight = openArea * waterAbsorptivity + iceArea * iceAbsorptivity;
  const openShortwaveWm2 = absorbedWeight > 0 ? x.wetArea * x.absorbedWm2 * openArea * waterAbsorptivity / absorbedWeight : 0;
  const iceShortwaveWm2 = x.wetArea * x.absorbedWm2 - openShortwaveWm2;
  const iceSunshine = iceArea > 0 ? iceShortwaveWm2 / iceArea : 0;
  let waterK = x.waterK, airK = x.airK;
  const openRadiation = openShortwaveWm2 - openArea * x.emissivity * STEFAN_BOLTZMANN * waterK ** 4;
  waterK += x.dt * openRadiation / x.waterCapacity;
  const rate = EXCHANGE * openArea * (1 / x.airCapacity + 1 / x.waterCapacity);
  const openHeat = (waterK - airK) * -Math.expm1(-x.dt * rate) / (1 / x.airCapacity + 1 / x.waterCapacity);
  waterK -= openHeat / x.waterCapacity;
  airK += openHeat / x.airCapacity;
  if (iceArea === 0) return { waterK, airK, radiationWm2: openRadiation, openShortwaveWm2, iceShortwaveWm2, iceArea, skinK: SEA_ICE_FREEZE_K, conductiveWm2: 0, iceAirWm2: 0, iceOceanWm2: 0, balanceResidualWm2: 0 };
  const thickness = x.iceKgM2 / (ICE_DENSITY2 * iceArea), conductance = ICE_CONDUCTIVITY / thickness;
  const bottomK = Math.min(SEA_ICE_FREEZE_K, waterK);
  const balance = (t) => conductance * (bottomK - t) + iceSunshine - x.emissivity * STEFAN_BOLTZMANN * t ** 4 - EXCHANGE * (t - airK);
  let skinK = SEA_ICE_FREEZE_K;
  if (balance(skinK) < 0) {
    let lo = 0, hi = skinK;
    skinK = Math.min(skinK, Math.max(lo, airK));
    for (let j = 0; j < 20; j++) {
      const residual = balance(skinK);
      if (Math.abs(residual) < 1e-10) break;
      if (residual > 0) lo = skinK;
      else hi = skinK;
      const next2 = skinK + residual / (conductance + 4 * x.emissivity * STEFAN_BOLTZMANN * skinK ** 3 + EXCHANGE);
      skinK = next2 > lo && next2 < hi ? next2 : (lo + hi) / 2;
    }
  }
  const iceRadiation = iceShortwaveWm2 - iceArea * x.emissivity * STEFAN_BOLTZMANN * skinK ** 4;
  const iceAirWm2 = iceArea * EXCHANGE * (skinK - airK), iceOceanWm2 = iceRadiation - iceAirWm2;
  waterK += x.dt * iceOceanWm2 / x.waterCapacity;
  airK += x.dt * iceAirWm2 / x.airCapacity;
  const conductiveWm2 = iceArea * conductance * (bottomK - skinK);
  return {
    waterK,
    airK,
    radiationWm2: openRadiation + iceRadiation,
    openShortwaveWm2,
    iceShortwaveWm2,
    iceArea,
    skinK,
    conductiveWm2,
    iceAirWm2,
    iceOceanWm2,
    balanceResidualWm2: skinK < SEA_ICE_FREEZE_K ? iceOceanWm2 + conductiveWm2 : 0
  };
}

// environment.ts
var SEA_FREEZE_K = SEA_ICE_FREEZE_K;
var SNOW_MELT_K = 273.15;
var DEFAULT_ENVIRONMENT = Object.freeze({ oceanStrengthMps: 0.3, vegetation: true, iceAlbedo: true, terrainWater: false, glaciers: false, dynamicCirculation: false });
var clamp = (x) => Math.max(0, Math.min(1, x));
var EnvironmentModel = class {
  constructor(thermal, water, config, initialEnthalpy) {
    this.thermal = thermal;
    this.water = water;
    this.config = config;
    if (config.conductiveSeaIce && !thermal.config.separateReservoirs) throw new Error("Conductive sea ice requires separate thermal reservoirs");
    if (config.separateSurfaceAlbedo && !thermal.config.separateReservoirs) throw new Error("Separate surface albedo requires separate thermal reservoirs");
    const n2 = thermal.grid.count;
    this.ocean = new OceanTransport(thermal, water, !!config.dynamicCirculation, config.underIceOcean ?? !!config.conductiveSeaIce);
    this.seaIceHeat = config.conductiveSeaIce ? { iceArea: new Float64Array(n2), skinK: new Float64Array(n2), conductiveWm2: new Float64Array(n2), airWm2: new Float64Array(n2), oceanWm2: new Float64Array(n2), radiationWm2: new Float64Array(n2), balanceResidualWm2: new Float64Array(n2) } : null;
    thermal.oceanSurfaceSolver = config.conductiveSeaIce ? this : null;
    this.atmosphere = config.dynamicCirculation ? new AtmosphericCirculation(thermal, water, config.circulationScheme, config.boundaryLayerDepthM, config.pressureLayerDepthM) : null;
    if (config.glaciers) water.attachGlacier(derivePlanet(thermal.planet).gravityMps2);
    this.iceCover = new Float64Array(n2);
    this.snowCover = new Float64Array(n2);
    this.landEvaporation = new Float64Array(n2).fill(1);
    this.heatJm2 = new Float64Array(n2);
    this.vegetation = new Float64Array(n2).fill(0.5);
    this.glacierCover = new Float64Array(n2);
    this.shelfLandCover = new Float64Array(n2);
    this.shelfSeaCover = new Float64Array(n2);
    this.oceanFrozenCover = new Float64Array(n2);
    this.landHeatJm2 = new Float64Array(n2);
    this.oceanHeatJm2 = new Float64Array(n2);
    for (let i = 0; i < n2; i++) {
      if (thermal.config.separateReservoirs) {
        const landLimit = water.snowKgM2[i] > 0 || water.landIceKgM2[i] > 0 || water.shelfLandIceKgM2[i] > 0 ? SNOW_MELT_K : Infinity;
        const seaLimit = water.seaIceKgM2[i] > 0 ? SEA_FREEZE_K : water.shelfSeaIceKgM2[i] > 0 ? SNOW_MELT_K : Infinity;
        this.landHeatJm2[i] = Math.min(0, landLimit - thermal.landTemperatureK[i]) * thermal.landCapacity[i];
        const delta2 = water.seaIceKgM2[i] > 0 && water.oceanGlobalKgM2 > 0 ? seaLimit - thermal.oceanTemperatureK[i] : Math.min(0, seaLimit - thermal.oceanTemperatureK[i]);
        this.oceanHeatJm2[i] = delta2 * thermal.oceanCapacity[i];
        continue;
      }
      const limit = water.seaIceKgM2[i] > 0 ? SEA_FREEZE_K : water.snowKgM2[i] > 0 || water.landIceKgM2[i] > 0 || water.shelfLandIceKgM2[i] > 0 || water.shelfSeaIceKgM2[i] > 0 ? SNOW_MELT_K : Infinity;
      const delta = water.seaIceKgM2[i] > 0 && water.oceanGlobalKgM2 > 0 ? limit - thermal.temperatureK[i] : Math.min(0, limit - thermal.temperatureK[i]);
      this.heatJm2[i] = delta * thermal.capacity[i];
    }
    if (initialEnthalpy === void 0) {
      if (thermal.config.separateReservoirs) {
        thermal.applyLandHeat(this.landHeatJm2);
        thermal.applyOceanHeat(this.oceanHeatJm2);
      } else thermal.applyHeat(this.heatJm2);
    }
    this.initialEnthalpy = initialEnthalpy ?? this.enthalpy();
    this.refresh();
    this.ocean.step(0, config.oceanStrengthMps);
  }
  thermal;
  water;
  config;
  seaIceHeat;
  seaIceHeatTimeS = null;
  surfaceSolver = null;
  ocean;
  atmosphere;
  iceCover;
  snowCover;
  landEvaporation;
  glacierCover;
  shelfLandCover;
  shelfSeaCover;
  oceanFrozenCover;
  heatJm2;
  landHeatJm2;
  oceanHeatJm2;
  get landTemperatureK() {
    return this.thermal.config.separateReservoirs ? this.thermal.landTemperatureK : void 0;
  }
  get oceanTemperatureK() {
    return this.thermal.config.separateReservoirs ? this.thermal.oceanTemperatureK : void 0;
  }
  get surfaceAlbedo() {
    return this.thermal.surfaceAlbedo ? { ...this.thermal.surfaceAlbedo, mean: this.thermal.albedo } : void 0;
  }
  vegetation;
  initialEnthalpy;
  stepOceanSurface(k, dt2) {
    const m2 = this.thermal, w2 = this.water, wet = 1 - w2.land[k];
    const base = clamp(m2.orbit.bondAlbedo + (this.config.separateSurfaceAlbedo ? 0 : this.config.vegetation ? w2.land[k] * 0.06 * (0.5 - this.vegetation[k]) : 0));
    const absorbed = m2.surfaceAlbedo && m2.albedo[k] < 1 ? m2.absorbedWm2[k] * (1 - m2.surfaceAlbedo.ocean[k]) / (1 - m2.albedo[k]) : m2.absorbedWm2[k];
    const flux = seaIceSurfaceExchange({ wetArea: wet, marineArea: Math.max(0, wet - w2.inlandWaterFraction[k]), iceKgM2: w2.seaIceKgM2[k], waterK: m2.oceanTemperatureK[k], airK: m2.temperatureK[k], waterCapacity: m2.oceanCapacity[k], airCapacity: m2.capacity[k], absorbedWm2: absorbed, waterAlbedo: base, iceAlbedo: this.config.iceAlbedo ? Math.max(base, 0.65) : base, emissivity: (1 - (m2.config.airRadiationFraction ?? 0)) * m2.config.emissivity, dt: dt2 });
    m2.oceanTemperatureK[k] = flux.waterK;
    m2.temperatureK[k] = flux.airK;
    const d2 = this.seaIceHeat;
    d2.iceArea[k] = flux.iceArea;
    d2.skinK[k] = flux.skinK;
    d2.conductiveWm2[k] = flux.conductiveWm2;
    d2.airWm2[k] = flux.iceAirWm2;
    d2.oceanWm2[k] = flux.iceOceanWm2;
    d2.radiationWm2[k] = flux.radiationWm2;
    d2.balanceResidualWm2[k] = flux.balanceResidualWm2;
    return flux.radiationWm2;
  }
  checkpoint() {
    return this.atmosphere ? { atmosphere: this.atmosphere.checkpoint(), ocean: this.ocean.checkpoint() } : null;
  }
  restore(s) {
    this.seaIceHeatTimeS = null;
    if (this.seaIceHeat) for (const field2 of Object.values(this.seaIceHeat)) field2.fill(0);
    if (!!s !== !!this.atmosphere) throw new Error("Mismatched circulation state");
    if (s) {
      this.atmosphere.restore(s.atmosphere);
      this.ocean.restore(s.ocean, this.config.oceanStrengthMps);
    }
    this.ocean.step(0, this.config.oceanStrengthMps);
  }
  enthalpy() {
    const w2 = this.water;
    let sum3 = 0, correction = 0;
    for (let i = 0; i < w2.grid.count; i++) {
      const increment = (VAPORIZATION_J_KG * w2.atmosphereKgM2[i] - FUSION_J_KG * (w2.snowKgM2[i] + w2.seaIceKgM2[i] + w2.landIceKgM2[i] + w2.shelfLandIceKgM2[i] + w2.shelfSeaIceKgM2[i])) / w2.grid.count - correction, total = sum3 + increment;
      correction = total - sum3 - increment;
      sum3 = total;
    }
    return this.thermal.energy() + sum3;
  }
  refresh(vegetation) {
    const m2 = this.thermal, w2 = this.water;
    if (this.config.separateSurfaceAlbedo) m2.surfaceAlbedo ??= { land: new Float64Array(w2.grid.count), ocean: new Float64Array(w2.grid.count) };
    else m2.surfaceAlbedo = null;
    if (vegetation) this.vegetation.set(vegetation);
    for (let i = 0; i < w2.grid.count; i++) {
      const f = w2.land[i], v2 = this.vegetation[i];
      this.iceCover[i] = f < 1 ? clamp(w2.seaIceKgM2[i] / ((1 - f) * 917 * 0.5)) : 0;
      this.snowCover[i] = f > 0 ? clamp(w2.snowKgM2[i] / (f * 30)) : 0;
      this.glacierCover[i] = f > 0 ? clamp(w2.landIceKgM2[i] / (f * 917 * 5)) : 0;
      this.shelfLandCover[i] = f > 0 ? clamp(w2.shelfLandIceKgM2[i] / (f * 917 * 5)) : 0;
      this.shelfSeaCover[i] = f < 1 ? clamp(w2.shelfSeaIceKgM2[i] / ((1 - f) * 917 * 5)) : 0;
      this.oceanFrozenCover[i] = Math.max(this.iceCover[i], this.shelfSeaCover[i]);
      const landFrozen = Math.max(this.snowCover[i], this.glacierCover[i], this.shelfLandCover[i]), frozen = f * landFrozen + (1 - f) * this.oceanFrozenCover[i];
      const base = clamp(m2.orbit.bondAlbedo + (this.config.vegetation ? f * 0.06 * (0.5 - v2) : 0));
      m2.albedo[i] = this.config.iceAlbedo ? base + (Math.max(base, 0.65) - base) * frozen : base;
      if (m2.surfaceAlbedo) {
        const lb = clamp(m2.orbit.bondAlbedo + (this.config.vegetation ? 0.06 * (0.5 - v2) : 0)), sb = m2.orbit.bondAlbedo;
        m2.surfaceAlbedo.land[i] = this.config.iceAlbedo ? lb + (Math.max(lb, 0.65) - lb) * landFrozen : lb;
        m2.surfaceAlbedo.ocean[i] = this.config.iceAlbedo ? sb + (Math.max(sb, 0.65) - sb) * this.oceanFrozenCover[i] : sb;
        m2.albedo[i] = f * m2.surfaceAlbedo.land[i] + (1 - f) * m2.surfaceAlbedo.ocean[i];
      }
      this.landEvaporation[i] = this.config.vegetation ? (0.6 + 0.4 * v2) * (1 - landFrozen) : 1 - landFrozen;
    }
    this.surfaceSolver?.refresh();
  }
  /** Project available sensible heat into phase changes, conserving enthalpy. */
  phase(dt2) {
    if (this.surfaceSolver) {
      this.surfaceSolver.phase(dt2);
      return;
    }
    if (this.thermal.config.separateReservoirs) {
      this.phaseSeparated(dt2);
      return;
    }
    const m2 = this.thermal, w2 = this.water, n2 = w2.grid.count;
    this.heatJm2.fill(0);
    let freezeRequest = 0;
    const freeze = new Float64Array(n2);
    for (let i = 0; i < n2; i++) {
      const c = m2.capacity[i];
      let t = m2.temperatureK[i];
      const snow2 = Math.min(w2.snowKgM2[i], Math.max(0, (t - SNOW_MELT_K) * c / FUSION_J_KG));
      w2.snowKgM2[i] -= snow2;
      w2.surfaceKgM2[i] += snow2;
      w2.meltKgM2S[i] += snow2 / dt2;
      t -= snow2 * FUSION_J_KG / c;
      this.heatJm2[i] -= snow2 * FUSION_J_KG;
      const glacier = Math.min(w2.landIceKgM2[i], Math.max(0, (t - SNOW_MELT_K) * c / FUSION_J_KG));
      w2.addLandIce(i, -glacier);
      w2.surfaceKgM2[i] += glacier;
      w2.meltKgM2S[i] += glacier / dt2;
      t -= glacier * FUSION_J_KG / c;
      this.heatJm2[i] -= glacier * FUSION_J_KG;
      for (const shelf of [w2.shelfLandIceKgM2, w2.shelfSeaIceKgM2]) {
        const melt = Math.min(shelf[i], Math.max(0, (t - SNOW_MELT_K) * c / FUSION_J_KG));
        shelf[i] -= melt;
        w2.addOceanWater(melt / n2);
        t -= melt * FUSION_J_KG / c;
        this.heatJm2[i] -= melt * FUSION_J_KG;
      }
      const ice2 = Math.min(w2.seaIceKgM2[i], Math.max(0, (t - SEA_FREEZE_K) * c / FUSION_J_KG));
      w2.seaIceKgM2[i] -= ice2;
      w2.addOceanWater(ice2 / n2);
      t -= ice2 * FUSION_J_KG / c;
      this.heatJm2[i] -= ice2 * FUSION_J_KG;
      freeze[i] = Math.max(0, (SEA_FREEZE_K - t) * c / FUSION_J_KG) * (1 - w2.land[i] - w2.inlandWaterFraction[i]);
      freezeRequest += freeze[i] / n2;
    }
    const fraction = freezeRequest > 0 ? Math.min(1, w2.oceanGlobalKgM2 / freezeRequest) : 0;
    w2.addOceanWater(-freezeRequest * fraction);
    for (let i = 0; i < n2; i++) {
      const amount = freeze[i] * fraction;
      w2.seaIceKgM2[i] += amount;
      this.heatJm2[i] += amount * FUSION_J_KG;
    }
    m2.applyHeat(this.heatJm2);
  }
  phaseSeparated(dt2) {
    const m2 = this.thermal, w2 = this.water, n2 = w2.grid.count;
    this.heatJm2.fill(0);
    this.landHeatJm2.fill(0);
    this.oceanHeatJm2.fill(0);
    const freeze = new Float64Array(n2);
    let freezeRequest = 0;
    for (let i = 0; i < n2; i++) {
      const lc = m2.landCapacity[i], oc = m2.oceanCapacity[i];
      let lt = m2.landTemperatureK[i], ot = m2.oceanTemperatureK[i];
      if (lc > 0) {
        const snow2 = Math.min(w2.snowKgM2[i], Math.max(0, (lt - SNOW_MELT_K) * lc / FUSION_J_KG));
        w2.snowKgM2[i] -= snow2;
        w2.surfaceKgM2[i] += snow2;
        w2.meltKgM2S[i] += snow2 / dt2;
        lt -= snow2 * FUSION_J_KG / lc;
        this.landHeatJm2[i] -= snow2 * FUSION_J_KG;
        const glacier = Math.min(w2.landIceKgM2[i], Math.max(0, (lt - SNOW_MELT_K) * lc / FUSION_J_KG));
        w2.addLandIce(i, -glacier);
        w2.surfaceKgM2[i] += glacier;
        w2.meltKgM2S[i] += glacier / dt2;
        lt -= glacier * FUSION_J_KG / lc;
        this.landHeatJm2[i] -= glacier * FUSION_J_KG;
        const shelf = Math.min(w2.shelfLandIceKgM2[i], Math.max(0, (lt - SNOW_MELT_K) * lc / FUSION_J_KG));
        w2.shelfLandIceKgM2[i] -= shelf;
        w2.addOceanWater(shelf / n2);
        this.landHeatJm2[i] -= shelf * FUSION_J_KG;
      }
      if (oc > 0) {
        const shelf = Math.min(w2.shelfSeaIceKgM2[i], Math.max(0, (ot - SNOW_MELT_K) * oc / FUSION_J_KG));
        w2.shelfSeaIceKgM2[i] -= shelf;
        w2.addOceanWater(shelf / n2);
        ot -= shelf * FUSION_J_KG / oc;
        this.oceanHeatJm2[i] -= shelf * FUSION_J_KG;
        const ice2 = Math.min(w2.seaIceKgM2[i], Math.max(0, (ot - SEA_FREEZE_K) * oc / FUSION_J_KG));
        w2.seaIceKgM2[i] -= ice2;
        w2.addOceanWater(ice2 / n2);
        ot -= ice2 * FUSION_J_KG / oc;
        this.oceanHeatJm2[i] -= ice2 * FUSION_J_KG;
        const wet = 1 - w2.land[i], open = wet > 0 ? (wet - w2.inlandWaterFraction[i]) / wet : 0;
        freeze[i] = Math.max(0, (SEA_FREEZE_K - ot) * oc / FUSION_J_KG) * open;
        freezeRequest += freeze[i] / n2;
      }
    }
    const fraction = freezeRequest > 0 ? Math.min(1, w2.oceanGlobalKgM2 / freezeRequest) : 0;
    w2.addOceanWater(-freezeRequest * fraction);
    for (let i = 0; i < n2; i++) {
      const amount = freeze[i] * fraction;
      w2.seaIceKgM2[i] += amount;
      this.oceanHeatJm2[i] += amount * FUSION_J_KG;
    }
    m2.applyLandHeat(this.landHeatJm2);
    m2.applyOceanHeat(this.oceanHeatJm2);
  }
  step(dt2) {
    const m2 = this.thermal, w2 = this.water;
    this.surfaceSolver?.resetRates();
    w2.meltKgM2S.fill(0);
    this.ocean.step(dt2, this.config.oceanStrengthMps);
    this.phase(dt2);
    this.refresh();
    w2.step(dt2, m2.temperatureK, m2.absorbedWm2, this);
    m2.applyHeat(this.heatJm2);
    if (m2.config.separateReservoirs) {
      m2.applyLandHeat(this.landHeatJm2);
      m2.applyOceanHeat(this.oceanHeatJm2);
    }
    this.phase(dt2);
    this.surfaceSolver?.compact(dt2);
    w2.glacier?.step(dt2, m2.landTemperatureK);
    if (this.surfaceSolver) {
      this.surfaceSolver.reconcileIce();
      this.surfaceSolver.route(dt2);
    } else w2.routeSurface(dt2);
    if (this.seaIceHeat) this.seaIceHeatTimeS = m2.timeS + dt2;
  }
  diagnostics() {
    const m2 = this.thermal, w2 = this.water, n2 = w2.grid.count;
    let land = 0, wet = 0, ice2 = 0, snow2 = 0, albedo = 0, current = 0;
    for (let i = 0; i < n2; i++) {
      land += w2.land[i];
      wet += 1 - w2.land[i];
      snow2 += w2.land[i] * this.snowCover[i];
      ice2 += (1 - w2.land[i]) * this.iceCover[i];
      albedo += m2.albedo[i];
      current = Math.max(current, Math.hypot(this.ocean.eastMps[i], this.ocean.northMps[i]));
    }
    return { energyResidualJm2: this.enthalpy() - this.initialEnthalpy - m2.radiationJm2, iceFraction: wet ? ice2 / wet : 0, snowFraction: land ? snow2 / land : 0, albedo: albedo / n2, maxCurrentMps: current };
  }
};

// surface-grid.ts
var SURFACE_WIDTH = 96;
var SURFACE_HEIGHT = 49;
function makeSurfaceGrid(width = SURFACE_WIDTH, height = SURFACE_HEIGHT) {
  const edges = [];
  for (let j = 0; j < height; j++) for (let x = 0; x < width; x++) {
    const a = j * width + x;
    edges.push({ a, b: j * width + (x + 1) % width });
    if (j + 1 < height) edges.push({ a, b: a + width });
  }
  return { width, height, count: width * height, sinLat: Float64Array.from({ length: height }, (_, j) => Math.cos(Math.PI * j / (height - 1))), edges };
}
function surfaceCell(grid, u4, v2) {
  const j = Math.max(0, Math.min(grid.height - 1, Math.round(v2 * (grid.height - 1))));
  return j * grid.width + (j === 0 || j === grid.height - 1 ? 0 : Math.floor((u4 % 1 + 1) % 1 * grid.width));
}
var SurfaceTerrainSampler = class {
  constructor(directions, grid) {
    this.directions = directions;
    this.grid = grid;
    const { width, height, count } = grid, n2 = directions.length / 3;
    this.bins = Array.from({ length: count }, () => []);
    for (let r = 0; r < n2; r++) {
      const u4 = 0.5 + Math.atan2(directions[3 * r], directions[3 * r + 2]) / (2 * Math.PI);
      const v2 = Math.acos(Math.max(-1, Math.min(1, directions[3 * r + 1]))) / Math.PI;
      this.bins[surfaceCell(grid, u4, v2)].push(r);
    }
    const sourceBins = this.bins.slice();
    this.heightSamples = Array.from({ length: count }, () => []);
    for (let k = 0; k < count; k++) {
      const j = Math.floor(k / width), pole = j === 0 || j === height - 1;
      if (pole && k % width) {
        this.bins[k] = this.bins[j * width];
        this.heightSamples[k] = this.heightSamples[j * width];
        continue;
      }
      const y = grid.sinLat[j], lon = ((k % width + 0.5) / width - 0.5) * 2 * Math.PI;
      const radius = Math.sqrt(Math.max(0, 1 - y * y)), x = radius * Math.sin(lon), z = radius * Math.cos(lon);
      const nearest = [];
      const consider = (r) => {
        const dot = x * directions[3 * r] + y * directions[3 * r + 1] + z * directions[3 * r + 2];
        if (nearest.length < 4 || dot > nearest[nearest.length - 1].dot) {
          nearest.push({ region: r, dot });
          nearest.sort((a, b) => b.dot - a.dot);
          if (nearest.length > 4) nearest.pop();
        }
      };
      const angle = Math.PI / (height - 1), reachesPole = angle >= Math.acos(Math.abs(y));
      const longitudeRadius = reachesPole ? Math.PI : Math.asin(Math.min(1, Math.sin(angle) / radius));
      const columns = Math.min(width, 2 * (Math.ceil(longitudeRadius / (2 * Math.PI / width)) + 1) + 1);
      const first = columns === width ? 0 : k % width - Math.floor(columns / 2);
      for (let row = Math.max(0, j - 2); row <= Math.min(height - 1, j + 2); row++) {
        if (row === 0 || row === height - 1) {
          for (const r of sourceBins[row * width]) consider(r);
          continue;
        }
        for (let dx = 0; dx < columns; dx++) for (const r of sourceBins[row * width + ((first + dx) % width + width) % width]) consider(r);
      }
      if (nearest.length < 4 || nearest[3].dot < Math.cos(angle)) {
        nearest.length = 0;
        for (let r = 0; r < n2; r++) consider(r);
      }
      if (!this.bins[k].length || pole) this.bins[k] = [nearest[0].region];
      this.heightSamples[k] = pole ? [{ region: nearest[0].region, weight: 1 }] : nearest.map((p2) => ({ region: p2.region, weight: 1 / Math.max(1e-12, 1 - p2.dot) }));
    }
  }
  directions;
  grid;
  bins;
  heightSamples;
  sample(elevation2) {
    const land = new Float64Array(this.grid.count), height = new Float64Array(this.grid.count);
    for (let k = 0; k < this.grid.count; k++) {
      for (const r of this.bins[k]) land[k] += elevation2[r] > 0 ? 1 : 0;
      land[k] /= this.bins[k].length;
      let weight = 0;
      if (land[k] > 0) {
        for (const sample of this.heightSamples[k]) if (elevation2[sample.region] > 0) {
          height[k] += sample.weight * Math.min(1, elevation2[sample.region]);
          weight += sample.weight;
        }
      }
      height[k] = weight > 0 ? height[k] / weight : 0;
    }
    return { land, height };
  }
};
function resampleClimateField(grid, field2, target) {
  const result = new Float64Array(target.count), w2 = grid.width, h = grid.height;
  let north = 0, south = 0;
  for (let x = 0; x < w2; x++) {
    north += field2[x] / w2;
    south += field2[(h - 1) * w2 + x] / w2;
  }
  for (let j = 0; j < target.height; j++) for (let x = 0; x < target.width; x++) {
    const sx = (x + 0.5) / target.width * w2 - 0.5, sy = (1 - target.sinLat[j]) * 0.5 * h - 0.5;
    const x0 = Math.floor(sx), fx = sx - x0, y0 = Math.floor(sy), fy = sy - y0;
    const row = (y) => {
      const k = Math.max(0, Math.min(h - 1, y)) * w2;
      return field2[k + (x0 + w2) % w2] * (1 - fx) + field2[k + (x0 + 1) % w2] * fx;
    };
    let value = row(y0) * (1 - fy) + row(y0 + 1) * fy;
    if (sy < 0) value = north + (value - north) * (sy + 0.5) * 2;
    if (sy > h - 1) value = south + (value - south) * (h - 0.5 - sy) * 2;
    result[j * target.width + x] = value;
  }
  return result;
}

// reference-moisture.ts
var cache = /* @__PURE__ */ new Map();
var DAY2 = 86400;
function referenceMoisture(target, planet, orbit, thermal, water, land, heightM, environmentConfig2 = DEFAULT_ENVIRONMENT, maxStepS = 21600) {
  finiteInRange(maxStepS, "reference maximum step", Number.MIN_VALUE);
  const annualOrbit = { ...orbit, orbitPhaseRad: 0, spinPhaseRad: 0 };
  const key = JSON.stringify([target.width, target.height, planet, annualOrbit, thermal, water, environmentConfig2, maxStepS, Array.from(land), Array.from(heightM)]);
  const known = cache.get(key);
  if (known) return known;
  const physical = "solidAngle" in target, grid = physical ? target : makeThermalGrid();
  let f = Float64Array.from(land), h = Float64Array.from(heightM);
  if (!physical) {
    f = new Float64Array(grid.count);
    h = new Float64Array(grid.count);
    const weights2 = new Float64Array(grid.count);
    for (let j = 0; j < target.height; j++) for (let x = 0; x < target.width; x++) {
      const row = Math.max(0, Math.min(grid.height - 1, Math.floor((1 - target.sinLat[j]) * grid.height / 2)));
      const k = row * grid.width + Math.floor((x + 0.5) * grid.width / target.width), i = j * target.width + x;
      const a = Math.cos(Math.PI * Math.max(0, (j - 0.5) / (target.height - 1))) - Math.cos(Math.PI * Math.min(1, (j + 0.5) / (target.height - 1)));
      weights2[k] += a;
      f[k] += a * land[i];
      h[k] += a * land[i] * heightM[i];
    }
    for (let i = 0; i < grid.count; i++) {
      h[i] = f[i] > 0 ? h[i] / f[i] : 0;
      f[i] = weights2[i] > 0 ? f[i] / weights2[i] : 0;
    }
  }
  const { yearS } = deriveOrbit(planet, orbit), zero = () => new Float64Array(grid.count), ones = () => zero().fill(1);
  const forcing = generateThermalClimate(grid, planet, annualOrbit, thermal, water, f, h, 0);
  const model = new ThermalModel(planet, annualOrbit, { ...thermal, separateReservoirs: true }, f, 0, grid, forcing);
  const w2 = new WaterModel(grid, planet.radiusM, f, h, forcing.temperatureK, water, { ...forcing, rainMmDay: zero(), evaporationMmDay: zero(), soilFraction: zero(), humidityFraction: zero(), surfaceMm: zero() });
  const effectiveStep = Math.min(maxStepS, w2.maxStepS);
  const fallbackCount = Math.max(1, Math.min(2048, Math.floor(3e7 / Math.max(1, grid.edges.length))));
  const initial2 = w2.diagnostics().totalMm, period = Math.min(yearS, 366 * DAY2, fallbackCount * effectiveStep);
  const count = Math.min(fallbackCount, Math.ceil(period / effectiveStep)), dt2 = period / count;
  const atmosphere = environmentConfig2.dynamicCirculation ? new AtmosphericCirculation(model, w2) : null;
  const samples = Array.from({ length: 48 }, (_, s) => {
    const t = s * yearS / 48, air = generateThermalClimate(grid, planet, annualOrbit, thermal, water, f, h, t);
    const ground = generateThermalClimate(grid, planet, annualOrbit, thermal, water, ones(), h, t);
    const sea = generateThermalClimate(grid, planet, annualOrbit, thermal, water, zero(), zero(), t);
    return { air, ground: ground.temperatureK, sea: sea.temperatureK };
  });
  const coupling = { heatJm2: zero(), landHeatJm2: zero(), oceanHeatJm2: zero(), landEvaporation: ones().fill(0.8), iceCover: zero(), oceanFrozenCover: zero(), landTemperatureK: model.landTemperatureK, oceanTemperatureK: model.oceanTemperatureK };
  const fields = ["atmosphereKgM2", "rainMmDay", "evaporationMmDay", "soilFraction", "humidityFraction", "surfaceMm", "temperatureK", "landTemperatureK", "oceanTemperatureK", "windEastMps", "windNorthMps"];
  const months = Array.from({ length: 12 }, () => Object.fromEntries(fields.map((k) => [k, zero()])));
  const coupledStep = Math.min(maxStepS, model.stepS, w2.maxStepS, yearS / 720);
  if (2 * Math.ceil(yearS / coupledStep) <= 262144 && 2 * Math.ceil(yearS / coupledStep) * grid.edges.length <= 6e8) {
    model.stepS = yearS / Math.ceil(yearS / coupledStep);
    const environment = new EnvironmentModel(model, w2, { ...environmentConfig2, terrainWater: false, glaciers: false });
    const steps = 2 * Math.ceil(yearS / coupledStep);
    model.advanceTo(steps * model.stepS, steps, (delta) => {
      if (environment.atmosphere) environment.atmosphere.step(delta, model.timeS + delta / 2);
      else {
        const wind = circulationWinds(grid, planet, annualOrbit, model.timeS + delta / 2, f, water.windMps);
        w2.setWinds(wind.eastMps, wind.northMps);
      }
      environment.step(delta);
      for (let cursor = Math.max(yearS, model.timeS), right = Math.min(2 * yearS, model.timeS + delta); cursor < right; ) {
        const month = Math.min(11, Math.floor((cursor - yearS) / (yearS / 12) + 1e-10)), next2 = Math.min(right, yearS + (month + 1) * yearS / 12), weight = (next2 - cursor) / (yearS / 12), out2 = months[month];
        for (let i = 0; i < grid.count; i++) {
          out2.atmosphereKgM2[i] += weight * w2.atmosphereKgM2[i];
          out2.rainMmDay[i] += w2.precipitationKgM2S[i] * DAY2 * weight;
          out2.evaporationMmDay[i] += w2.evaporationKgM2S[i] * DAY2 * weight;
          out2.soilFraction[i] += weight * (f[i] > 0 ? w2.soilKgM2[i] / (water.soilCapacityKgM2 * f[i]) : 0);
          out2.humidityFraction[i] += weight * Math.min(1, w2.atmosphereKgM2[i] / moistureCapacity(model.temperatureK[i]));
          out2.surfaceMm[i] += weight * (f[i] > 0 ? w2.surfaceKgM2[i] / f[i] : 0);
          out2.temperatureK[i] += weight * model.temperatureK[i];
          out2.landTemperatureK[i] += weight * model.landTemperatureK[i];
          out2.oceanTemperatureK[i] += weight * model.oceanTemperatureK[i];
          out2.windEastMps[i] += weight * w2.windEastMps[i];
          out2.windNorthMps[i] += weight * w2.windNorthMps[i];
        }
        cursor = next2;
      }
    });
    for (const month of months) for (const name of ["soilFraction", "humidityFraction"]) for (let i = 0; i < grid.count; i++) month[name][i] = Math.max(0, Math.min(1, month[name][i]));
    const result2 = { months: physical ? months : months.map((month) => Object.fromEntries(Object.entries(month).map(([name, values]) => [name, resampleClimateField(grid, values, target)]))), waterResidualMm: w2.diagnostics().totalMm - initial2, externalLatentHeatJm2: 0, energyResidualJm2: environment.diagnostics().energyResidualJm2, coupled: true, integratedYearS: yearS, forcingYearS: yearS, spinupYearS: yearS, referenceRadiusM: planet.radiusM, steps };
    cache.set(key, result2);
    if (cache.size > 4) cache.delete(cache.keys().next().value);
    return result2;
  }
  let externalLatentHeatJm2 = 0;
  for (let step2 = 0; step2 < 2 * count; step2++) {
    const phase2 = (step2 + 0.5) % count / count, s = phase2 * 48, a = Math.floor(s), b = (a + 1) % 48, blend = s - a, left = samples[a], right = samples[b];
    for (let i = 0; i < grid.count; i++) {
      model.temperatureK[i] = left.air.temperatureK[i] * (1 - blend) + right.air.temperatureK[i] * blend;
      model.landTemperatureK[i] = left.ground[i] * (1 - blend) + right.ground[i] * blend;
      model.oceanTemperatureK[i] = left.sea[i] * (1 - blend) + right.sea[i] * blend;
      model.absorbedWm2[i] = left.air.absorbedWm2[i] * (1 - blend) + right.air.absorbedWm2[i] * blend;
      coupling.oceanFrozenCover[i] = model.oceanTemperatureK[i] < 271.35 ? 1 : 0;
      coupling.landEvaporation[i] = model.landTemperatureK[i] < 273.15 ? 0 : 0.8;
      const melt = Math.min(w2.snowKgM2[i], model.landTemperatureK[i] > 273.15 ? dt2 * model.absorbedWm2[i] * f[i] / 334e3 : 0);
      w2.snowKgM2[i] -= melt;
      w2.surfaceKgM2[i] += melt;
      externalLatentHeatJm2 -= 334e3 * melt / grid.count;
    }
    if (atmosphere) atmosphere.step(dt2, phase2 * yearS);
    else {
      const wind = circulationWinds(grid, planet, annualOrbit, phase2 * yearS, f, water.windMps);
      w2.setWinds(wind.eastMps, wind.northMps);
    }
    w2.step(dt2, model.temperatureK, model.absorbedWm2, coupling);
    w2.routeSurface(dt2);
    externalLatentHeatJm2 += (coupling.heatJm2.reduce((s2, v2) => s2 + v2, 0) + coupling.landHeatJm2.reduce((s2, v2) => s2 + v2, 0) + coupling.oceanHeatJm2.reduce((s2, v2) => s2 + v2, 0)) / grid.count;
    if (step2 < count) continue;
    const from = (step2 - count) * dt2, to = from + dt2;
    for (let cursor = from; cursor < to; ) {
      const month = Math.min(11, Math.floor(cursor / (period / 12) + 1e-10)), next2 = Math.min(to, (month + 1) * period / 12), weight = (next2 - cursor) / (period / 12), out2 = months[month];
      for (let i = 0; i < grid.count; i++) {
        out2.atmosphereKgM2[i] += weight * w2.atmosphereKgM2[i];
        out2.rainMmDay[i] += w2.precipitationKgM2S[i] * DAY2 * weight;
        out2.evaporationMmDay[i] += w2.evaporationKgM2S[i] * DAY2 * weight;
        out2.soilFraction[i] += weight * (f[i] > 0 ? w2.soilKgM2[i] / (water.soilCapacityKgM2 * f[i]) : 0);
        out2.humidityFraction[i] += weight * Math.min(1, w2.atmosphereKgM2[i] / moistureCapacity(model.temperatureK[i]));
        out2.surfaceMm[i] += weight * (f[i] > 0 ? w2.surfaceKgM2[i] / f[i] : 0);
        out2.temperatureK[i] += weight * model.temperatureK[i];
        out2.landTemperatureK[i] += weight * model.landTemperatureK[i];
        out2.oceanTemperatureK[i] += weight * model.oceanTemperatureK[i];
        out2.windEastMps[i] += weight * w2.windEastMps[i];
        out2.windNorthMps[i] += weight * w2.windNorthMps[i];
      }
      cursor = next2;
    }
  }
  for (const month of months) for (const key2 of ["humidityFraction", "soilFraction"]) for (let i = 0; i < grid.count; i++) month[key2][i] = Math.max(0, Math.min(1, month[key2][i]));
  const result = { months: physical ? months : months.map((month) => Object.fromEntries(Object.entries(month).map(([name, values]) => [name, resampleClimateField(grid, values, target)]))), waterResidualMm: w2.diagnostics().totalMm - initial2, externalLatentHeatJm2, coupled: false, integratedYearS: period, forcingYearS: yearS, spinupYearS: period, referenceRadiusM: planet.radiusM, steps: 2 * count };
  cache.set(key, result);
  if (cache.size > 4) cache.delete(cache.keys().next().value);
  return result;
}

// climate.ts
var clamp2 = (x, lo = 0, hi = 1) => Math.max(lo, Math.min(hi, x));
function circulationWinds(grid, planet, orbit, timeS, land, strength) {
  const declination = sunState(planet, orbit, timeS).declinationRad;
  const eastMps = new Float64Array(grid.count), northMps = new Float64Array(grid.count);
  const rotation = Math.min(1, DEFAULT_PLANET.siderealPeriodS / planet.siderealPeriodS);
  for (let i = 0; i < grid.count; i++) {
    const lat = Math.asin(grid.sinLat[Math.floor(i / grid.width)]);
    const shifted = (lat - 0.4 * declination) * 180 / Math.PI, d2 = Math.min(90, Math.abs(shifted));
    const band = Math.min(2, Math.floor(d2 / 30)), shape = Math.sin(Math.PI * (d2 - band * 30) / 30);
    const speed = strength * (1 - 0.25 * land[i]) * shape;
    eastMps[i] = (band === 1 ? 1 : -1) * speed * rotation * (planet.retrograde ? -1 : 1);
    northMps[i] = (band === 1 ? 1 : -1) * Math.sign(shifted) * 0.35 * speed;
  }
  return { eastMps, northMps };
}
function generateClimate(grid, planet, orbit, thermal, water, land, heightM, timeS, environment) {
  const climate = generateThermalClimate(grid, planet, orbit, thermal, water, land, heightM, timeS);
  if (water.moistureScheme === "transport" && thermal.separateReservoirs) {
    const reference2 = referenceMoisture(grid, planet, orbit, thermal, water, land, heightM, environment);
    const phase2 = orbit.orbitPhaseRad + 2 * Math.PI * timeS / deriveOrbit(planet, orbit).yearS;
    const month = Math.floor((phase2 / (2 * Math.PI) % 1 + 1) % 1 * 12);
    for (const key of ["rainMmDay", "evaporationMmDay", "soilFraction", "humidityFraction", "surfaceMm", "atmosphereKgM2"]) climate[key] = reference2.months[month][key].slice();
    if (thermal.airRadiationFraction !== void 0) for (const key of ["temperatureK", "landTemperatureK", "oceanTemperatureK"]) climate[key] = reference2.months[month][key].slice();
  }
  return climate;
}
function generateThermalClimate(grid, planet, orbit, thermal, water, land, heightM, timeS) {
  if (land.length !== grid.count || heightM.length !== grid.count) throw new RangeError("Climate terrain size mismatch");
  for (let i = 0; i < grid.count; i++) if (!Number.isFinite(land[i]) || land[i] < 0 || land[i] > 1 || !Number.isFinite(heightM[i]) || heightM[i] < 0) throw new RangeError("Invalid climate terrain");
  const { fluxWm2: flux, yearS } = deriveOrbit(planet, orbit), omega = 2 * Math.PI / yearS;
  const phase2 = orbit.orbitPhaseRad + omega * (timeS % yearS), declination = Math.asin(Math.sin(planet.obliquityRad) * Math.sin(phase2));
  const n2 = grid.count, temperatureK = new Float64Array(n2), radiationScale = new Float64Array(n2), absorbedWm2 = new Float64Array(n2);
  const rainMmDay = new Float64Array(n2), evaporationMmDay = new Float64Array(n2), soilFraction = new Float64Array(n2), humidityFraction = new Float64Array(n2), surfaceMm = new Float64Array(n2);
  const annual = new Float64Array(grid.height);
  for (let j = 0; j < grid.height; j++) for (let s = 0; s < 24; s++) annual[j] += dailyMeanInsolation(grid.sinLat[j], Math.asin(Math.sin(planet.obliquityRad) * Math.sin(2 * Math.PI * (s + 0.5) / 24)), flux) / 24;
  let marine = Float64Array.from(land, (f) => 1 - f);
  const closePoles = (field2) => {
    for (const j of [0, grid.height - 1]) if (Math.abs(grid.sinLat[j]) === 1) {
      let mean = 0;
      for (let x = 0; x < grid.width; x++) mean += field2[j * grid.width + x] / grid.width;
      field2.fill(mean, j * grid.width, (j + 1) * grid.width);
    }
  };
  for (let pass = 0; pass < 3; pass++) {
    const sum3 = marine.slice(), weight = new Float64Array(n2).fill(1);
    for (const e2 of grid.edges) {
      sum3[e2.a] += marine[e2.b];
      sum3[e2.b] += marine[e2.a];
      weight[e2.a]++;
      weight[e2.b]++;
    }
    marine = sum3.map((v2, i) => v2 / weight[i]);
    closePoles(marine);
  }
  const winds = circulationWinds(grid, planet, orbit, timeS, land, water.windMps);
  const transport = thermal.diffusion * (DEFAULT_PLANET.radiusM / planet.radiusM) ** 2, redistribute = transport / (transport + 2);
  const globalT = Math.pow((1 - orbit.bondAlbedo) * flux / (4 * thermal.emissivity * STEFAN_BOLTZMANN), 0.25);
  const derivative = Math.max(1e-12, 4 * thermal.emissivity * STEFAN_BOLTZMANN * globalT ** 3);
  const sample = (values, x, y) => values[Math.max(0, Math.min(grid.height - 1, Math.round(y))) * grid.width + (Math.round(x) % grid.width + grid.width) % grid.width];
  for (let i = 0; i < n2; i++) {
    const j = Math.floor(i / grid.width), x = i % grid.width, sinLat = grid.sinLat[j];
    const effectiveLand = land[i] * (1 - 0.6 * marine[i]);
    const capacity = effectiveLand * thermal.landHeatCapacity + (1 - effectiveLand) * thermal.oceanDepthM * 42e5;
    const lag = Math.atan(omega * capacity / derivative), amplitude = Math.cos(lag);
    const lagDeclination = Math.asin(Math.sin(planet.obliquityRad) * Math.sin(phase2 - lag));
    const seasonal = Math.max(0, annual[j] + amplitude * (dailyMeanInsolation(sinLat, lagDeclination, flux) - annual[j]));
    const q = (1 - redistribute) * seasonal + redistribute * flux / 4;
    radiationScale[i] = Math.max(0.55, Math.exp(-65e-4 * heightM[i] * land[i] / 288.15));
    temperatureK[i] = radiationScale[i] * Math.pow(Math.max(0, (1 - orbit.bondAlbedo) * q / (thermal.emissivity * STEFAN_BOLTZMANN)), 0.25);
    absorbedWm2[i] = (1 - orbit.bondAlbedo) * dailyMeanInsolation(sinLat, declination, flux);
    const u4 = winds.eastMps[i], v2 = winds.northMps[i], speed = Math.hypot(u4, v2);
    const dx = speed > 1e-9 ? u4 / speed : 0, dy = speed > 1e-9 ? -v2 / speed : 0;
    let ocean = marine[i], weight = 1;
    for (let k = 1; k <= 8; k++) {
      const w2 = Math.exp(-k / 3);
      ocean += w2 * (1 - sample(land, x - dx * k, j - dy * k));
      weight += w2;
    }
    ocean /= weight;
    const ascent = heightM[i] - sample(heightM, x - dx, j - dy);
    const orography = speed > 1e-9 ? Math.exp(clamp2(ascent / 1e3, -1, 1)) : 1;
    const lat = Math.asin(sinLat) * 180 / Math.PI, d2 = Math.abs(lat - 0.4 * declination * 180 / Math.PI);
    const belt = 0.25 + 1.1 * Math.exp(-Math.pow(d2 / 12, 2)) + 0.6 * Math.exp(-Math.pow((d2 - 55) / 12, 2)) - 0.2 * Math.exp(-Math.pow((d2 - 30) / 9, 2));
    const potential = 86400 * water.evaporationFraction * absorbedWm2[i] / 245e4;
    rainMmDay[i] = clamp2(potential * belt * (0.2 + 0.8 * ocean) * orography, 0, 30);
    const wetness = clamp2(rainMmDay[i] / 5);
    soilFraction[i] = clamp2(0.1 + 0.75 * wetness, 0.05, 0.9);
    humidityFraction[i] = clamp2(0.3 + 0.45 * wetness + 0.1 * ocean, 0.2, 0.95);
    surfaceMm[i] = 20 * wetness * wetness;
    evaporationMmDay[i] = potential * clamp2((temperatureK[i] - 273.15) / 5) * (1 - humidityFraction[i]) * (land[i] + (water.initialOceanDepthM > 0 ? 1 - land[i] : 0));
  }
  const result = { temperatureK, radiationScale, absorbedWm2, windEastMps: winds.eastMps, windNorthMps: winds.northMps, rainMmDay, evaporationMmDay, soilFraction, humidityFraction, surfaceMm };
  for (const field2 of Object.values(result)) closePoles(field2);
  return result;
}

// sea-ice.ts
var FREEZE_K = 271.35;
var LATENT_J_M3 = 917 * 334e3;
var MAX_ENERGY = 2 * LATENT_J_M3;
var COVER_ENERGY = 0.5 * LATENT_J_M3;
var bounded = (energy) => Math.max(0, Math.min(MAX_ENERGY, energy));
function seaIceCooling(temperatureK, emissivity) {
  return 4 * emissivity * STEFAN_BOLTZMANN * FREEZE_K ** 3 * (FREEZE_K - temperatureK);
}
function advanceSeaIce(energyJm2, coolingWm2, dtS) {
  return bounded(energyJm2 + coolingWm2 * dtS);
}
function seaIceFraction(energyJm2) {
  return Math.max(0, Math.min(1, energyJm2 / COVER_ENERGY));
}
function generateSeaIce(cooling, count, yearS, phaseRad) {
  const result = new Float64Array(count), monthS = yearS / 12;
  const phase2 = (phaseRad / (2 * Math.PI) % 1 + 1) % 1 * 12, month = Math.floor(phase2), fraction = phase2 - month;
  for (let i = 0; i < count; i++) {
    let low = 0, high = MAX_ENERGY, total = 0;
    for (let m2 = 0; m2 < 12; m2++) {
      const delta = cooling[m2 * count + i] * monthS;
      total += delta;
      low = bounded(low + delta);
      high = bounded(high + delta);
    }
    let energy = total > 0 ? high : low;
    for (let m2 = 0; m2 < month; m2++) energy = advanceSeaIce(energy, cooling[m2 * count + i], monthS);
    result[i] = advanceSeaIce(energy, cooling[month * count + i], fraction * monthS);
  }
  return result;
}

// surface.ts
var BIOMES = {
  ice: { label: "Perennial ice / snow", color: [234, 242, 240] },
  tundra: { label: "Tundra", color: [143, 153, 125] },
  boreal: { label: "Boreal forest", color: [46, 88, 76] },
  temperate: { label: "Temperate forest", color: [70, 121, 66] },
  grassland: { label: "Grassland / steppe", color: [156, 168, 89] },
  desert: { label: "Desert", color: [215, 182, 122] },
  savanna: { label: "Savanna", color: [179, 173, 83] },
  "tropical-forest": { label: "Tropical seasonal forest", color: [90, 137, 61] },
  rainforest: { label: "Tropical rainforest", color: [27, 101, 63] },
  barren: { label: "Barren ground", color: [151, 132, 112] }
};
var clamp3 = (x) => Math.max(0, Math.min(1, x));
function classifyBiome(meanK, warmestK, rainMm) {
  const mean = meanK - 273.15, warmest = warmestK - 273.15;
  if (mean > 45 || warmest < 10 && rainMm < 50) return "barren";
  if (warmest < 0) return "ice";
  if (warmest < 10) return "tundra";
  if (rainMm < 250) return "desert";
  if (rainMm < Math.max(500, 25 * mean)) return "grassland";
  if (mean < 5) return "boreal";
  if (mean < 20) return "temperate";
  if (rainMm < 1e3) return "savanna";
  return rainMm < 1600 ? "tropical-forest" : "rainforest";
}
function generateSurfaceReference(grid, planet, orbit, thermal, water, land, heightM, moistureAnnual, environment) {
  const meanTemperatureK = new Float64Array(grid.count), warmestTemperatureK = new Float64Array(grid.count), annualRainMm = new Float64Array(grid.count);
  const monthlyIceCooling = new Float64Array(12 * grid.count);
  const { yearS } = deriveOrbit(planet, orbit), annualOrbit = { ...orbit, orbitPhaseRad: 0, spinPhaseRad: 0 };
  for (let month = 0; month < 12; month++) {
    const time = (month + 0.5) * yearS / 12;
    const c = moistureAnnual ? generateThermalClimate(grid, planet, annualOrbit, thermal, water, land, heightM, time) : generateClimate(grid, planet, annualOrbit, thermal, water, land, heightM, time, environment);
    for (let i = 0; i < grid.count; i++) {
      const sourceT = thermal.airRadiationFraction !== void 0 ? c.landTemperatureK?.[i] ?? c.temperatureK[i] : c.temperatureK[i];
      meanTemperatureK[i] += sourceT / 12;
      warmestTemperatureK[i] = Math.max(warmestTemperatureK[i], sourceT);
      annualRainMm[i] += c.rainMmDay[i] * 365.2425 / 12;
      monthlyIceCooling[month * grid.count + i] = seaIceCooling(c.temperatureK[i], thermal.emissivity);
    }
  }
  if (moistureAnnual) annualRainMm.set(moistureAnnual);
  return { meanTemperatureK, warmestTemperatureK, annualRainMm, monthlyIceCooling };
}
function surfaceCover(climate, temperatureK, soilFraction) {
  const biome = classifyBiome(climate.meanTemperatureK, climate.warmestTemperatureK, climate.annualRainMm);
  const snowFraction = clamp3((273.15 - temperatureK) / 8) * clamp3(climate.annualRainMm / 120);
  const base = BIOMES[biome === "ice" ? "barren" : biome].color;
  const dry = biome === "barren" || biome === "desert" || biome === "ice" ? 0 : 0.35 * (1 - clamp3(soilFraction / 0.6));
  const dormant = [166, 145, 97], snow2 = BIOMES.ice.color;
  const color = base.map((c, i) => (c * (1 - dry) + dormant[i] * dry) * (1 - snowFraction) + snow2[i] * snowFraction);
  return { biome, snowFraction, color };
}

// ice-inventory.ts
function decodeIceInventory(value) {
  if (value === void 0 || value === null) return null;
  if (!value || typeof value !== "object" || Array.isArray(value)) throw new Error("Invalid ice inventory configuration");
  const d2 = value, n2 = SURFACE_WIDTH * SURFACE_HEIGHT;
  if (d2.version !== 1 || d2.grid?.width !== SURFACE_WIDTH || d2.grid?.height !== SURFACE_HEIGHT) throw new Error("Ice inventory uses a different surface grid");
  if (typeof d2.source !== "string" || !d2.source.trim() || d2.source.length > 4096) throw new Error("Missing ice inventory source");
  const read = (key, min, max) => {
    const a = d2[key];
    if (!Array.isArray(a) && !(a instanceof Float64Array) || a.length !== n2) throw new Error(`Invalid ${key} dimensions`);
    return Float64Array.from(a, (v2) => {
      if (typeof v2 !== "number" || !Number.isFinite(v2) || v2 < min || v2 > max) throw new Error(`Invalid ${key}`);
      return v2;
    });
  };
  const groundedThicknessM = read("groundedThicknessM", 0, 6e3), shelfThicknessM = read("shelfThicknessM", 0, 6e3);
  if (!Array.isArray(d2.bedrockM) && !(d2.bedrockM instanceof Float64Array) || d2.bedrockM.length !== n2) throw new Error("Invalid bedrockM dimensions");
  const bedrockM = Array.from(d2.bedrockM, (v2, i) => {
    if (v2 === null && groundedThicknessM[i] === 0 && shelfThicknessM[i] === 0) return null;
    if (typeof v2 !== "number" || !Number.isFinite(v2) || v2 < -12e3 || v2 > 9e3) throw new Error("Missing or invalid ice product bedrock");
    return v2;
  });
  for (let i = 0; i < n2; i++) if (groundedThicknessM[i] > 0 && shelfThicknessM[i] > 0) throw new Error("Grounded ice and floating shelf overlap");
  return { version: 1, grid: { width: SURFACE_WIDTH, height: SURFACE_HEIGHT }, source: d2.source, groundedThicknessM, shelfThicknessM, bedrockM };
}

// refinement-topology.ts
var MAX_SURFACE_PATCHES = 1e5;
function makeSurfacePartition(grid, land, height, source2, reliefM, quality) {
  const n2 = grid.count, bins = Array.from({ length: n2 }, () => []);
  if (source2) {
    const mesh2 = source2.mesh, xyz = mesh2?.xyz_t ?? source2.directions, len = xyz.length / 3;
    for (let t = 0; t < len; t++) {
      const direction = Array.from({ length: 3 }, (_, c) => xyz[3 * t + c]), [u5, v3] = directionToUV(direction);
      let a = 1;
      if (mesh2) {
        const p2 = [0, 1, 2].map((j) => Array.from(mesh2.xyz_r.subarray(3 * mesh2.r_begin_s(3 * t + j), 3 * mesh2.r_begin_s(3 * t + j) + 3)));
        const dot = (x, y) => x.reduce((s, v4, c) => s + v4 * y[c], 0);
        const det = p2[0][0] * (p2[1][1] * p2[2][2] - p2[1][2] * p2[2][1]) + p2[0][1] * (p2[1][2] * p2[2][0] - p2[1][0] * p2[2][2]) + p2[0][2] * (p2[1][0] * p2[2][1] - p2[1][1] * p2[2][0]);
        a = 2 * Math.atan2(Math.abs(det), 1 + dot(p2[0], p2[1]) + dot(p2[1], p2[2]) + dot(p2[2], p2[0]));
      }
      bins[thermalCell(grid, u5, v3)].push({ u: u5, v: v3, e: source2.elevation[(mesh2?.numRegions ?? 0) + t], a });
    }
  }
  const level = new Uint8Array(n2), offset = new Int32Array(n2 + 1);
  for (let k = 0; k < n2; k++) {
    const positive = bins[k].filter((p2) => p2.e > 0), range = positive.length ? Math.max(...positive.map((p2) => p2.e)) - Math.min(...positive.map((p2) => p2.e)) : 0;
    const coast = land[k] > 0 && land[k] < 1, polar2 = Math.abs(grid.sinLat[Math.floor(k / grid.width)]) > 0.8 && land[k] > 0;
    level[k] = coast || range * reliefM > 1200 ? quality === "high" ? 8 : 4 : range * reliefM > 400 || polar2 ? 4 : 1;
    offset[k + 1] = offset[k] + level[k] ** 2;
  }
  if (offset[n2] > MAX_SURFACE_PATCHES) throw new Error("Refinement exceeds the saveable surface budget; use a smaller atmosphere grid");
  const count = offset[n2], parent = new Int32Array(count), lw = new Float64Array(count), sw = new Float64Array(count), h = new Float64Array(count), u4 = new Float64Array(count), v2 = new Float64Array(count);
  const part = { level, offset, parent, land: lw, sea: sw, heightM: h, u: u4, v: v2 };
  for (let k = 0; k < n2; k++) {
    const q = level[k], start2 = offset[k], j = Math.floor(k / grid.width), x = k % grid.width;
    const sums = new Float64Array(q * q), heights = new Float64Array(q * q);
    for (let t = start2; t < offset[k + 1]; t++) {
      const a = t - start2, xx = a % q, yy = Math.floor(a / q);
      parent[t] = k;
      u4[t] = (x + (xx + 0.5) / q) / grid.width;
      v2[t] = Math.acos(1 - 2 * (j + (yy + 0.5) / q) / grid.height) / Math.PI;
    }
    for (const p2 of bins[k]) {
      const t = partitionCell(grid, part, p2.u, p2.v) - start2;
      sums[t] += p2.a;
      if (p2.e > 0) {
        lw[start2 + t] += p2.a;
        heights[t] += p2.a * Math.min(1, p2.e) * reliefM;
      } else sw[start2 + t] += p2.a;
    }
    let aLand = 0, aSea = 0;
    for (let t = start2; t < offset[k + 1]; t++) {
      const a = t - start2;
      if (sums[a] === 0) {
        const y = Math.cos(v2[t] * Math.PI), lon = (u4[t] - 0.5) * 2 * Math.PI, r = Math.sqrt(1 - y * y);
        let best = -Infinity, e2 = land[k] >= 0.5 ? height[k] : 0;
        for (const p2 of bins[k]) {
          const py = Math.cos(p2.v * Math.PI), pr = Math.sqrt(1 - py * py), d2 = y * py + r * pr * Math.cos((p2.u - u4[t]) * 2 * Math.PI);
          if (d2 > best) {
            best = d2;
            e2 = p2.e;
          }
        }
        lw[t] = e2 > 0 ? 1 : 0;
        sw[t] = e2 > 0 ? 0 : 1;
        h[t] = Math.max(0, e2) * reliefM;
      } else {
        h[t] = lw[t] > 0 ? heights[a] / lw[t] : 0;
        lw[t] /= sums[a];
        sw[t] /= sums[a];
      }
      aLand += lw[t];
      aSea += sw[t];
    }
    if (aLand === 0 && land[k] > 0) {
      for (let t = start2; t < offset[k + 1]; t++) {
        lw[t] = 1;
        h[t] = height[k] * reliefM;
      }
      aLand = q * q;
    }
    if (aSea === 0 && land[k] < 1) {
      for (let t = start2; t < offset[k + 1]; t++) sw[t] = 1;
      aSea = q * q;
    }
    if (land[k] === 1) {
      for (let t = start2; t < offset[k + 1]; t++) if (lw[t] === 0) {
        lw[t] = 1;
        h[t] = height[k] * reliefM;
        aLand++;
      }
    }
    if (land[k] === 0) {
      for (let t = start2; t < offset[k + 1]; t++) if (sw[t] === 0) {
        sw[t] = 1;
        aSea++;
      }
    }
    for (let t = start2; t < offset[k + 1]; t++) {
      lw[t] *= aLand > 0 ? land[k] / aLand : 0;
      sw[t] *= aSea > 0 ? (1 - land[k]) / aSea : 0;
    }
  }
  return part;
}
function partitionCell(grid, p2, u4, v2) {
  const uu = (u4 % 1 + 1) % 1, k = thermalCell(grid, uu, v2), q = p2.level[k];
  const x = Math.min(q - 1, Math.floor((uu * grid.width - k % grid.width) * q));
  const y = Math.max(0, Math.min(q - 1, Math.floor(((1 - Math.cos(v2 * Math.PI)) / 2 * grid.height - Math.floor(k / grid.width)) * q)));
  return p2.offset[k] + y * q + x;
}

// refinement-surface.ts
var stores = ["snow", "ice", "grounded", "shelfLand", "shelfSea", "soil", "surface"];
var coarse = { snow: "snowKgM2", ice: "seaIceKgM2", grounded: "landIceKgM2", shelfLand: "shelfLandIceKgM2", shelfSea: "shelfSeaIceKgM2", soil: "soilKgM2", surface: "surfaceKgM2" };
var RefinedSurface = class _RefinedSurface {
  constructor(model, water, partition) {
    this.model = model;
    this.water = water;
    this.partition = partition;
    const count = partition.parent.length, n2 = model.grid.count;
    for (const key of stores) this[key] = new Float64Array(count);
    this.landK = new Float64Array(count);
    this.seaK = new Float64Array(count);
    this.rain = new Float64Array(count);
    this.snowfall = new Float64Array(count);
    this.melt = new Float64Array(count);
    this.lakeArea = new Float64Array(count);
    this.albedo = new Float64Array(count);
    this.landAlbedo = new Float64Array(count);
    this.seaAlbedo = new Float64Array(count);
    this.oceanDemand = new Float64Array(count);
    this.meanHeight = new Float64Array(n2);
    this.maxHeight = new Float64Array(n2);
    this.lastLand = model.landTemperatureK.slice();
    this.lastSea = model.oceanTemperatureK.slice();
    for (let t = 0; t < count; t++) {
      const k = partition.parent[t];
      this.meanHeight[k] += partition.heightM[t] * partition.land[t];
      if (partition.land[t] > 0) this.maxHeight[k] = Math.max(this.maxHeight[k], partition.heightM[t]);
    }
    for (let k = 0; k < n2; k++) if (water.land[k] > 0) this.meanHeight[k] /= water.land[k];
    const initial2 = deriveOrbit(model.planet, model.orbit).equilibriumK / model.config.emissivity ** 0.25, maxT = Math.max(initial2, (model.fluxWm2 / (model.config.emissivity * STEFAN_BOLTZMANN)) ** 0.25), derivative = 4 * model.config.emissivity * STEFAN_BOLTZMANN * maxT ** 3 * (1 - (model.config.airRadiationFraction ?? 0));
    let bound = Infinity;
    for (let t = 0; t < count; t++) {
      if (partition.land[t] > 0) bound = Math.min(bound, 0.45 * model.config.landHeatCapacity * Math.max(0.55, Math.exp(-65e-4 * partition.heightM[t] / 288.15)) ** 4 / derivative);
      if (partition.sea[t] > 0) bound = Math.min(bound, 0.45 * model.config.oceanDepthM * 42e5 / derivative);
    }
    this.maxStepS = bound;
  }
  model;
  water;
  partition;
  maxStepS;
  landK;
  seaK;
  snow;
  ice;
  grounded;
  shelfLand;
  shelfSea;
  soil;
  surface;
  rain;
  snowfall;
  melt;
  albedo;
  landAlbedo;
  seaAlbedo;
  oceanDemand;
  lastLand;
  lastSea;
  meanHeight;
  maxHeight;
  environment = null;
  routePartition = null;
  terrainSource = null;
  lakeArea;
  static create(m2, w2, height, source2, quality, seeds) {
    const r = new _RefinedSurface(m2, w2, makeSurfacePartition(m2.grid, w2.land, height, source2, m2.planet.reliefM, quality)), p2 = r.partition;
    r.terrainSource = source2;
    r.attachRouting(false);
    for (let t = 0; t < p2.parent.length; t++) {
      const k = p2.parent[t], f = w2.land[k];
      r.rain[t] = w2.config.moistureScheme === "transport" ? (f > 0 ? w2.landPrecipitationKgM2S[k] * p2.land[t] / f : 0) + (f < 1 ? w2.oceanPrecipitationKgM2S[k] * p2.sea[t] / (1 - f) : 0) : w2.precipitationKgM2S[k] * (p2.land[t] + p2.sea[t]);
      r.landK[t] = Math.max(1, m2.landTemperatureK[k] - 65e-4 * (p2.heightM[t] - r.meanHeight[k]));
      r.seaK[t] = m2.oceanTemperatureK[k];
    }
    for (let k = 0; k < m2.grid.count; k++) {
      const mean = r.meanTemperature(k, false), factor = mean > 0 ? m2.landTemperatureK[k] / mean : 1;
      for (let t = p2.offset[k]; t < p2.offset[k + 1]; t++) r.landK[t] *= factor;
      for (const kind of stores) {
        const ocean = kind === "ice" || kind === "shelfSea", weights2 = new Float64Array(p2.offset[k + 1] - p2.offset[k]);
        let sum3 = 0;
        for (let t = p2.offset[k]; t < p2.offset[k + 1]; t++) {
          const area = kind === "surface" ? p2.land[t] + r.lakeArea[t] : ocean ? p2.sea[t] : p2.land[t];
          const weight = kind === "snow" ? Math.max(0, 273.15 - r.airK(t)) : kind === "soil" || kind === "surface" ? 1 : Math.max(0, seeds(p2.u[t], p2.v[t], kind));
          weights2[t - p2.offset[k]] = area * weight;
          sum3 += area * weight;
        }
        if (sum3 === 0) {
          for (let t = p2.offset[k]; t < p2.offset[k + 1]; t++) {
            weights2[t - p2.offset[k]] = kind === "surface" ? p2.land[t] + p2.sea[t] : ocean ? p2.sea[t] : p2.land[t];
            sum3 += weights2[t - p2.offset[k]];
          }
        }
        for (let t = p2.offset[k]; t < p2.offset[k + 1]; t++) r[kind][t] = sum3 > 0 ? w2[coarse[kind]][k] * weights2[t - p2.offset[k]] / sum3 : 0;
      }
    }
    return r;
  }
  /** Conservative overlap on the registered, nested geographic tiling. */
  static remap(old, m2, w2, part, source2 = null) {
    const r = new _RefinedSurface(m2, w2, part), p2 = old.partition;
    if (source2) r.setTerrainSource(source2);
    for (let k = 0; k < w2.grid.count; k++) {
      const nq = part.level[k], oq = p2.level[k];
      const landHeat = new Float64Array(nq * nq), seaHeat = new Float64Array(nq * nq), landWeight = new Float64Array(nq * nq), seaWeight = new Float64Array(nq * nq);
      for (let a = p2.offset[k]; a < p2.offset[k + 1]; a++) {
        const local = a - p2.offset[k], x = local % oq, y = Math.floor(local / oq), candidates = [];
        for (let yy = Math.floor(y * nq / oq); yy < Math.ceil((y + 1) * nq / oq); yy++) for (let xx = Math.floor(x * nq / oq); xx < Math.ceil((x + 1) * nq / oq); xx++) {
          const overlap = (Math.min((x + 1) / oq, (xx + 1) / nq) - Math.max(x / oq, xx / nq)) * (Math.min((y + 1) / oq, (yy + 1) / nq) - Math.max(y / oq, yy / nq));
          candidates.push({ t: part.offset[k] + yy * nq + xx, overlap: overlap * nq * nq });
        }
        for (const b of candidates) {
          const i = b.t - part.offset[k], fraction = b.overlap * oq * oq / (nq * nq);
          landHeat[i] += fraction * p2.land[a] * old.landK[a];
          landWeight[i] += fraction * p2.land[a];
          seaHeat[i] += fraction * p2.sea[a] * old.seaK[a];
          seaWeight[i] += fraction * p2.sea[a];
        }
        for (const kind of stores) {
          const ocean = kind === "ice" || kind === "shelfSea";
          let target = kind;
          const carrier = (t, sea2) => kind === "surface" ? part.land[t] + r.lakeArea[t] : sea2 ? part.sea[t] : part.land[t];
          let sum3 = candidates.reduce((sum4, b) => sum4 + b.overlap * carrier(b.t, ocean), 0), sea = ocean;
          if (sum3 === 0) {
            if (kind === "soil" || kind === "surface") {
              w2.addOceanWater(old[kind][a] / w2.grid.count);
              continue;
            }
            sea = !ocean;
            target = kind === "shelfLand" ? "shelfSea" : kind === "shelfSea" ? "shelfLand" : ocean ? "snow" : "ice";
            sum3 = candidates.reduce((sum4, b) => sum4 + b.overlap * (sea ? part.sea[b.t] : part.land[b.t]), 0);
          }
          for (const b of candidates) r[target][b.t] += sum3 > 0 ? old[kind][a] * b.overlap * carrier(b.t, sea) / sum3 : 0;
        }
        for (const b of candidates) for (const key of ["rain", "snowfall", "melt"]) r[key][b.t] += old[key][a] * b.overlap * oq * oq / (nq * nq);
      }
      for (let b = part.offset[k]; b < part.offset[k + 1]; b++) {
        const i = b - part.offset[k];
        r.landK[b] = landWeight[i] > 0 ? landHeat[i] / landWeight[i] : old.model.landTemperatureK[k];
        r.seaK[b] = seaWeight[i] > 0 ? seaHeat[i] / seaWeight[i] : old.model.oceanTemperatureK[k];
      }
      const ml = r.meanTemperature(k, false), ms = r.meanTemperature(k, true), fl = ml > 0 ? old.model.landTemperatureK[k] / ml : 1, fs = ms > 0 ? old.model.oceanTemperatureK[k] / ms : 1;
      for (let b = part.offset[k]; b < part.offset[k + 1]; b++) {
        r.landK[b] *= fl;
        r.seaK[b] *= fs;
      }
    }
    for (let t = 0; t < part.parent.length; t++) {
      const excess = Math.max(0, r.soil[t] - part.land[t] * w2.config.soilCapacityKgM2);
      r.soil[t] -= excess;
      r.surface[t] += excess;
    }
    r.aggregate();
    return r;
  }
  attach(e2) {
    this.environment = e2;
    e2.surfaceSolver = this;
    this.model.surfaceSolver = this;
    this.water.surfaceSolver = this;
    this.attachRouting();
    this.refresh();
  }
  resetRates() {
    this.melt.fill(0);
    this.rain.fill(0);
    this.snowfall.fill(0);
  }
  attachRouting(install = true) {
    const route = this.water.routing, source2 = this.terrainSource;
    if (!route || !source2?.mesh) return;
    const mesh2 = source2.mesh, p2 = this.partition;
    this.routePartition = Int32Array.from({ length: mesh2.numTriangles }, (_, t) => {
      const xyz = mesh2.xyz_t.subarray(3 * t, 3 * t + 3), u4 = 0.5 + Math.atan2(xyz[0], xyz[2]) / (2 * Math.PI), v2 = Math.acos(Math.max(-1, Math.min(1, xyz[1]))) / Math.PI;
      return route.network.cell[t] >= 0 ? partitionCell(this.model.grid, p2, u4, v2) : -1;
    });
    this.lakeArea.fill(0);
    const rawSea = new Float64Array(p2.parent.length);
    for (let t = 0; t < mesh2.numTriangles; t++) {
      if (source2.elevation[mesh2.numRegions + t] > 0) continue;
      const xyz = mesh2.xyz_t.subarray(3 * t, 3 * t + 3), u4 = 0.5 + Math.atan2(xyz[0], xyz[2]) / (2 * Math.PI), v2 = Math.acos(Math.max(-1, Math.min(1, xyz[1]))) / Math.PI, a = partitionCell(this.model.grid, p2, u4, v2);
      rawSea[a] += route.network.areaM2[t];
      if ((route.network.inlandLakeId?.[t] ?? 0) > 0) this.lakeArea[a] += route.network.areaM2[t];
    }
    for (let a = 0; a < rawSea.length; a++) this.lakeArea[a] = rawSea[a] > 0 ? p2.sea[a] * this.lakeArea[a] / rawSea[a] : 0;
    if (install) route.setPartition(this.routePartition, this.surface, p2.parent);
  }
  setTerrainSource(source2) {
    this.terrainSource = source2;
    this.attachRouting();
  }
  meanTemperature(k, ocean) {
    const p2 = this.partition, a = ocean ? p2.sea : p2.land, t = ocean ? this.seaK : this.landK;
    let sum3 = 0, weight = 0;
    for (let i = p2.offset[k]; i < p2.offset[k + 1]; i++) {
      sum3 += a[i] * t[i];
      weight += a[i];
    }
    return weight > 0 ? sum3 / weight : ocean ? this.model.oceanTemperatureK[k] : this.model.landTemperatureK[k];
  }
  lapse(k) {
    return Math.min(65e-4, Math.max(0, this.model.temperatureK[k] - 1) / Math.max(1, this.maxHeight[k] - this.water.land[k] * this.meanHeight[k]));
  }
  landAirK(t) {
    const p2 = this.partition, k = p2.parent[t];
    return this.model.temperatureK[k] - this.lapse(k) * (p2.heightM[t] - this.water.land[k] * this.meanHeight[k]);
  }
  seaAirK(t) {
    const k = this.partition.parent[t];
    return this.model.temperatureK[k] + this.lapse(k) * this.water.land[k] * this.meanHeight[k];
  }
  airK(t) {
    const p2 = this.partition;
    return (p2.land[t] * this.landAirK(t) + p2.sea[t] * this.seaAirK(t)) / (p2.land[t] + p2.sea[t]);
  }
  /** Import only a coarse ocean/ice-flow anomaly, preserving local contrasts. */
  pull() {
    const p2 = this.partition, m2 = this.model;
    for (let t = 0; t < p2.parent.length; t++) {
      const k = p2.parent[t];
      this.landK[t] += m2.landTemperatureK[k] - this.lastLand[k];
      this.seaK[t] += m2.oceanTemperatureK[k] - this.lastSea[k];
    }
    this.lastLand.set(m2.landTemperatureK);
    this.lastSea.set(m2.oceanTemperatureK);
  }
  temperatures(k) {
    this.model.landTemperatureK[k] = this.lastLand[k] = this.meanTemperature(k, false);
    this.model.oceanTemperatureK[k] = this.lastSea[k] = this.meanTemperature(k, true);
  }
  aggregate() {
    const p2 = this.partition, w2 = this.water;
    for (let k = 0; k < w2.grid.count; k++) {
      for (const kind of stores) {
        let sum3 = 0;
        for (let t = p2.offset[k]; t < p2.offset[k + 1]; t++) sum3 += this[kind][t];
        w2[coarse[kind]][k] = sum3;
      }
      this.temperatures(k);
    }
  }
  refresh() {
    if (!this.environment) return;
    const p2 = this.partition, e2 = this.environment, m2 = this.model, clamp5 = (v2) => Math.max(0, Math.min(1, v2));
    for (let k = 0; k < m2.grid.count; k++) {
      let sum3 = 0, landReflect = 0, seaReflect = 0, snow2 = 0, ice2 = 0, ground = 0, shelfLand = 0, shelfSea = 0, landFrozen = 0, seaFrozen = 0;
      for (let t = p2.offset[k]; t < p2.offset[k + 1]; t++) {
        const l2 = p2.land[t], s2 = p2.sea[t], sn = l2 > 0 ? clamp5(this.snow[t] / (30 * l2)) : 0, g = l2 > 0 ? clamp5(this.grounded[t] / (917 * 5 * l2)) : 0, sl = l2 > 0 ? clamp5(this.shelfLand[t] / (917 * 5 * l2)) : 0, i = s2 > 0 ? clamp5(this.ice[t] / (917 * 0.5 * s2)) : 0, ss = s2 > 0 ? clamp5(this.shelfSea[t] / (917 * 5 * s2)) : 0;
        const lf = Math.max(sn, g, sl), sf = Math.max(i, ss), base = clamp5(m2.orbit.bondAlbedo + (e2.config.vegetation ? l2 / (l2 + s2) * 0.06 * (0.5 - e2.vegetation[k]) : 0));
        this.albedo[t] = e2.config.iceAlbedo ? base + (Math.max(base, 0.65) - base) * (l2 * lf + s2 * sf) / (l2 + s2) : base;
        if (e2.config.separateSurfaceAlbedo) {
          const lb = clamp5(m2.orbit.bondAlbedo + (e2.config.vegetation ? 0.06 * (0.5 - e2.vegetation[k]) : 0)), sb = m2.orbit.bondAlbedo;
          this.landAlbedo[t] = e2.config.iceAlbedo ? lb + (Math.max(lb, 0.65) - lb) * lf : lb;
          this.seaAlbedo[t] = e2.config.iceAlbedo ? sb + (Math.max(sb, 0.65) - sb) * sf : sb;
          this.albedo[t] = (l2 * this.landAlbedo[t] + s2 * this.seaAlbedo[t]) / (l2 + s2);
        } else this.landAlbedo[t] = this.seaAlbedo[t] = this.albedo[t];
        sum3 += (l2 + s2) * this.albedo[t];
        landReflect += l2 * this.landAlbedo[t];
        seaReflect += s2 * this.seaAlbedo[t];
        snow2 += l2 * sn;
        ground += l2 * g;
        shelfLand += l2 * sl;
        ice2 += s2 * i;
        shelfSea += s2 * ss;
        landFrozen += l2 * lf;
        seaFrozen += s2 * sf;
      }
      const l = this.water.land[k], s = 1 - l;
      m2.albedo[k] = sum3;
      if (m2.surfaceAlbedo) {
        m2.surfaceAlbedo.land[k] = l > 0 ? landReflect / l : 0;
        m2.surfaceAlbedo.ocean[k] = s > 0 ? seaReflect / s : 0;
      }
      e2.snowCover[k] = l > 0 ? snow2 / l : 0;
      e2.glacierCover[k] = l > 0 ? ground / l : 0;
      e2.shelfLandCover[k] = l > 0 ? shelfLand / l : 0;
      e2.iceCover[k] = s > 0 ? ice2 / s : 0;
      e2.shelfSeaCover[k] = s > 0 ? shelfSea / s : 0;
      e2.oceanFrozenCover[k] = s > 0 ? seaFrozen / s : 0;
      e2.landEvaporation[k] = (e2.config.vegetation ? 0.6 + 0.4 * e2.vegetation[k] : 1) * (l > 0 ? 1 - landFrozen / l : 1);
    }
  }
  stepSurface(k, dt2, insolation) {
    const m2 = this.model, p2 = this.partition, airFraction = m2.config.airRadiationFraction ?? 0;
    let net = 0;
    const iceHeat = this.environment?.seaIceHeat;
    if (iceHeat) for (const field2 of Object.values(iceHeat)) field2[k] = 0;
    for (let t = p2.offset[k]; t < p2.offset[k + 1]; t++) for (const ocean of [false, true]) {
      const area = ocean ? p2.sea[t] : p2.land[t];
      if (area === 0) continue;
      const a = ocean ? this.seaK : this.landK, cs = area * (ocean ? m2.config.oceanDepthM * 42e5 : m2.config.landHeatCapacity), scale2 = ocean ? 1 : Math.max(0.55, Math.exp(-65e-4 * p2.heightM[t] / 288.15));
      if (ocean && iceHeat) {
        const e2 = this.environment, base = Math.max(0, Math.min(1, m2.orbit.bondAlbedo + (e2.config.separateSurfaceAlbedo ? 0 : e2.config.vegetation ? p2.land[t] / (p2.land[t] + p2.sea[t]) * 0.06 * (0.5 - e2.vegetation[k]) : 0)));
        const airK = this.seaAirK(t), flux = seaIceSurfaceExchange({ wetArea: area, marineArea: Math.max(0, area - this.lakeArea[t]), iceKgM2: this.ice[t], waterK: a[t], airK, waterCapacity: cs, airCapacity: m2.capacity[k], absorbedWm2: (1 - this.seaAlbedo[t]) * insolation, waterAlbedo: base, iceAlbedo: e2.config.iceAlbedo ? Math.max(base, 0.65) : base, emissivity: (1 - airFraction) * m2.config.emissivity, dt: dt2 });
        a[t] = flux.waterK;
        m2.temperatureK[k] += flux.airK - airK;
        net += flux.radiationWm2;
        iceHeat.iceArea[k] += flux.iceArea;
        iceHeat.skinK[k] += flux.iceArea * flux.skinK;
        iceHeat.conductiveWm2[k] += flux.conductiveWm2;
        iceHeat.airWm2[k] += flux.iceAirWm2;
        iceHeat.oceanWm2[k] += flux.iceOceanWm2;
        iceHeat.radiationWm2[k] += flux.radiationWm2;
        iceHeat.balanceResidualWm2[k] += flux.balanceResidualWm2;
        continue;
      }
      const radiation = area * ((1 - (ocean ? this.seaAlbedo[t] : this.landAlbedo[t])) * insolation - (1 - airFraction) * m2.config.emissivity * STEFAN_BOLTZMANN * (a[t] / scale2) ** 4);
      a[t] += dt2 * radiation / cs;
      net += radiation;
      const ca3 = m2.capacity[k], rate = 10 * area * (1 / ca3 + 1 / cs), heat = (a[t] - (ocean ? this.seaAirK(t) : this.landAirK(t))) * -Math.expm1(-dt2 * rate) / (1 / ca3 + 1 / cs);
      a[t] -= heat / cs;
      m2.temperatureK[k] += heat / ca3;
    }
    if (iceHeat && iceHeat.iceArea[k] > 0) iceHeat.skinK[k] /= iceHeat.iceArea[k];
    this.temperatures(k);
    return net;
  }
  phase(dt2) {
    this.pull();
    const p2 = this.partition, m2 = this.model, w2 = this.water;
    const lh = new Float64Array(m2.grid.count), sh = new Float64Array(m2.grid.count), freeze = new Float64Array(p2.parent.length);
    let request = 0;
    for (let t = 0; t < p2.parent.length; t++) {
      const k = p2.parent[t], lc = p2.land[t] * m2.config.landHeatCapacity, sc = p2.sea[t] * m2.config.oceanDepthM * 42e5;
      if (lc > 0) for (const kind of ["snow", "grounded", "shelfLand"]) {
        const melt = Math.min(this[kind][t], Math.max(0, (this.landK[t] - 273.15) * lc / FUSION_J_KG));
        this[kind][t] -= melt;
        this.landK[t] -= melt * FUSION_J_KG / lc;
        lh[k] -= melt * FUSION_J_KG;
        if (kind === "shelfLand") w2.addOceanWater(melt / m2.grid.count);
        else {
          this.surface[t] += melt;
          this.melt[t] += melt / dt2;
          w2.meltKgM2S[k] += melt / dt2;
        }
      }
      if (sc > 0) {
        for (const [kind, limit] of [["shelfSea", 273.15], ["ice", 271.35]]) {
          const melt = Math.min(this[kind][t], Math.max(0, (this.seaK[t] - limit) * sc / FUSION_J_KG));
          this[kind][t] -= melt;
          this.seaK[t] -= melt * FUSION_J_KG / sc;
          sh[k] -= melt * FUSION_J_KG;
          w2.addOceanWater(melt / m2.grid.count);
        }
        const open = p2.sea[t] > 0 ? Math.max(0, 1 - this.lakeArea[t] / p2.sea[t]) : 0;
        freeze[t] = Math.max(0, (271.35 - this.seaK[t]) * sc / FUSION_J_KG) * open;
        request += freeze[t] / m2.grid.count;
      }
    }
    const ratio = request > 0 ? Math.min(1, w2.oceanGlobalKgM2 / request) : 0;
    if (w2.config.compensatedOceanTransfers) w2.addOceanWater(-Math.min(w2.oceanGlobalKgM2, request * ratio));
    else w2.oceanGlobalKgM2 = Math.max(0, w2.oceanGlobalKgM2 - request * ratio);
    for (let t = 0; t < freeze.length; t++) if (freeze[t] > 0) {
      const amount = freeze[t] * ratio, k = p2.parent[t];
      this.ice[t] += amount;
      this.seaK[t] += amount * FUSION_J_KG / (p2.sea[t] * m2.config.oceanDepthM * 42e5);
      sh[k] += amount * FUSION_J_KG;
    }
    m2.applyLandHeat(lh);
    m2.applyOceanHeat(sh);
    this.aggregate();
    w2.landIceCorrection.fill(0);
  }
  evaporate(k, dt2, potential, deficit) {
    const p2 = this.partition, w2 = this.water, m2 = this.model, e2 = this.environment;
    let landEvap = 0, lakeEvap = 0, ocean = 0, lh = 0, sh = 0;
    for (let t = p2.offset[k]; t < p2.offset[k + 1]; t++) {
      const l = p2.land[t], s = p2.sea[t], frozen = l > 0 ? Math.min(1, Math.max(this.snow[t] / (l * 30), this.grounded[t] / (l * 917 * 5), this.shelfLand[t] / (l * 917 * 5))) : 0;
      const landPotential = e2.config.separateSurfaceAlbedo && m2.albedo[k] < 1 ? potential * (1 - this.landAlbedo[t]) / (1 - m2.albedo[k]) : potential, seaPotential = e2.config.separateSurfaceAlbedo && m2.albedo[k] < 1 ? potential * (1 - this.seaAlbedo[t]) / (1 - m2.albedo[k]) : potential;
      const demand = landPotential * deficit * Math.max(0, Math.min(1, (this.landK[t] - 273.15) / 5)) * l * (e2.config.vegetation ? 0.6 + 0.4 * e2.vegetation[k] : 1) * (1 - frozen);
      const lakeArea = this.lakeArea[t];
      const lakeDemand = seaPotential * deficit * Math.max(0, Math.min(1, (this.seaK[t] - 273.15) / 5)) * lakeArea;
      const surface = Math.min(this.surface[t], demand + lakeDemand), lake = Math.min(surface, lakeDemand), soil = Math.min(this.soil[t], Math.max(0, demand - surface + lake));
      this.surface[t] -= surface;
      this.soil[t] -= soil;
      landEvap += surface - lake + soil;
      lakeEvap += lake;
      lh -= VAPORIZATION_J_KG * (surface - lake + soil);
      sh -= VAPORIZATION_J_KG * lake;
      if (l > 0) this.landK[t] -= VAPORIZATION_J_KG * (surface - lake + soil) / (l * m2.config.landHeatCapacity);
      if (s > 0) this.seaK[t] -= VAPORIZATION_J_KG * lake / (s * m2.config.oceanDepthM * 42e5);
      const ice2 = s > 0 ? Math.min(1, Math.max(this.ice[t] / (s * 917 * 0.5), this.shelfSea[t] / (s * 917 * 5))) : 0;
      this.oceanDemand[t] = seaPotential * deficit * (w2.config.liquidOceanEvaporation ? 1 : Math.max(0, Math.min(1, (this.seaK[t] - 273.15) / 5))) * Math.max(0, s - lakeArea) * (1 - ice2);
      ocean += this.oceanDemand[t];
    }
    m2.applySurfaceCellHeat(k, lh, sh);
    this.aggregateCell(k);
    return { landEvap, lakeEvap, oceanDemand: ocean };
  }
  oceanEvaporate(k, amount) {
    const p2 = this.partition, m2 = this.model;
    let sum3 = 0;
    for (let t = p2.offset[k]; t < p2.offset[k + 1]; t++) sum3 += this.oceanDemand[t];
    for (let t = p2.offset[k]; t < p2.offset[k + 1]; t++) if (p2.sea[t] > 0) this.seaK[t] -= sum3 > 0 ? amount * this.oceanDemand[t] / sum3 * VAPORIZATION_J_KG / (p2.sea[t] * m2.config.oceanDepthM * 42e5) : 0;
    m2.applySurfaceCellHeat(k, 0, -amount * VAPORIZATION_J_KG);
    this.temperatures(k);
  }
  aggregateCell(k) {
    const p2 = this.partition;
    for (const kind of stores) {
      let sum3 = 0;
      for (let t = p2.offset[k]; t < p2.offset[k + 1]; t++) sum3 += this[kind][t];
      this.water[coarse[kind]][k] = sum3;
    }
    this.temperatures(k);
  }
  precipitate(k, rain2, dt2, landRain) {
    const p2 = this.partition, w2 = this.water, q = p2.level[k], start2 = p2.offset[k], u4 = w2.windEastMps[k], v2 = w2.windNorthMps[k], speed = Math.hypot(u4, v2), weights2 = new Float64Array(q * q);
    let sum3 = 0, snow2 = 0, landWeight = 0, seaWeight = 0;
    for (let t = start2; t < p2.offset[k + 1]; t++) {
      const x = (t - start2) % q, y = Math.floor((t - start2) / q), xx = Math.max(0, Math.min(q - 1, x - Math.round(speed > 0 ? u4 / speed : 0))), yy = Math.max(0, Math.min(q - 1, y + Math.round(speed > 0 ? v2 / speed : 0))), up = p2.heightM[start2 + yy * q + xx];
      weights2[t - start2] = (p2.land[t] + p2.sea[t]) * Math.exp(Math.max(-1, Math.min(1, (p2.heightM[t] - up) / 1e3)));
      sum3 += weights2[t - start2];
      const area = p2.land[t] + p2.sea[t];
      landWeight += weights2[t - start2] * p2.land[t] / area;
      seaWeight += weights2[t - start2] * p2.sea[t] / area;
    }
    for (let t = start2; t < p2.offset[k + 1]; t++) {
      const area = p2.land[t] + p2.sea[t], uniform = rain2 * weights2[t - start2] / sum3;
      const land = landRain === void 0 ? uniform * p2.land[t] / area : landWeight > 0 ? landRain * weights2[t - start2] * p2.land[t] / area / landWeight : 0;
      const sea = landRain === void 0 ? uniform * p2.sea[t] / area : seaWeight > 0 ? (rain2 - landRain) * weights2[t - start2] * p2.sea[t] / area / seaWeight : 0, amount = landRain === void 0 ? uniform : land + sea;
      this.rain[t] = amount / dt2;
      const frozen = this.landAirK(t) < 273.15 ? land : 0;
      this.snowfall[t] = frozen / dt2;
      this.snow[t] += frozen;
      snow2 += frozen;
      const liquid = land - frozen, capacity = w2.config.soilCapacityKgM2 * p2.land[t], infiltration = Math.min(liquid, Math.max(0, capacity - this.soil[t]));
      this.soil[t] += infiltration;
      this.surface[t] += liquid - infiltration;
      const drainage = Math.max(0, this.soil[t] - 0.7 * capacity) * -Math.expm1(-dt2 / (3 * 86400));
      this.soil[t] -= drainage;
      this.surface[t] += drainage;
      const lake = this.lakeArea[t];
      this.surface[t] += landRain === void 0 ? amount * lake / area : p2.sea[t] > 0 ? sea * lake / p2.sea[t] : 0;
      w2.addOceanWater((landRain === void 0 ? amount * Math.max(0, p2.sea[t] - lake) / area : p2.sea[t] > 0 ? sea * Math.max(0, p2.sea[t] - lake) / p2.sea[t] : 0) / w2.grid.count);
    }
    this.aggregateCell(k);
    return snow2;
  }
  reconcileIce() {
    const p2 = this.partition, w2 = this.water;
    for (let k = 0; k < w2.grid.count; k++) {
      let total = 0;
      for (let t = p2.offset[k]; t < p2.offset[k + 1]; t++) total += this.grounded[t];
      const target = w2.landIceKgM2[k];
      for (let t = p2.offset[k]; t < p2.offset[k + 1]; t++) this.grounded[t] = total > 0 ? this.grounded[t] * target / total : w2.land[k] > 0 ? target * p2.land[t] / w2.land[k] : 0;
    }
  }
  compact(dt2) {
    const p2 = this.partition, f = -Math.expm1(-dt2 / (30 * 365.25 * 86400));
    if (!this.water.glacier) return;
    for (let t = 0; t < p2.parent.length; t++) if (this.landK[t] < 273.15) {
      const mass = Math.max(0, this.snow[t] - 50 * p2.land[t]) * f;
      this.snow[t] -= mass;
      this.grounded[t] += mass;
    }
    this.aggregate();
  }
  route(dt2) {
    const w2 = this.water;
    if (dt2 > 0) w2.routeSurface(dt2);
    else w2.routing?.synchronize(w2);
    if (this.routePartition && w2.routing) {
      this.surface.fill(0);
      const conversion = 1e3 / w2.cellAreaM2;
      for (let t = 0; t < this.routePartition.length; t++) if (this.routePartition[t] >= 0) this.surface[this.routePartition[t]] += w2.routing.volumeM3[t] * conversion;
      for (let k = 0; k < w2.grid.count; k++) {
        let sum3 = 0;
        for (let t = this.partition.offset[k]; t < this.partition.offset[k + 1]; t++) sum3 += this.surface[t];
        if (sum3 === 0 && w2.surfaceKgM2[k] > 0) this.redistributeSurface(k, w2.surfaceKgM2[k]);
      }
    } else for (let k = 0; k < w2.grid.count; k++) this.redistributeSurface(k, w2.surfaceKgM2[k]);
  }
  redistributeSurface(k, target) {
    const p2 = this.partition;
    let sum3 = 0;
    for (let t = p2.offset[k]; t < p2.offset[k + 1]; t++) sum3 += this.surface[t];
    for (let t = p2.offset[k]; t < p2.offset[k + 1]; t++) this.surface[t] = sum3 > 0 ? this.surface[t] * target / sum3 : this.water.land[k] > 0 ? target * p2.land[t] / this.water.land[k] : 0;
  }
  samplePatch(t) {
    const p2 = this.partition, l = p2.land[t], s = p2.sea[t], a = l + s;
    return { patch: t, parent: p2.parent[t], landFraction: l / a, heightM: p2.heightM[t], airK: this.airK(t), landK: this.landK[t], seaK: this.seaK[t], snowMm: l > 0 ? this.snow[t] / l : 0, iceKgM2: s > 0 ? this.ice[t] / s : 0, landIceKgM2: l > 0 ? this.grounded[t] / l : 0, shelfLandKgM2: l > 0 ? this.shelfLand[t] / l : 0, shelfSeaKgM2: s > 0 ? this.shelfSea[t] / s : 0, soilMm: l > 0 ? this.soil[t] / l : 0, surfaceMm: this.surface[t] / a, rainMmDay: 86400 * this.rain[t] / a, snowMmDay: 86400 * this.snowfall[t] / a, meltMmDay: l > 0 ? 86400 * this.melt[t] / l : 0 };
  }
  sample(u4, v2) {
    if (v2 > 1e-12 && v2 < 1 - 1e-12) return this.samplePatch(partitionCell(this.model.grid, this.partition, u4, v2));
    const p2 = this.partition, g = this.model.grid, row = v2 <= 1e-12 ? 0 : g.height - 1;
    const out2 = this.samplePatch(p2.offset[row * g.width]);
    let total = 0, land = 0, sea = 0;
    const keys = ["heightM", "airK", "landK", "seaK", "snowMm", "iceKgM2", "landIceKgM2", "shelfLandKgM2", "shelfSeaKgM2", "soilMm", "surfaceMm", "rainMmDay", "snowMmDay", "meltMmDay"];
    for (const key of keys) out2[key] = 0;
    const landKeys = /* @__PURE__ */ new Set(["heightM", "landK", "snowMm", "landIceKgM2", "shelfLandKgM2", "soilMm", "meltMmDay"]), seaKeys = /* @__PURE__ */ new Set(["seaK", "iceKgM2", "shelfSeaKgM2"]);
    for (let x = 0; x < g.width; x++) {
      const k = row * g.width + x, q = p2.level[k], start2 = p2.offset[k] + (row === 0 ? 0 : q * (q - 1));
      for (let t = start2; t < start2 + q; t++) {
        const s = this.samplePatch(t), l = p2.land[t], wet = p2.sea[t], a = l + wet;
        total += a;
        land += l;
        sea += wet;
        for (const key of keys) out2[key] += s[key] * (landKeys.has(key) ? l : seaKeys.has(key) ? wet : a);
      }
    }
    for (const key of keys) out2[key] /= landKeys.has(key) ? land || 1 : seaKeys.has(key) ? sea || 1 : total;
    out2.landFraction = land / total;
    return out2;
  }
  checkpoint() {
    const result = { partition: structuredClone(this.partition), landK: this.landK.slice(), seaK: this.seaK.slice(), rain: this.rain.slice(), snowfall: this.snowfall.slice(), melt: this.melt.slice() };
    for (const key of stores) result[key] = this[key].slice();
    return result;
  }
  restore(s) {
    for (const key of [...stores, "landK", "seaK", "rain", "snowfall", "melt"]) this[key].set(s[key]);
    this.lastLand.set(this.model.landTemperatureK);
    this.lastSea.set(this.model.oceanTemperatureK);
    this.validate();
  }
  validate() {
    const p2 = this.partition, w2 = this.water, m2 = this.model;
    for (let k = 0; k < w2.grid.count; k++) {
      let land = 0, sea = 0;
      for (let t = p2.offset[k]; t < p2.offset[k + 1]; t++) {
        land += p2.land[t];
        sea += p2.sea[t];
      }
      if (Math.abs(land - w2.land[k]) > 1e-12 || Math.abs(sea - (1 - w2.land[k])) > 1e-12) throw new Error("Refined surface area mismatch");
      for (const kind of stores) {
        let sum3 = 0;
        for (let t = p2.offset[k]; t < p2.offset[k + 1]; t++) sum3 += this[kind][t];
        if (Math.abs(sum3 - w2[coarse[kind]][k]) > Math.max(1e-8, Math.abs(sum3) * 1e-10)) throw new Error(`Refined ${kind} ledger mismatch`);
      }
      if (Math.abs(this.meanTemperature(k, false) - m2.landTemperatureK[k]) > 1e-9 || Math.abs(this.meanTemperature(k, true) - m2.oceanTemperatureK[k]) > 1e-9) throw new Error("Refined heat ledger mismatch");
    }
  }
};
function decodeRefinedCheckpoint(value, n2) {
  if (value == null) return null;
  const d2 = record(value), raw2 = record(d2.partition), level = field(raw2.level, "refinement levels", n2, 1, 8);
  if (level.some((q) => q !== 1 && q !== 4 && q !== 8)) throw new Error("Invalid refinement level");
  const offset = field(raw2.offset, "refinement offsets", n2 + 1, 0, MAX_SURFACE_PATCHES);
  let count = 0;
  for (let k = 0; k < n2; k++) {
    if (offset[k] !== count) throw new Error("Invalid refinement offsets");
    count += level[k] ** 2;
  }
  if (offset[n2] !== count || count > MAX_SURFACE_PATCHES) throw new Error("Invalid refinement size");
  const parents = field(raw2.parent, "refinement parent", count, 0, n2 - 1);
  if (parents.some((v2) => !Number.isInteger(v2))) throw new Error("Invalid refinement parent");
  const p2 = { level: Uint8Array.from(level), offset: Int32Array.from(offset), parent: Int32Array.from(parents), land: field(raw2.land, "refinement land area", count, 0, 1), sea: field(raw2.sea, "refinement sea area", count, 0, 1), heightM: field(raw2.heightM, "refinement height", count, 0, 1e6), u: field(raw2.u, "refinement longitude", count, 0, 1), v: field(raw2.v, "refinement latitude", count, 0, 1) };
  for (let k = 0; k < n2; k++) for (let t = p2.offset[k]; t < p2.offset[k + 1]; t++) if (p2.parent[t] !== k || p2.land[t] + p2.sea[t] <= 0) throw new Error("Invalid refinement ownership");
  const result = { partition: p2 };
  for (const key of [...stores, "landK", "seaK", "rain", "snowfall", "melt"]) result[key] = field(d2[key], `refinement ${key}`, count, 0, key.endsWith("K") ? 1e5 : 1e30);
  for (let t = 0; t < count; t++) {
    if (p2.land[t] === 0 && result.snow[t] + result.grounded[t] + result.shelfLand[t] + result.soil[t] > 0 || p2.sea[t] === 0 && result.ice[t] + result.shelfSea[t] > 0) throw new Error("Refined store requires surface");
  }
  return result;
}

// runtime-state.ts
function record(v2) {
  if (!v2 || typeof v2 !== "object" || Array.isArray(v2)) throw new Error("Expected snapshot object");
  return v2;
}
function scalar(v2, name, min = -1e30, max = 1e30, integer = false) {
  if (typeof v2 !== "number" || !Number.isFinite(v2) || v2 < min || v2 > max || integer && !Number.isSafeInteger(v2)) throw new Error(`Invalid ${name}`);
  return v2;
}
function boolean(v2) {
  if (typeof v2 !== "boolean") throw new Error("Invalid snapshot switch");
  return v2;
}
function field(v2, name, n2, min = -1e30, max = 1e30) {
  if (!Array.isArray(v2) && !(v2 instanceof Float64Array) && !(v2 instanceof Uint8Array) && !(v2 instanceof Int32Array) || v2.length !== n2) throw new Error(`Invalid ${name} dimensions`);
  return Float64Array.from(v2, (x) => scalar(x, name, min, max));
}
function thermalConfig(v2) {
  const c = record(v2);
  return { emissivity: scalar(c.emissivity, "emissivity", 0.1, 1), landHeatCapacity: scalar(c.landHeatCapacity, "heat capacity", 1e5, 1e8), oceanDepthM: scalar(c.oceanDepthM, "mixed layer", 0.1, 100), diffusion: scalar(c.diffusion, "diffusion", 0, 5), ...c.separateReservoirs === void 0 ? {} : { separateReservoirs: boolean(c.separateReservoirs) }, ...c.airRadiationFraction === void 0 ? {} : { airRadiationFraction: scalar(c.airRadiationFraction, "air radiative fraction", 0, 1) } };
}
function waterConfig(v2) {
  const c = record(v2);
  if (c.moistureScheme !== void 0 && c.moistureScheme !== "transport") throw new Error("Invalid moisture scheme");
  if (c.upliftScheme !== void 0 && (c.upliftScheme !== "advective" && c.upliftScheme !== "eddy-front")) throw new Error("Invalid uplift scheme");
  return { ...c.upliftScheme === void 0 ? {} : { upliftScheme: c.upliftScheme }, ...c.consistentLiftTemperature === void 0 ? {} : { consistentLiftTemperature: boolean(c.consistentLiftTemperature) }, ...c.buoyantConvection === void 0 ? {} : { buoyantConvection: boolean(c.buoyantConvection) }, ...c.coldFrontDisplacement === void 0 ? {} : { coldFrontDisplacement: boolean(c.coldFrontDisplacement) }, ...c.moistureScheme === "transport" ? { moistureScheme: "transport" } : {}, ...c.liquidOceanEvaporation === void 0 ? {} : { liquidOceanEvaporation: boolean(c.liquidOceanEvaporation) }, ...c.compensatedOceanTransfers === void 0 ? {} : { compensatedOceanTransfers: boolean(c.compensatedOceanTransfers) }, evaporationFraction: scalar(c.evaporationFraction, "evaporation fraction", 0, 1), soilCapacityKgM2: scalar(c.soilCapacityKgM2, "soil capacity", 1, 1e3), initialOceanDepthM: scalar(c.initialOceanDepthM, "water inventory", 0, 1e4), windMps: scalar(c.windMps, "wind", -100, 100), moistureDiffusivityM2s: scalar(c.moistureDiffusivityM2s, "moisture mixing", 0, 1e7), routingSpeedMps: scalar(c.routingSpeedMps, "routing speed", 0.01, 10) };
}
function environmentConfig(v2) {
  const c = record(v2);
  if (c.circulationScheme !== void 0 && !isCirculationScheme(c.circulationScheme)) throw new Error("Invalid circulation scheme");
  if (c.boundaryLayerDepthM !== void 0 && !fullWindDrag(c.circulationScheme)) throw new Error("Pressure boundary-layer depth requires full wind drag");
  if (c.pressureLayerDepthM !== void 0 && c.circulationScheme === void 0) throw new Error("Thermal pressure-layer depth requires a pressure scheme");
  return { ...c.pressureLayerDepthM === void 0 ? {} : { pressureLayerDepthM: scalar(c.pressureLayerDepthM, "thermal pressure-layer depth", 100, 5e3) }, ...c.boundaryLayerDepthM === void 0 ? {} : { boundaryLayerDepthM: scalar(c.boundaryLayerDepthM, "pressure boundary-layer depth", 100, 5e3) }, ...c.circulationScheme === void 0 ? {} : { circulationScheme: c.circulationScheme }, oceanStrengthMps: scalar(c.oceanStrengthMps, "ocean current", 0, 2), vegetation: boolean(c.vegetation), iceAlbedo: boolean(c.iceAlbedo), terrainWater: c.terrainWater === void 0 ? false : boolean(c.terrainWater), glaciers: c.glaciers === void 0 ? false : boolean(c.glaciers), dynamicCirculation: c.dynamicCirculation === void 0 ? false : boolean(c.dynamicCirculation), ...c.conductiveSeaIce === void 0 ? {} : { conductiveSeaIce: boolean(c.conductiveSeaIce) }, ...c.underIceOcean === void 0 ? {} : { underIceOcean: boolean(c.underIceOcean) }, ...c.separateSurfaceAlbedo === void 0 ? {} : { separateSurfaceAlbedo: boolean(c.separateSurfaceAlbedo) } };
}
function decodeRuntimeState(value) {
  const d2 = record(value), g = record(d2.grid);
  if (d2.version !== 1) throw new Error("Unsupported simulation state version");
  const width = scalar(g.width, "grid width", 4, 8192, true), height = scalar(g.height, "grid height", 2, 4096, true), n2 = width * height, sn = SURFACE_WIDTH * SURFACE_HEIGHT;
  if (n2 > 16384) throw new Error("Simulation grid too large");
  const result = { version: 1, grid: { width, height }, enabled: boolean(d2.enabled), waterEnabled: boolean(d2.waterEnabled), config: thermalConfig(d2.config), waterConfig: waterConfig(d2.waterConfig), environmentConfig: environmentConfig(d2.environmentConfig), iceInventory: decodeIceInventory(d2.iceInventory), state: null };
  if (result.environmentConfig.circulationScheme && result.environmentConfig.dynamicCirculation && (!result.config.separateReservoirs || result.waterConfig.moistureScheme !== "transport")) throw new Error("Pressure circulation requires separate dynamic transport reservoirs");
  if (result.environmentConfig.conductiveSeaIce && !result.config.separateReservoirs) throw new Error("Conductive sea ice requires separate thermal reservoirs");
  if (result.environmentConfig.separateSurfaceAlbedo && !result.config.separateReservoirs) throw new Error("Separate surface albedo requires separate thermal reservoirs");
  if (d2.refinement !== void 0) {
    if (d2.refinement !== "balanced" && d2.refinement !== "high") throw new Error("Invalid refinement quality");
    result.refinement = d2.refinement;
  }
  if (d2.state === null) return result;
  if (!result.enabled) throw new Error("Disabled simulation has active state");
  const s = record(d2.state), t = record(s.thermal), ref = record(s.surfaceReference), initial2 = record(s.surfaceInitial);
  const f = (o2, key, len = n2, min = 0, max = 1e30) => field(o2[key], key, len, min, max);
  const thermal = {
    temperatureK: f(t, "temperatureK", n2, 0, 1e5),
    absorbedWm2: f(t, "absorbedWm2"),
    albedo: f(t, "albedo", n2, 0, 1),
    steps: scalar(t.steps, "steps", 0, Number.MAX_SAFE_INTEGER, true),
    radiationJm2: scalar(t.radiationJm2, "radiation"),
    exchangeJm2: scalar(t.exchangeJm2, "exchange"),
    radiationCorrection: scalar(t.radiationCorrection, "radiation correction"),
    exchangeCorrection: scalar(t.exchangeCorrection, "exchange correction")
  };
  if (result.config.separateReservoirs) {
    thermal.landTemperatureK = f(t, "landTemperatureK", n2, 0, 1e5);
    thermal.oceanTemperatureK = f(t, "oceanTemperatureK", n2, 0, 1e5);
  } else if (t.landTemperatureK !== void 0 || t.oceanTemperatureK !== void 0) throw new Error("Unexpected separate thermal reservoirs");
  let water = null, vegetation = null;
  if (result.waterEnabled) {
    const w2 = record(s.water), v2 = record(s.vegetation), wind = Math.abs(result.waterConfig.windMps) + 1e-9;
    let routing = null;
    let glacier = null;
    const landIceKgM2 = w2.landIceKgM2 === void 0 && !result.environmentConfig.glaciers ? new Float64Array(n2) : f(w2, "landIceKgM2");
    const landIceCorrection = w2.landIceCorrection === void 0 && !result.environmentConfig.glaciers ? new Float64Array(n2) : f(w2, "landIceCorrection", n2, -1e30);
    if (landIceCorrection.some((v3, i) => Math.abs(v3) > Math.max(1e-12, Number.EPSILON * landIceKgM2[i]))) throw new Error("Invalid grounded ice compensation");
    if (result.environmentConfig.glaciers) {
      const g2 = record(w2.glacier);
      glacier = { erodedM: f(g2, "erodedM"), sedimentM: f(g2, "sedimentM"), depositedM: f(g2, "depositedM"), speedMps: f(g2, "speedMps"), outflowM3S: f(g2, "outflowM3S"), limitedCells: scalar(g2.limitedCells, "ice limiter count", 0, 4 * n2, true), ...g2.erodedVolumeM === void 0 ? {} : { erodedVolumeM: f(g2, "erodedVolumeM") }, ...g2.bedrockM === void 0 ? {} : { bedrockM: f(g2, "bedrockM", n2, -12e3, 1e6) } };
    } else if (w2.glacier !== void 0 && w2.glacier !== null || !result.iceInventory && landIceKgM2.some((v3) => v3 !== 0)) throw new Error("Unexpected land ice state");
    if (result.environmentConfig.terrainWater) {
      const r = record(w2.routing), length = scalar(r.volumeM3?.length, "terrain routing count", 4, 25e4, true);
      const receivers = f(r, "receiverSide", length, -1, 3 * length - 1);
      if (receivers.some((v3) => !Number.isInteger(v3))) throw new Error("Invalid terrain routing side");
      routing = { volumeM3: f(r, "volumeM3", length), fluxM3S: f(r, "fluxM3S", length), receiverSide: new Int32Array(receivers) };
    } else if (w2.routing !== void 0 && w2.routing !== null) throw new Error("Unexpected terrain routing state");
    const ocean = scalar(w2.oceanGlobalKgM2, "ocean store", 0), correctionBound = 4 * Number.EPSILON * Math.max(1, ocean);
    if (w2.oceanCorrection !== void 0 && !result.waterConfig.compensatedOceanTransfers) throw new Error("Ocean compensation requires its accumulation switch");
    water = { snowfallKgM2S: w2.snowfallKgM2S === void 0 || w2.snowfallKgM2S === null ? null : f(w2, "snowfallKgM2S"), atmosphereKgM2: f(w2, "atmosphereKgM2"), soilKgM2: f(w2, "soilKgM2"), surfaceKgM2: f(w2, "surfaceKgM2"), snowKgM2: f(w2, "snowKgM2"), seaIceKgM2: f(w2, "seaIceKgM2"), meltKgM2S: f(w2, "meltKgM2S"), precipitationKgM2S: f(w2, "precipitationKgM2S"), evaporationKgM2S: f(w2, "evaporationKgM2S"), dischargeM3S: f(w2, "dischargeM3S"), windEastMps: f(w2, "windEastMps", n2, -wind, wind), windNorthMps: f(w2, "windNorthMps", n2, -wind, wind), oceanGlobalKgM2: ocean, ...w2.oceanCorrection === void 0 ? {} : { oceanCorrection: scalar(w2.oceanCorrection, "ocean compensation", -correctionBound, correctionBound) }, elapsedS: scalar(w2.elapsedS, "water age", 0, Number.MAX_SAFE_INTEGER), initialTotalMm: scalar(w2.initialTotalMm, "initial water", 0), routing, landIceKgM2, landIceCorrection, glacier, shelfLandIceKgM2: w2.shelfLandIceKgM2 === void 0 ? new Float64Array(n2) : f(w2, "shelfLandIceKgM2"), shelfSeaIceKgM2: w2.shelfSeaIceKgM2 === void 0 ? new Float64Array(n2) : f(w2, "shelfSeaIceKgM2") };
    if (w2.landPrecipitationKgM2S !== void 0) {
      if (result.waterConfig.moistureScheme !== "transport") throw new Error("Unexpected land precipitation");
      water.landPrecipitationKgM2S = f(w2, "landPrecipitationKgM2S");
      if (water.landPrecipitationKgM2S.some((p2, i) => p2 > water.precipitationKgM2S[i] + 1e-12)) throw new Error("Invalid land precipitation allocation");
    }
    vegetation = { meanK: f(v2, "meanK", sn, 0, 1e5), rainMm: f(v2, "rainMm", sn), cover: f(v2, "cover", sn, 0, 1), weights: f(v2, "weights", sn * Object.keys(BIOMES).length, 0, 1) };
    const types2 = Object.keys(BIOMES).length;
    for (let i = 0; i < sn; i++) {
      let sum3 = 0;
      for (let b = 0; b < types2; b++) sum3 += vegetation.weights[i * types2 + b];
      if (Math.abs(sum3 - 1) > 1e-8) throw new Error("Invalid vegetation mixture");
    }
  } else if (s.water !== null || s.vegetation !== null || s.initialEnthalpy !== null) throw new Error("Unexpected water state");
  let circulation = null;
  if (result.waterEnabled && result.environmentConfig.dynamicCirculation) {
    const c = record(s.circulation), a = record(c.atmosphere), o2 = record(c.ocean), limit = Math.abs(result.waterConfig.windMps) * circulationOffsetFactor(result.environmentConfig.circulationScheme, result.waterConfig.moistureScheme === "transport" && !!result.config.separateReservoirs), speed = result.environmentConfig.oceanStrengthMps / 4;
    circulation = { atmosphere: { eastMps: field(a.eastMps, "circulation east", n2, -limit, limit), northMps: field(a.northMps, "circulation north", n2, -limit, limit) }, ocean: { circulationMps: field(o2.circulationMps, "ocean circulation", width * (height - 1), -speed, speed) } };
  } else if (s.circulation !== void 0 && s.circulation !== null) throw new Error("Unexpected circulation state");
  const nullable = (key, len) => result.waterEnabled ? f(s, key, len) : s[key] === null ? null : (() => {
    throw new Error(`Unexpected ${key}`);
  })();
  const optionalIce = (key, len) => result.waterEnabled ? s[key] === void 0 && !result.environmentConfig.glaciers ? new Float64Array(len) : f(s, key, len) : null;
  result.state = {
    land: f(s, "land", n2, 0, 1),
    height: f(s, "height", n2, 0, 1),
    localLand: f(s, "localLand", sn, 0, 1),
    localHeight: f(s, "localHeight", sn, 0, 1),
    epochS: scalar(s.epochS, "epoch", 0, Number.MAX_SAFE_INTEGER),
    stepS: scalar(s.stepS, "step", Number.MIN_VALUE, 1800),
    lastTarget: scalar(s.lastTarget, "target time", 0, Number.MAX_SAFE_INTEGER),
    initialEnergyJm2: scalar(s.initialEnergyJm2, "initial heat", 0),
    initialEnthalpy: result.waterEnabled ? scalar(s.initialEnthalpy, "initial enthalpy") : null,
    thermal,
    circulation,
    radiationScale: f(s, "radiationScale", n2, 0.55, 1),
    water,
    vegetation,
    initialTemperature: f(s, "initialTemperature", n2, 0, 1e5),
    initialSoil: f(s, "initialSoil", n2, 0, 1),
    initialSnow: nullable("initialSnow", n2),
    initialIce: nullable("initialIce", n2),
    initialLandIce: optionalIce("initialLandIce", n2),
    localLandIceSeed: optionalIce("localLandIceSeed", sn),
    localSnowSeed: nullable("localSnowSeed", sn),
    localIceSeed: nullable("localIceSeed", sn),
    surfaceReference: { meanTemperatureK: f(ref, "meanTemperatureK", sn, 0, 1e5), warmestTemperatureK: f(ref, "warmestTemperatureK", sn, 0, 1e5), annualRainMm: f(ref, "annualRainMm", sn), monthlyIceCooling: f(ref, "monthlyIceCooling", 12 * sn, -1e30) },
    surfaceInitial: { temperatureK: f(initial2, "temperatureK", sn, 0, 1e5), soilFraction: f(initial2, "soilFraction", sn, 0, 1) },
    iceEnergy: f(s, "iceEnergy", sn)
  };
  const state = result.state, age = thermal.steps * state.stepS, time = state.epochS + age;
  state.surfaceReservoirInitial = s.surfaceReservoirInitial == null ? null : (() => {
    const p2 = record(s.surfaceReservoirInitial);
    return { landTemperatureK: f(p2, "landTemperatureK", sn, 0, 1e5), oceanTemperatureK: f(p2, "oceanTemperatureK", sn, 0, 1e5), initialLandTemperatureK: f(p2, "initialLandTemperatureK", n2, 0, 1e5), initialOceanTemperatureK: f(p2, "initialOceanTemperatureK", n2, 0, 1e5) };
  })();
  state.shelves = s.shelves == null ? null : (() => {
    const p2 = record(s.shelves);
    return { initialLand: f(p2, "initialLand"), initialSea: f(p2, "initialSea"), localLandSeed: f(p2, "localLandSeed", sn), localSeaSeed: f(p2, "localSeaSeed", sn) };
  })();
  if (result.config.separateReservoirs && !state.surfaceReservoirInitial) throw new Error("Missing surface reservoir initial temperatures");
  if (!result.config.separateReservoirs && state.surfaceReservoirInitial) throw new Error("Unexpected surface reservoir initial temperatures");
  if (!result.waterEnabled && state.shelves) throw new Error("Unexpected floating shelf display seeds");
  if (water && !state.shelves && (water.shelfLandIceKgM2.some((v2) => v2 > 0) || water.shelfSeaIceKgM2.some((v2) => v2 > 0))) throw new Error("Missing floating shelf display seeds");
  if (result.iceInventory && result.waterEnabled && !state.shelves) throw new Error("Observed ice requires conserved ice reservoirs");
  if (water?.landIceKgM2.some((v2, i) => state.land[i] === 0 && v2 !== 0)) throw new Error("Grounded ice requires land");
  if (water?.shelfLandIceKgM2.some((v2, i) => state.land[i] === 0 && v2 !== 0) || water?.shelfSeaIceKgM2.some((v2, i) => state.land[i] === 1 && v2 !== 0)) throw new Error("Ice shelf requires its thermal surface");
  if (s.refined !== void 0) state.refined = decodeRefinedCheckpoint(s.refined, n2);
  if (state.refined) {
    const p2 = state.refined.partition;
    for (let k = 0; k < n2; k++) {
      const q = p2.level[k];
      for (let t2 = p2.offset[k]; t2 < p2.offset[k + 1]; t2++) {
        const a = t2 - p2.offset[k], u4 = (k % width + (a % q + 0.5) / q) / width, v2 = Math.acos(1 - 2 * (Math.floor(k / width) + (Math.floor(a / q) + 0.5) / q) / height) / Math.PI;
        if (Math.abs(p2.u[t2] - u4) > 1e-12 || Math.abs(p2.v[t2] - v2) > 1e-12) throw new Error("Invalid refinement registration");
      }
    }
  }
  if (!!state.refined !== !!(result.refinement && result.config.separateReservoirs && water)) throw new Error("Missing or unexpected refined reservoirs");
  if (water?.snowfallKgM2S?.some((v2, i) => v2 > (water.landPrecipitationKgM2S?.[i] ?? water.precipitationKgM2S[i] * (state.refined ? 1 : state.land[i])) + 1e-12)) throw new Error("Snowfall exceeds precipitation on land");
  if (!Number.isFinite(time) || time > Number.MAX_SAFE_INTEGER || time > state.lastTarget + 1e-6 || state.lastTarget - time >= state.stepS + 1e-6) throw new Error("Inconsistent simulation time");
  if (water && Math.abs(water.elapsedS - age) > Math.max(1e-6, age * 1e-10)) throw new Error("Inconsistent water age");
  return result;
}

// vegetation.ts
var YEAR = 365.2425 * 86400;
var clamp4 = (v2) => Math.max(0, Math.min(1, v2));
var types = Object.keys(BIOMES);
var VegetationModel = class {
  constructor(reference2) {
    this.reference = reference2;
    this.meanK = reference2.meanTemperatureK.slice();
    this.rainMm = reference2.annualRainMm.slice();
    this.cover = new Float64Array(this.meanK.length);
    this.weights = new Float64Array(this.meanK.length * types.length);
    for (let i = 0; i < this.meanK.length; i++) {
      const biome = classifyBiome(this.meanK[i], reference2.warmestTemperatureK[i], this.rainMm[i]);
      this.weights[i * types.length + types.indexOf(biome)] = 1;
      this.cover[i] = this.suitability(i);
    }
  }
  reference;
  meanK;
  rainMm;
  cover;
  weights;
  suitability(i) {
    const warm = this.reference.warmestTemperatureK[i] + this.meanK[i] - this.reference.meanTemperatureK[i];
    return clamp4((warm - 268.15) / 15) * clamp4((323.15 - this.meanK[i]) / 15) * clamp4(this.rainMm[i] / 800);
  }
  step(dt2, temperature, rainMmDay, soil) {
    const climate = -Math.expm1(-dt2 / YEAR), composition = -Math.expm1(-dt2 / (5 * YEAR));
    for (let i = 0; i < this.meanK.length; i++) {
      this.meanK[i] += (temperature[i] - this.meanK[i]) * climate;
      this.rainMm[i] += (rainMmDay[i] * 365.2425 - this.rainMm[i]) * climate;
      const target = this.suitability(i) * (0.35 + 0.65 * clamp4(soil[i] / 0.5));
      this.cover[i] += (target - this.cover[i]) * -Math.expm1(-dt2 / ((target < this.cover[i] ? 0.5 : 3) * YEAR));
      const warm = this.reference.warmestTemperatureK[i] + this.meanK[i] - this.reference.meanTemperatureK[i];
      const targetBiome = types.indexOf(classifyBiome(this.meanK[i], warm, this.rainMm[i]));
      for (let b = 0; b < types.length; b++) this.weights[i * types.length + b] += ((b === targetBiome ? 1 : 0) - this.weights[i * types.length + b]) * composition;
    }
  }
  sample(i) {
    const color = [0, 0, 0];
    let best = 0;
    for (let b = 0; b < types.length; b++) {
      if (this.weights[i * types.length + b] > this.weights[i * types.length + best]) best = b;
      const rgb = BIOMES[types[b] === "ice" ? "barren" : types[b]].color;
      for (let c = 0; c < 3; c++) color[c] += rgb[c] * this.weights[i * types.length + b];
    }
    const bare = BIOMES.barren.color, greenness = 0.4 + 0.6 * this.cover[i];
    return { biome: types[best], vegetationFraction: this.cover[i], color: color.map((c, j) => c * greenness + bare[j] * (1 - greenness)) };
  }
  checkpoint() {
    return { meanK: this.meanK.slice(), rainMm: this.rainMm.slice(), cover: this.cover.slice(), weights: this.weights.slice() };
  }
  restore(s) {
    this.meanK.set(s.meanK);
    this.rainMm.set(s.rainMm);
    this.cover.set(s.cover);
    this.weights.set(s.weights);
  }
};

// surface-reservoirs.ts
function aggregateSurface(grid, surface, field2, mask) {
  const sum3 = new Float64Array(grid.count), weight = new Float64Array(grid.count);
  for (let j = 0; j < surface.height; j++) {
    const top = Math.max(0, (j - 0.5) / (surface.height - 1)) * Math.PI, bottom = Math.min(1, (j + 0.5) / (surface.height - 1)) * Math.PI;
    const area = Math.cos(top) - Math.cos(bottom);
    for (let x = 0; x < surface.width; x++) {
      const i = j * surface.width + x, k = thermalCell(grid, (x + 0.5) / surface.width, j / (surface.height - 1)), w2 = area * mask[i];
      sum3[k] += w2 * field2[i];
      weight[k] += w2;
    }
  }
  return sum3.map((v2, k) => weight[k] > 0 ? v2 / weight[k] : 0);
}
function downscaleStore(grid, surface, current, initial2, fraction, localInitial) {
  const a = resampleClimateField(grid, Float64Array.from(current, (v2, i) => fraction[i] > 0 ? v2 / fraction[i] : 0), surface);
  const b = resampleClimateField(grid, Float64Array.from(initial2, (v2, i) => fraction[i] > 0 ? v2 / fraction[i] : 0), surface);
  return a.map((v2, i) => b[i] > 1e-9 ? localInitial[i] * Math.min(1, v2 / b[i]) + Math.max(0, v2 - b[i]) : v2);
}

// thermal-runtime.ts
function oldRefinedLandEstimate(water, refined) {
  if (water.landPrecipitationKgM2S || !refined) return void 0;
  const p2 = refined.partition, estimate2 = new Float64Array(water.precipitationKgM2S.length);
  for (let t = 0; t < p2.parent.length; t++) estimate2[p2.parent[t]] += refined.rain[t] * p2.land[t] / (p2.land[t] + p2.sea[t]);
  for (let k = 0; k < estimate2.length; k++) estimate2[k] = Math.min(water.precipitationKgM2S[k], Math.max(water.snowfallKgM2S?.[k] ?? 0, estimate2[k]));
  return estimate2;
}
var ThermalRuntime = class _ThermalRuntime {
  constructor(grid = makeThermalGrid()) {
    this.grid = grid;
  }
  grid;
  refinement;
  refinedSurface = null;
  refinedDisplay = null;
  iceInventory = null;
  surfaceReservoirInitial = null;
  shelves = null;
  localShelfLand = null;
  localShelfSea = null;
  surfaceLandTemperature = null;
  surfaceOceanTemperature = null;
  environmentConfig = { ...DEFAULT_ENVIRONMENT };
  environment = null;
  vegetation = null;
  initialSnow = null;
  initialIce = null;
  initialLandIce = null;
  localLandIceSeed = null;
  localLandIce = null;
  localSnowSeed = null;
  localIceSeed = null;
  localSnow = null;
  localIce = null;
  enabled = false;
  waterEnabled = false;
  waterConfig = { ...DEFAULT_WATER };
  water = null;
  waterTexture = null;
  surfaceTexture = null;
  config = { ...DEFAULT_THERMAL };
  model = null;
  status = "Thermal model off";
  land = null;
  landElevation = null;
  key = "";
  presented = null;
  lastTarget = 0;
  texture = null;
  wind = null;
  surfaceReference = null;
  initialSoil = null;
  surfaceGrid = makeSurfaceGrid();
  surfaceSampler = null;
  surfaceTerrain = null;
  terrainSource = null;
  surfaceInitial = null;
  initialTemperature = null;
  surfaceTemperature = null;
  surfaceSoil = null;
  iceEnergy = null;
  snapshot() {
    const m2 = this.model;
    return {
      version: 1,
      grid: { width: this.grid.width, height: this.grid.height },
      enabled: this.enabled,
      waterEnabled: this.waterEnabled,
      config: { ...this.config },
      waterConfig: { ...this.waterConfig },
      environmentConfig: { ...this.environmentConfig },
      iceInventory: structuredClone(this.iceInventory),
      ...this.refinement ? { refinement: this.refinement } : {},
      state: m2 ? {
        land: this.land.slice(),
        height: this.landElevation.slice(),
        localLand: this.surfaceTerrain.land.slice(),
        localHeight: this.surfaceTerrain.height.slice(),
        ...this.refinedSurface ? { refined: this.refinedSurface.checkpoint() } : {},
        epochS: m2.epochS,
        stepS: m2.stepS,
        lastTarget: this.lastTarget,
        initialEnergyJm2: m2.initialEnergyJm2,
        initialEnthalpy: this.environment?.initialEnthalpy ?? null,
        circulation: this.environment?.checkpoint() ?? null,
        thermal: m2.checkpoint(),
        radiationScale: m2.radiationScale.slice(),
        water: this.water ? { ...this.water.checkpoint(), initialTotalMm: this.water.initialTotalMm } : null,
        vegetation: this.vegetation?.checkpoint() ?? null,
        initialTemperature: this.initialTemperature.slice(),
        initialSoil: this.initialSoil.slice(),
        initialSnow: this.initialSnow?.slice() ?? null,
        initialIce: this.initialIce?.slice() ?? null,
        initialLandIce: this.initialLandIce?.slice() ?? null,
        localLandIceSeed: this.localLandIceSeed?.slice() ?? null,
        localSnowSeed: this.localSnowSeed?.slice() ?? null,
        localIceSeed: this.localIceSeed?.slice() ?? null,
        surfaceReservoirInitial: structuredClone(this.surfaceReservoirInitial),
        shelves: structuredClone(this.shelves),
        surfaceReference: structuredClone(this.surfaceReference),
        surfaceInitial: { temperatureK: this.surfaceInitial.temperatureK.slice(), soilFraction: this.surfaceInitial.soilFraction.slice() },
        iceEnergy: this.iceEnergy.slice()
      } : null
    };
  }
  /** Build an independent candidate. Never generate climate or advance a step. */
  static fromSnapshot(value, planet, orbit) {
    const d2 = decodeRuntimeState(value), rt2 = new _ThermalRuntime(makeThermalGrid(d2.grid.width, d2.grid.height)), s = d2.state;
    rt2.enabled = d2.enabled;
    rt2.waterEnabled = d2.waterEnabled;
    rt2.config = d2.config;
    rt2.waterConfig = d2.waterConfig;
    rt2.environmentConfig = d2.environmentConfig;
    rt2.iceInventory = d2.iceInventory ?? null;
    rt2.refinement = d2.refinement;
    const orbitState = deriveOrbit(planet, orbit), unsupported = orbitState.solarDayS > orbitState.yearS / 20;
    if (!s) {
      if (rt2.waterEnabled && !rt2.enabled) throw new Error("Water requires an enabled thermal model");
      if (rt2.enabled && !unsupported) throw new Error("Active simulation is missing its state");
      return rt2;
    }
    if (unsupported) throw new Error("Snapshot climate incompatible with rotation");
    rt2.land = s.land;
    rt2.landElevation = s.height;
    rt2.surfaceTerrain = { land: s.localLand, height: s.localHeight };
    rt2.surfaceReference = s.surfaceReference;
    rt2.surfaceInitial = s.surfaceInitial;
    rt2.initialTemperature = s.initialTemperature;
    rt2.initialSoil = s.initialSoil;
    rt2.initialSnow = s.initialSnow;
    rt2.initialIce = s.initialIce;
    rt2.localSnowSeed = s.localSnowSeed;
    rt2.localIceSeed = s.localIceSeed;
    rt2.iceEnergy = s.iceEnergy;
    rt2.initialLandIce = s.initialLandIce;
    rt2.localLandIceSeed = s.localLandIceSeed;
    rt2.surfaceReservoirInitial = s.surfaceReservoirInitial ?? null;
    rt2.shelves = s.shelves ?? null;
    const m2 = rt2.model = new ThermalModel(planet, orbit, rt2.config, s.land, s.epochS, rt2.grid, { temperatureK: s.thermal.temperatureK, radiationScale: s.radiationScale, absorbedWm2: s.thermal.absorbedWm2, landTemperatureK: s.thermal.landTemperatureK, oceanTemperatureK: s.thermal.oceanTemperatureK }, s.initialEnergyJm2);
    if (s.water) {
      rt2.water = new WaterModel(rt2.grid, planet.radiusM, s.land, s.height.map((h) => h * planet.reliefM), m2.temperatureK, rt2.waterConfig, void 0, s.water.initialTotalMm);
      rt2.water.restore(s.water, rt2.waterConfig.moistureScheme === "transport" ? oldRefinedLandEstimate(s.water, s.refined) : void 0);
      if (rt2.iceInventory) rt2.water.glacierBedM = rt2.compatibleBed(planet);
      rt2.environment = new EnvironmentModel(m2, rt2.water, rt2.environmentConfig, s.initialEnthalpy);
      rt2.environment.restore(s.circulation);
      rt2.vegetation = new VegetationModel(s.surfaceReference);
      rt2.vegetation.restore(s.vegetation);
      if (s.refined) {
        rt2.refinedSurface = new RefinedSurface(m2, rt2.water, s.refined.partition);
        rt2.refinedSurface.restore(s.refined);
        rt2.refinedSurface.attach(rt2.environment);
      }
    }
    const step2 = Math.min(m2.stepS, rt2.water?.maxStepS ?? Infinity, rt2.refinedSurface?.maxStepS ?? Infinity);
    if (s.stepS > step2 + 1e-9) throw new Error("Snapshot step does not match model stability limit");
    m2.stepS = s.stepS;
    m2.restore(s.thermal);
    rt2.refreshEnvironment();
    rt2.environment?.atmosphere?.validateWinds(m2.timeS - (m2.steps > 0 ? m2.stepS / 2 : 0));
    if (m2.albedo.some((v2, i) => Math.abs(v2 - s.thermal.albedo[i]) > 8 * Number.EPSILON)) throw new Error("Saved albedo does not match frozen water and vegetation");
    if (rt2.water && rt2.environment) {
      const budget = rt2.water.diagnostics(), waterScale = Math.max(budget.totalMm, rt2.water.initialTotalMm);
      if (Math.abs(budget.residualMm) > Math.max(1e-6, 64 * Number.EPSILON * waterScale)) throw new Error("Saved water budget mismatch");
      const energyScale = Math.max(Math.abs(m2.energy()), Math.abs(rt2.environment.enthalpy()), Math.abs(rt2.environment.initialEnthalpy), Math.abs(m2.radiationJm2));
      if (Math.abs(rt2.environment.diagnostics().energyResidualJm2) > Math.max(1e-4, 128 * Number.EPSILON * energyScale)) throw new Error("Saved enthalpy budget mismatch");
    }
    rt2.key = rt2.modelKey(planet, orbit);
    rt2.lastTarget = s.lastTarget;
    rt2.presented = rt2.checkpoint();
    rt2.sync(planet, orbit, s.lastTarget, null);
    return rt2;
  }
  modelKey(planet, orbit) {
    return JSON.stringify([planet, orbit, this.config, this.waterEnabled, this.waterConfig, this.environmentConfig, this.iceInventory, this.refinement]);
  }
  /** Opt-in closure migration: preserve every stock and budget origin. */
  configureSurfacePhysics(options) {
    if (!this.model || !this.water || !this.environment || !this.config.separateReservoirs) throw new Error("Surface physics requires separate thermal/water reservoirs");
    if (options.separateSurfaceAlbedo !== void 0) this.environmentConfig.separateSurfaceAlbedo = options.separateSurfaceAlbedo;
    if (options.liquidOceanEvaporation !== void 0) this.water.config.liquidOceanEvaporation = this.waterConfig.liquidOceanEvaporation = options.liquidOceanEvaporation;
    this.refreshEnvironment();
    this.key = this.modelKey(this.model.planet, this.model.orbit);
    this.presented = this.checkpoint();
    this.texture = this.surfaceTexture = this.waterTexture = null;
    this.refinedDisplay = null;
  }
  initializeLakeLevels(levels) {
    if (!this.water?.routing || !this.model || this.model.steps !== 0 || this.water.elapsedS !== 0) throw new Error("Observed lake levels require an attached time-zero terrain");
    this.water.routing.initializeLakeLevels(this.water, levels);
    this.presented = this.checkpoint();
    this.texture = this.surfaceTexture = this.waterTexture = null;
    this.refinedDisplay = null;
  }
  compatibleBed(planet) {
    return this.landElevation.map((h, i) => h * planet.reliefM - (this.land[i] > 0 ? this.initialLandIce[i] / (917 * this.land[i]) : 0));
  }
  allocationScale(requested, current) {
    const mask = requested.map((v2) => v2 > 0 ? 1 : 0), weight = resampleClimateField(this.grid, mask, this.surfaceGrid);
    const ratio = resampleClimateField(this.grid, requested.map((v2, i) => v2 > 0 ? current[i] / v2 : 0), this.surfaceGrid);
    return ratio.map((v2, i) => weight[i] > 0 ? v2 / weight[i] : 0);
  }
  /** Retain panel references, replacing only with a fully prepared instance. */
  replaceWith(prepared) {
    Object.assign(this, prepared);
  }
  attachRestoredTerrain(land, height, source2) {
    if (!this.model) {
      this.setTerrain(land, height, source2);
      return;
    }
    const sampler = new SurfaceTerrainSampler(source2.directions, this.surfaceGrid), local = sampler.sample(source2.elevation);
    for (const [saved, generated] of [[this.land, land], [this.landElevation, height], [this.surfaceTerrain.land, local.land], [this.surfaceTerrain.height, local.height]]) {
      if (saved.length !== generated.length || saved.some((v2, i) => Math.abs(v2 - generated[i]) > 1e-12)) throw new Error("Simulation terrain does not match authored terrain");
    }
    this.surfaceSampler = sampler;
    this.terrainSource = source2;
    if (this.environmentConfig.terrainWater && this.water) this.attachRouting(this.model.planet);
    if (this.refinedSurface) {
      const expected = makeSurfacePartition(this.grid, land, height, source2, this.model.planet.reliefM, this.refinement), actual = this.refinedSurface.partition;
      for (const key of ["level", "offset", "parent", "land", "sea", "heightM", "u", "v"]) if (expected[key].length !== actual[key].length || expected[key].some((v2, i) => Math.abs(v2 - actual[key][i]) > 1e-10)) throw new Error("Refined topology does not match authored terrain");
      this.refinedSurface.setTerrainSource(source2);
    }
  }
  attachRouting(planet) {
    const source2 = this.terrainSource;
    if (!source2?.mesh) throw new Error("Terrain water requires the authored mesh");
    const network = terrainRoutingNetwork(source2.mesh, source2.elevation, this.grid, planet.radiusM, planet.reliefM, source2.quadElements, source2.drainage?.inlandLakeId, planet.oceanDepthM);
    if (source2.drainage) {
      network.endorheic = Int32Array.from(source2.drainage.basinId);
      network.terminal = Uint8Array.from(source2.drainage.terminal);
    }
    this.water.attachRouting(network);
  }
  invalidate() {
    this.refinedSurface = null;
    this.refinedDisplay = null;
    this.surfaceReservoirInitial = null;
    this.shelves = null;
    this.localShelfLand = this.localShelfSea = this.surfaceLandTemperature = this.surfaceOceanTemperature = null;
    this.environment = null;
    this.vegetation = null;
    this.initialSnow = this.initialIce = this.localSnowSeed = this.localIceSeed = this.localSnow = this.localIce = this.initialLandIce = this.localLandIceSeed = this.localLandIce = null;
    this.key = "";
    this.model = null;
    this.water = null;
    this.presented = null;
    this.texture = null;
    this.waterTexture = null;
    this.wind = null;
    this.surfaceTexture = null;
    this.surfaceReference = null;
    this.initialSoil = null;
    this.initialTemperature = null;
    this.surfaceInitial = null;
    this.surfaceTemperature = null;
    this.surfaceSoil = null;
    this.iceEnergy = null;
  }
  setTerrain(land, height = new Float64Array(this.grid.count), source2) {
    if (this.refinedSurface) {
      this.remapTerrain(land, height, source2 ?? null);
      return;
    }
    this.terrainSource = source2 ?? null;
    this.land = land.slice();
    this.landElevation = height.slice();
    if (source2) {
      if (this.surfaceSampler?.directions !== source2.directions) this.surfaceSampler = new SurfaceTerrainSampler(source2.directions, this.surfaceGrid);
      this.surfaceTerrain = this.surfaceSampler.sample(source2.elevation);
    } else this.surfaceTerrain = { land: resampleClimateField(this.grid, land, this.surfaceGrid).map((f) => Math.max(0, Math.min(1, f))), height: resampleClimateField(this.grid, height, this.surfaceGrid) };
    this.invalidate();
  }
  remapTerrain(land, height, source2, quality = this.refinement) {
    const old = this.refinedSurface, before = this.model, previous = this.water, thermal = before.checkpoint(), water = previous.checkpoint(), energy = before.energy();
    const part = makeSurfacePartition(this.grid, land, height, source2, before.planet.reliefM, quality);
    const radiationScale = height.map((h) => Math.max(0.55, Math.exp(-65e-4 * h * before.planet.reliefM / 288.15)));
    const m2 = new ThermalModel(before.planet, before.orbit, this.config, land, before.epochS, this.grid, { ...thermal, radiationScale }, before.initialEnergyJm2);
    m2.restore(thermal);
    if (m2.stepS < before.stepS - 1e-9) throw new Error("Terrain edit changes the stable integration step; reset climate explicitly");
    m2.stepS = before.stepS;
    const w2 = new WaterModel(this.grid, before.planet.radiusM, land, height.map((h) => h * before.planet.reliefM), m2.temperatureK, this.waterConfig, void 0, previous.initialTotalMm);
    w2.oceanGlobalKgM2 = previous.oceanGlobalKgM2;
    w2.oceanCorrection = previous.oceanCorrection;
    w2.atmosphereKgM2.set(previous.atmosphereKgM2);
    w2.elapsedS = previous.elapsedS;
    for (const key of ["precipitationKgM2S", "evaporationKgM2S", "meltKgM2S", "dischargeM3S"]) w2[key].set(previous[key]);
    w2.snowfallKgM2S = previous.snowfallKgM2S?.slice() ?? null;
    w2.setWinds(previous.windEastMps, previous.windNorthMps);
    w2.landPrecipitationKgM2S.set(previous.landPrecipitationKgM2S);
    w2.oceanPrecipitationKgM2S.set(previous.oceanPrecipitationKgM2S);
    w2.landPrecipitationKnown = previous.landPrecipitationKnown;
    if (this.environmentConfig.terrainWater) {
      if (!source2?.mesh) throw new Error("Refined terrain water requires the authored mesh");
      const network = terrainRoutingNetwork(source2.mesh, source2.elevation, this.grid, before.planet.radiusM, before.planet.reliefM, source2.quadElements, source2.drainage?.inlandLakeId, before.planet.oceanDepthM);
      if (source2.drainage) {
        network.endorheic = Int32Array.from(source2.drainage.basinId);
        network.terminal = Uint8Array.from(source2.drainage.terminal);
      }
      w2.attachRouting(network);
    }
    const r = RefinedSurface.remap(old, m2, w2, part, source2);
    if (Math.min(r.maxStepS, w2.maxStepS) < before.stepS - 1e-9) throw new Error("Terrain edit changes the refined stable step; reset climate explicitly");
    const factor = land.every((v2, i) => v2 === previous.land[i]) ? 1 : energy / m2.energy();
    m2.temperatureK.forEach((v2, i) => m2.temperatureK[i] = v2 * factor);
    r.landK.forEach((v2, i) => r.landK[i] = v2 * factor);
    r.seaK.forEach((v2, i) => r.seaK[i] = v2 * factor);
    r.aggregate();
    if (m2.temperatureK.some((v2) => v2 > 500) || r.landK.some((v2) => v2 > 500) || r.seaK.some((v2) => v2 > 500)) throw new Error("Terrain edit displaces too much stored heat for this fixed step; reset climate explicitly");
    const initialLandIce = w2.landIceKgM2.slice();
    if (this.iceInventory) w2.glacierBedM = height.map((h, i) => h * before.planet.reliefM - (land[i] > 0 ? initialLandIce[i] / (917 * land[i]) : 0));
    const e2 = new EnvironmentModel(m2, w2, this.environmentConfig, this.environment.initialEnthalpy);
    if (w2.glacier && water.glacier) {
      const g = water.glacier, bed = w2.glacier.bedrockM;
      w2.glacier.restore({ ...g, bedrockM: w2.glacierBedM ?? void 0, erodedM: g.erodedM.map((v2, i) => Math.min(v2, Math.max(0, bed[i]))), erodedVolumeM: g.erodedVolumeM ?? g.erodedM.map((v2, i) => v2 * previous.land[i]), speedMps: new Float64Array(this.grid.count), outflowM3S: new Float64Array(this.grid.count), limitedCells: 0 });
    }
    e2.restore(this.environment.checkpoint());
    r.attach(e2);
    if (w2.routing) {
      const network = w2.routing.network;
      r.setTerrainSource(source2);
      if (previous.routing && previous.routing.volumeM3.length === w2.routing.volumeM3.length) {
        for (let t = 0; t < network.cell.length; t++) w2.routing.volumeM3[t] = network.cell[t] >= 0 ? previous.routing.volumeM3[t] : 0;
        r.setTerrainSource(source2);
      }
      r.route(0);
    }
    r.validate();
    const sampler = source2 ? new SurfaceTerrainSampler(source2.directions, this.surfaceGrid) : null;
    const local = sampler ? sampler.sample(source2.elevation) : { land: resampleClimateField(this.grid, land, this.surfaceGrid).map((f) => Math.max(0, Math.min(1, f))), height: resampleClimateField(this.grid, height, this.surfaceGrid) };
    e2.refresh(aggregateSurface(this.grid, this.surfaceGrid, this.vegetation.cover, local.land));
    this.model = m2;
    this.water = w2;
    this.environment = e2;
    this.refinedSurface = r;
    this.refinement = quality;
    this.initialLandIce = initialLandIce;
    this.land = land.slice();
    this.landElevation = height.slice();
    this.terrainSource = source2;
    this.surfaceSampler = sampler;
    this.surfaceTerrain = local;
    this.texture = this.surfaceTexture = this.waterTexture = null;
    this.refinedDisplay = null;
    this.presented = null;
    this.key = this.modelKey(m2.planet, m2.orbit);
    this.sync(m2.planet, m2.orbit, this.lastTarget, null);
    this.presented = this.checkpoint();
  }
  get maxAdvanceS() {
    return this.model ? 32 * this.model.stepS : Infinity;
  }
  sample(u4, v2) {
    return this.model?.temperatureK[thermalCell(this.grid, u4, v2)] ?? null;
  }
  sampleWind(u4, v2) {
    if (!this.wind) return null;
    const k = thermalCell(this.grid, u4, v2);
    return { eastMps: this.wind.eastMps[k], northMps: this.wind.northMps[k] };
  }
  sampleSurface(u4, v2) {
    return this.surfaceReference && this.surfaceTemperature ? this.refinedSurface ? this.refinedAt(u4, v2) : this.surfaceAt(surfaceCell(this.surfaceGrid, u4, v2)) : null;
  }
  surfaceAt(k) {
    const r = this.surfaceReference;
    const climate = { meanTemperatureK: r.meanTemperatureK[k], warmestTemperatureK: r.warmestTemperatureK[k], annualRainMm: r.annualRainMm[k] };
    const base = surfaceCover(climate, this.surfaceTemperature[k], this.surfaceSoil[k]);
    if (!this.environment) {
      const surfaceTemperatureK2 = (this.surfaceTerrain.land[k] >= 0.5 ? this.surfaceLandTemperature?.[k] : this.surfaceOceanTemperature?.[k]) ?? this.surfaceTemperature[k];
      return { ...climate, localTemperatureK: this.surfaceTemperature[k], surfaceTemperatureK: surfaceTemperatureK2, seaIceFraction: seaIceFraction(this.iceEnergy[k]), vegetationFraction: 0, landIceM: 0, shelfIceM: 0, shelfIceFraction: 0, ...base };
    }
    const snow2 = Math.min(1, this.localSnow[k] / 30), ice2 = Math.min(1, this.localIce[k] / (917 * 0.5));
    const vegetation = this.vegetation.sample(k);
    const landIceM = (this.localLandIce?.[k] ?? 0) / 917, shelfIceM = (this.surfaceTerrain.land[k] * (this.localShelfLand?.[k] ?? 0) + (1 - this.surfaceTerrain.land[k]) * (this.localShelfSea?.[k] ?? 0)) / 917;
    const shelfLand = Math.min(1, (this.localShelfLand?.[k] ?? 0) / (917 * 5)), shelfSea = Math.min(1, (this.localShelfSea?.[k] ?? 0) / (917 * 5)), glacier = Math.max(Math.min(1, landIceM / 5), shelfLand);
    const color = vegetation.color.map((v2, c) => (v2 * (1 - glacier) + [190, 217, 224][c] * glacier) * (1 - snow2) + [234, 242, 240][c] * snow2);
    const localTemperatureK = this.config.separateReservoirs ? this.surfaceTemperature[k] : Math.min(this.surfaceTemperature[k], this.surfaceTerrain.land[k] < 0.5 && ice2 > 0 ? 271.35 : snow2 > 0 || glacier > 0 ? 273.15 : Infinity);
    const onLand = this.surfaceTerrain.land[k] >= 0.5;
    const surfaceTemperatureK = Math.min(onLand ? this.surfaceLandTemperature?.[k] ?? localTemperatureK : this.surfaceOceanTemperature?.[k] ?? localTemperatureK, onLand ? snow2 > 0 || glacier > 0 ? 273.15 : Infinity : ice2 > 0 ? 271.35 : shelfSea > 0 ? 273.15 : Infinity);
    return { ...climate, ...vegetation, localTemperatureK, surfaceTemperatureK, seaIceFraction: ice2, shelfIceM, shelfIceFraction: Math.max(shelfLand, shelfSea), snowFraction: snow2, landIceM, color };
  }
  /** Opt-in migration splits existing mass and sensible heat, not a new climate. */
  enableRefinement(quality) {
    if (!this.model || !this.water || !this.environment || !this.config.separateReservoirs) throw new Error("Refinement requires separate thermal/water reservoirs");
    if (this.refinedSurface) {
      this.remapTerrain(this.land, this.landElevation, this.terrainSource, quality);
      return;
    }
    const refined = RefinedSurface.create(this.model, this.water, this.landElevation, this.terrainSource, quality, (u4, v2, kind) => {
      const k = surfaceCell(this.surfaceGrid, u4, v2);
      return kind === "grounded" ? this.localLandIceSeed?.[k] ?? 0 : kind === "shelfLand" ? this.shelves?.localLandSeed[k] ?? 0 : kind === "shelfSea" ? this.shelves?.localSeaSeed[k] ?? 0 : kind === "ice" ? this.localIceSeed?.[k] ?? 0 : 1;
    });
    const step2 = Math.min(this.model.stepS, refined.maxStepS);
    if (step2 < this.model.stepS - 1e-9 && this.model.steps > 0) throw new Error("Refinement changes the stable step; initialize it before evolving climate");
    this.model.stepS = step2;
    this.refinement = quality;
    this.refinedSurface = refined;
    refined.aggregate();
    this.refinedSurface.attach(this.environment);
    if (this.terrainSource) this.refinedSurface.setTerrainSource(this.terrainSource);
    this.key = this.modelKey(this.model.planet, this.model.orbit);
    this.texture = null;
    this.refinedDisplay = null;
  }
  rebuildRefinement() {
    if (this.refinedSurface) this.remapTerrain(this.land, this.landElevation, this.terrainSource);
  }
  disableRefinement() {
    if (!this.refinedSurface) {
      this.refinement = void 0;
      return;
    }
    this.refinedSurface.aggregate();
    this.model.surfaceSolver = null;
    this.water.surfaceSolver = null;
    this.environment.surfaceSolver = null;
    this.water.routing?.clearPartition();
    this.refinedSurface = null;
    this.refinement = void 0;
    this.refinedDisplay = null;
    this.texture = this.waterTexture = this.surfaceTexture = null;
    this.presented = null;
    this.key = this.modelKey(this.model.planet, this.model.orbit);
    this.refreshEnvironment();
  }
  refinedAt(u4, v2, s = this.refinedSurface.sample(u4, v2)) {
    const k = surfaceCell(this.surfaceGrid, u4, v2), r = this.surfaceReference, base = { meanTemperatureK: r.meanTemperatureK[k], warmestTemperatureK: r.warmestTemperatureK[k], annualRainMm: r.annualRainMm[k] }, veg = this.vegetation.sample(k);
    const snow2 = Math.min(1, s.snowMm / 30), glacier = Math.max(Math.min(1, s.landIceKgM2 / (917 * 5)), Math.min(1, s.shelfLandKgM2 / (917 * 5))), seaIce = Math.min(1, s.iceKgM2 / (917 * 0.5)), shelf = Math.min(1, s.shelfSeaKgM2 / (917 * 5));
    const color = veg.color.map((value, c) => (value * (1 - glacier) + [190, 217, 224][c] * glacier) * (1 - snow2) + [234, 242, 240][c] * snow2);
    return { ...base, ...veg, localTemperatureK: s.airK, surfaceTemperatureK: s.landFraction >= 0.5 ? s.landK : s.seaK, landTemperatureK: s.landK, oceanTemperatureK: s.seaK, landFraction: s.landFraction, heightM: s.heightM, snowFraction: snow2, seaIceFraction: seaIce, landIceM: s.landIceKgM2 / 917, shelfIceM: (s.landFraction * s.shelfLandKgM2 + (1 - s.landFraction) * s.shelfSeaKgM2) / 917, shelfIceFraction: Math.max(shelf, Math.min(1, s.shelfLandKgM2 / (917 * 5))), color };
  }
  renderRefinement() {
    const w2 = this.refinement === "high" ? 384 : 192, h = w2 / 2 + 1, n2 = w2 * h, pixels = new Uint8Array(n2 * 4), dh = w2 / 2, air = new Uint8Array(w2 * dh * 4), waterPixels = new Uint8Array(w2 * dh * 4);
    const fields = { land: new Float64Array(n2), temperatureK: new Float64Array(n2), landTemperatureK: new Float64Array(n2), oceanTemperatureK: new Float64Array(n2), snowMm: new Float64Array(n2), iceKgM2: new Float64Array(n2), landIceKgM2: new Float64Array(n2), shelfLandIceKgM2: new Float64Array(n2), shelfSeaIceKgM2: new Float64Array(n2), vegetation: new Float64Array(n2) };
    const byte = (x) => Math.round(Math.max(0, Math.min(1, x)) * 255), north = this.refinedSurface.sample(0, 0), south = this.refinedSurface.sample(0, 1);
    for (let i = 0; i < n2; i++) {
      const j = Math.floor(i / w2), u4 = (i % w2 + 0.5) / w2, v2 = j / (h - 1), s = j === 0 ? north : j === h - 1 ? south : this.refinedSurface.sample(u4, v2), cover = this.refinedAt(u4, v2, s);
      fields.land[i] = s.landFraction;
      fields.temperatureK[i] = s.airK;
      fields.landTemperatureK[i] = s.landK;
      fields.oceanTemperatureK[i] = s.seaK;
      fields.snowMm[i] = s.snowMm;
      fields.iceKgM2[i] = s.iceKgM2;
      fields.landIceKgM2[i] = s.landIceKgM2;
      fields.shelfLandIceKgM2[i] = s.shelfLandKgM2;
      fields.shelfSeaIceKgM2[i] = s.shelfSeaKgM2;
      fields.vegetation[i] = this.vegetation.cover[surfaceCell(this.surfaceGrid, u4, v2)];
      for (let c = 0; c < 3; c++) pixels[4 * i + c] = Math.round(cover.color[c]);
      pixels[4 * i + 3] = byte(Math.max(cover.seaIceFraction, cover.shelfIceFraction));
    }
    for (let i = 0; i < w2 * dh; i++) {
      const u4 = (i % w2 + 0.5) / w2, v2 = Math.acos(1 - 2 * (Math.floor(i / w2) + 0.5) / dh) / Math.PI, s = this.refinedSurface.sample(u4, v2), wind = this.sampleWind(u4, v2);
      air[4 * i] = byte((s.airK - 193.15) / 140);
      air[4 * i + 1] = 128 + Math.round(1.27 * wind.eastMps);
      air[4 * i + 2] = 128 + Math.round(1.27 * wind.northMps);
      air[4 * i + 3] = 255;
      waterPixels[4 * i] = byte(s.rainMmDay / 20);
      waterPixels[4 * i + 1] = byte(s.soilMm / this.waterConfig.soilCapacityKgM2);
      waterPixels[4 * i + 2] = byte(Math.log10(1 + this.water.dischargeM3S[s.parent]) / 7);
      waterPixels[4 * i + 3] = byte(s.landFraction);
    }
    for (const j of [0, h - 1]) for (const a of [pixels]) for (let c = 0; c < 4; c++) {
      let mean = 0;
      for (let x = 0; x < w2; x++) mean += a[4 * (j * w2 + x) + c] / w2;
      for (let x = 0; x < w2; x++) a[4 * (j * w2 + x) + c] = Math.round(mean);
    }
    this.surfaceTexture = { width: w2, height: h, pixels, timeS: this.model.timeS };
    this.texture = { width: w2, height: dh, pixels: air, timeS: this.model.timeS };
    this.waterTexture = { width: w2, height: dh, pixels: waterPixels, timeS: this.model.timeS };
    this.refinedDisplay = { texture: this.surfaceTexture, ...fields };
  }
  sampleWater(u4, v2) {
    if (!this.water) return null;
    const w2 = this.water, k = thermalCell(this.grid, u4, v2), f = w2.land[k];
    if (this.refinedSurface) {
      const s = this.refinedSurface.sample(u4, v2);
      return { precipitationMmDay: s.rainMmDay, soilMm: s.landFraction > 0 ? s.soilMm : null, surfaceMm: s.landFraction > 0 ? s.surfaceMm / s.landFraction : null, dischargeM3S: w2.dischargeM3S[k], atmosphereMm: w2.atmosphereKgM2[k], snowMm: s.snowMm, iceM: s.iceKgM2 / 917, meltMmDay: s.meltMmDay, landIceM: s.landIceKgM2 / 917, iceSpeedMyr: (w2.glacier?.speedMps[k] ?? 0) * 365.25 * 86400 };
    }
    return {
      precipitationMmDay: 86400 * w2.precipitationKgM2S[k],
      soilMm: f > 0 ? w2.soilKgM2[k] / f : null,
      surfaceMm: f > 0 ? w2.surfaceKgM2[k] / f : null,
      dischargeM3S: w2.dischargeM3S[k],
      atmosphereMm: w2.atmosphereKgM2[k],
      snowMm: f > 0 ? w2.snowKgM2[k] / f : 0,
      iceM: f < 1 ? w2.seaIceKgM2[k] / ((1 - f) * 917) : 0,
      meltMmDay: f > 0 ? 86400 * w2.meltKgM2S[k] / f : 0,
      landIceM: f > 0 ? w2.landIceKgM2[k] / (917 * f) : 0,
      iceSpeedMyr: (w2.glacier?.speedMps[k] ?? 0) * 365.25 * 86400
    };
  }
  sampleTerrainWater(u4, v2) {
    const route = this.water?.routing, mesh2 = this.terrainSource?.mesh;
    if (!route || !mesh2) return null;
    const direction = uvToDirection(u4, v2);
    let nearest = -1, best = -Infinity;
    for (let t = 0; t < mesh2.numTriangles; t++) {
      const dot = direction.reduce((sum3, x, c) => sum3 + x * mesh2.xyz_t[3 * t + c], 0);
      if (dot > best) {
        best = dot;
        nearest = t;
      }
    }
    if (nearest < 0 || route.network.cell[nearest] < 0) return null;
    return { triangle: nearest, depthM: route.volumeM3[nearest] / route.network.areaM2[nearest], flowM3S: route.fluxM3S[nearest] };
  }
  checkpoint() {
    return { thermal: this.model.checkpoint(), water: this.water?.checkpoint() ?? null, ice: this.iceEnergy.slice(), vegetation: this.vegetation?.checkpoint() ?? null, circulation: this.environment?.checkpoint() ?? null, refined: this.refinedSurface?.checkpoint() ?? null };
  }
  localTemperature(temperature) {
    const delta = temperature.map((t, i) => t - this.initialTemperature[i]);
    return resampleClimateField(this.grid, delta, this.surfaceGrid).map((d2, i) => Math.max(0, this.surfaceInitial.temperatureK[i] + d2));
  }
  localReservoirTemperature(kind) {
    const r = this.surfaceReservoirInitial, m2 = this.model;
    if (!r) return this.localTemperature(m2.temperatureK);
    const initial2 = kind === "land" ? r.initialLandTemperatureK : r.initialOceanTemperatureK, current = kind === "land" ? m2.landTemperatureK : m2.oceanTemperatureK, local = kind === "land" ? r.landTemperatureK : r.oceanTemperatureK;
    return resampleClimateField(this.grid, current.map((t, i) => t - initial2[i]), this.surfaceGrid).map((d2, i) => Math.max(0, local[i] + d2));
  }
  refreshEnvironment() {
    if (!this.environment || !this.vegetation) return;
    this.environment.refresh(aggregateSurface(this.grid, this.surfaceGrid, this.vegetation.cover, this.surfaceTerrain.land));
    this.environment.ocean.step(0, this.environmentConfig.oceanStrengthMps);
  }
  surfaceState() {
    if (this.refinedDisplay) return this.refinedDisplay;
    if (!this.surfaceTexture || !this.surfaceTerrain || !this.surfaceTemperature) return null;
    return { texture: this.surfaceTexture, land: this.surfaceTerrain.land, temperatureK: this.surfaceTemperature, landTemperatureK: this.surfaceLandTemperature, oceanTemperatureK: this.surfaceOceanTemperature, snowMm: this.localSnow, iceKgM2: this.localIce, landIceKgM2: this.localLandIce, shelfLandIceKgM2: this.localShelfLand, shelfSeaIceKgM2: this.localShelfSea, vegetation: this.vegetation?.cover ?? null };
  }
  sync(planet, orbit, timeS, presentedTimeS) {
    if (!this.enabled || !this.land) {
      this.invalidate();
      this.status = this.enabled ? "Waiting for terrain" : "Thermal model off";
      return null;
    }
    const derived = deriveOrbit(planet, orbit);
    if (derived.solarDayS > derived.yearS / 20) {
      this.invalidate();
      this.status = "Daily mean unavailable for slow / synchronous spin (solar day > year / 20).";
      return null;
    }
    const key = this.modelKey(planet, orbit);
    if (key !== this.key) {
      this.iceInventory = decodeIceInventory(this.iceInventory);
      const heights = this.landElevation.map((e2) => e2 * planet.reliefM);
      const reference2 = generateClimate(this.grid, planet, orbit, this.config, this.waterConfig, this.land, heights, timeS, this.environmentConfig);
      const local = this.surfaceTerrain, localHeights = local.height.map((e2) => e2 * planet.reliefM);
      const modern = this.waterConfig.moistureScheme === "transport" && this.config.separateReservoirs;
      const coarse2 = modern ? generateSurfaceReference(this.grid, planet, orbit, this.config, this.waterConfig, this.land, heights, void 0, this.environmentConfig) : null;
      const annual = coarse2 ? resampleClimateField(this.grid, coarse2.annualRainMm, this.surfaceGrid) : void 0;
      this.surfaceReference = generateSurfaceReference(this.surfaceGrid, planet, orbit, this.config, this.waterConfig, local.land, localHeights, annual, this.environmentConfig);
      this.surfaceInitial = modern ? generateThermalClimate(this.surfaceGrid, planet, orbit, this.config, this.waterConfig, local.land, localHeights, timeS) : generateClimate(this.surfaceGrid, planet, orbit, this.config, this.waterConfig, local.land, localHeights, timeS);
      if (modern) this.surfaceInitial.soilFraction = resampleClimateField(this.grid, reference2.soilFraction, this.surfaceGrid);
      const coupled = this.config.airRadiationFraction !== void 0 && coarse2;
      if (coupled) {
        const analytic = generateSurfaceReference(this.grid, planet, orbit, this.config, this.waterConfig, this.land, heights, new Float64Array(this.grid.count));
        const meanDelta = resampleClimateField(this.grid, coarse2.meanTemperatureK.map((v2, i) => v2 - analytic.meanTemperatureK[i]), this.surfaceGrid);
        const warmDelta = resampleClimateField(this.grid, coarse2.warmestTemperatureK.map((v2, i) => v2 - analytic.warmestTemperatureK[i]), this.surfaceGrid);
        for (let i = 0; i < this.surfaceGrid.count; i++) {
          this.surfaceReference.meanTemperatureK[i] = Math.max(0, this.surfaceReference.meanTemperatureK[i] + meanDelta[i]);
          this.surfaceReference.warmestTemperatureK[i] = Math.max(this.surfaceReference.meanTemperatureK[i], this.surfaceReference.warmestTemperatureK[i] + warmDelta[i]);
        }
        const current = generateThermalClimate(this.grid, planet, orbit, this.config, this.waterConfig, this.land, heights, timeS);
        const delta = resampleClimateField(this.grid, reference2.temperatureK.map((t, i) => t - current.temperatureK[i]), this.surfaceGrid);
        this.surfaceInitial.temperatureK = this.surfaceInitial.temperatureK.map((v2, i) => Math.max(0, v2 + delta[i]));
      }
      this.iceEnergy = generateSeaIce(this.surfaceReference.monthlyIceCooling, this.surfaceGrid.count, derived.yearS, orbit.orbitPhaseRad + 2 * Math.PI * (timeS % derived.yearS) / derived.yearS);
      this.initialSoil = reference2.soilFraction;
      this.initialTemperature = reference2.temperatureK.slice();
      let reservoirSeeds;
      if (this.config.separateReservoirs) {
        const localLand = generateThermalClimate(this.surfaceGrid, planet, orbit, this.config, this.waterConfig, new Float64Array(this.surfaceGrid.count).fill(1), localHeights, timeS);
        const localOcean = generateThermalClimate(this.surfaceGrid, planet, orbit, this.config, this.waterConfig, new Float64Array(this.surfaceGrid.count), new Float64Array(this.surfaceGrid.count), timeS);
        const landTemperatureK = aggregateSurface(this.grid, this.surfaceGrid, localLand.temperatureK, local.land).map((t, i) => this.land[i] > 0 && t > 0 ? t : reference2.temperatureK[i]);
        const oceanTemperatureK = aggregateSurface(this.grid, this.surfaceGrid, localOcean.temperatureK, local.land.map((f) => 1 - f)).map((t, i) => this.land[i] < 1 && t > 0 ? t : reference2.temperatureK[i]);
        if (coupled && reference2.landTemperatureK && reference2.oceanTemperatureK) {
          const ld = resampleClimateField(this.grid, reference2.landTemperatureK.map((t, i) => t - landTemperatureK[i]), this.surfaceGrid);
          const od = resampleClimateField(this.grid, reference2.oceanTemperatureK.map((t, i) => t - oceanTemperatureK[i]), this.surfaceGrid);
          localLand.temperatureK = localLand.temperatureK.map((t, i) => Math.max(0, t + ld[i]));
          localOcean.temperatureK = localOcean.temperatureK.map((t, i) => Math.max(0, t + od[i]));
          landTemperatureK.set(reference2.landTemperatureK);
          oceanTemperatureK.set(reference2.oceanTemperatureK);
        }
        reservoirSeeds = { landTemperatureK, oceanTemperatureK };
        this.surfaceReservoirInitial = { landTemperatureK: localLand.temperatureK, oceanTemperatureK: localOcean.temperatureK, initialLandTemperatureK: landTemperatureK.slice(), initialOceanTemperatureK: oceanTemperatureK.slice() };
        const seaReference = generateSurfaceReference(this.surfaceGrid, planet, orbit, this.config, this.waterConfig, new Float64Array(this.surfaceGrid.count), new Float64Array(this.surfaceGrid.count), new Float64Array(this.surfaceGrid.count));
        this.iceEnergy = generateSeaIce(seaReference.monthlyIceCooling, this.surfaceGrid.count, derived.yearS, orbit.orbitPhaseRad + 2 * Math.PI * (timeS % derived.yearS) / derived.yearS);
      }
      this.model = new ThermalModel(planet, orbit, this.config, this.land, timeS, this.grid, { ...reference2, ...reservoirSeeds });
      this.water = this.waterEnabled ? new WaterModel(
        this.grid,
        planet.radiusM,
        this.land,
        heights,
        this.model.temperatureK,
        this.waterConfig,
        reference2
      ) : null;
      if (this.water) {
        const w2 = this.water, land = this.land, sea = land.map((f) => 1 - f), localSea = local.land.map((f) => 1 - f);
        this.localSnowSeed = this.surfaceInitial.temperatureK.map((t, i) => 150 * surfaceCover({ meanTemperatureK: this.surfaceReference.meanTemperatureK[i], warmestTemperatureK: this.surfaceReference.warmestTemperatureK[i], annualRainMm: this.surfaceReference.annualRainMm[i] }, t, this.surfaceInitial.soilFraction[i]).snowFraction);
        this.localIceSeed = this.iceEnergy.map((e2) => e2 / FUSION_J_KG);
        const snow2 = aggregateSurface(this.grid, this.surfaceGrid, this.localSnowSeed, local.land).map((v2, i) => v2 * land[i]);
        const ice2 = aggregateSurface(this.grid, this.surfaceGrid, this.localIceSeed, localSea).map((v2, i) => v2 * sea[i]);
        w2.seedFrozen(snow2, ice2);
        this.localLandIceSeed = this.iceInventory ? this.iceInventory.groundedThicknessM.map((t) => 917 * t) : this.surfaceReference.warmestTemperatureK.map((t) => this.environmentConfig.glaciers ? 917 * 1500 * Math.max(0, Math.min(1, (273.15 - t) / 15)) : 0);
        const landIce = aggregateSurface(this.grid, this.surfaceGrid, this.localLandIceSeed, local.land).map((v2, i) => v2 * land[i]);
        if (this.environmentConfig.glaciers || this.iceInventory) w2.seedLandIce(landIce);
        const glacierScale = this.iceInventory ? this.allocationScale(landIce, w2.landIceKgM2) : resampleClimateField(this.grid, landIce.map((v2, i) => v2 > 0 ? w2.landIceKgM2[i] / v2 : 0), this.surfaceGrid);
        this.localLandIceSeed = this.localLandIceSeed.map((v2, i) => v2 * glacierScale[i]);
        this.initialLandIce = w2.landIceKgM2.slice();
        if (this.iceInventory) w2.glacierBedM = this.compatibleBed(planet);
        const shelfSeed = this.iceInventory?.shelfThicknessM.map((h) => h * 917) ?? new Float64Array(this.surfaceGrid.count);
        const shelfLand = aggregateSurface(this.grid, this.surfaceGrid, shelfSeed, local.land).map((v2, i) => v2 * land[i]), shelfSea = aggregateSurface(this.grid, this.surfaceGrid, shelfSeed, localSea).map((v2, i) => v2 * sea[i]);
        w2.seedShelves(shelfLand, shelfSea);
        const shelfScale = (requested, current) => this.allocationScale(requested, current);
        const shelfLandScale = shelfScale(shelfLand, w2.shelfLandIceKgM2), shelfSeaScale = shelfScale(shelfSea, w2.shelfSeaIceKgM2);
        this.shelves = { initialLand: w2.shelfLandIceKgM2.slice(), initialSea: w2.shelfSeaIceKgM2.slice(), localLandSeed: shelfSeed.map((v2, i) => v2 * shelfLandScale[i]), localSeaSeed: shelfSeed.map((v2, i) => v2 * shelfSeaScale[i]) };
        const snowScale = resampleClimateField(this.grid, snow2.map((v2, i) => v2 > 0 ? w2.snowKgM2[i] / v2 : 0), this.surfaceGrid);
        const iceScale = resampleClimateField(this.grid, ice2.map((v2, i) => v2 > 0 ? w2.seaIceKgM2[i] / v2 : 0), this.surfaceGrid);
        this.localSnowSeed = this.localSnowSeed.map((v2, i) => v2 * snowScale[i]);
        this.localIceSeed = this.localIceSeed.map((v2, i) => v2 * iceScale[i]);
        this.initialSnow = w2.snowKgM2.slice();
        this.initialIce = w2.seaIceKgM2.slice();
        this.environment = new EnvironmentModel(this.model, w2, this.environmentConfig);
        if (this.surfaceReservoirInitial) {
          this.surfaceReservoirInitial.landTemperatureK = this.localReservoirTemperature("land");
          this.surfaceReservoirInitial.oceanTemperatureK = this.localReservoirTemperature("ocean");
          this.surfaceReservoirInitial.initialLandTemperatureK = this.model.landTemperatureK.slice();
          this.surfaceReservoirInitial.initialOceanTemperatureK = this.model.oceanTemperatureK.slice();
        }
        if (this.environmentConfig.terrainWater) this.attachRouting(planet);
        this.initialTemperature = this.model.temperatureK.slice();
        this.vegetation = new VegetationModel(this.surfaceReference);
        this.model.stepS = Math.min(this.model.stepS, w2.maxStepS);
        this.refreshEnvironment();
      }
      if (this.refinement && this.water && this.environment && this.config.separateReservoirs) this.enableRefinement(this.refinement);
      this.key = this.modelKey(planet, orbit);
      this.presented = this.checkpoint();
      this.texture = null;
      this.waterTexture = null;
      this.lastTarget = timeS;
    }
    const m2 = this.model;
    if (presentedTimeS !== null && presentedTimeS >= this.lastTarget) this.presented = this.checkpoint();
    if (timeS < this.lastTarget) {
      if (this.presented && m2.epochS + this.presented.thermal.steps * m2.stepS <= timeS) {
        m2.restore(this.presented.thermal);
        if (this.water && this.presented.water) this.water.restore(this.presented.water, this.water.config.moistureScheme === "transport" ? oldRefinedLandEstimate(this.presented.water, this.presented.refined) : void 0);
        this.environment?.restore(this.presented.circulation);
        if (this.refinedSurface && this.presented.refined) this.refinedSurface.restore(this.presented.refined);
        this.iceEnergy = this.presented.ice.slice();
        if (this.vegetation && this.presented.vegetation) this.vegetation.restore(this.presented.vegetation);
        this.refreshEnvironment();
      } else {
        this.invalidate();
        return this.sync(planet, orbit, timeS, presentedTimeS);
      }
      this.texture = null;
      this.waterTexture = null;
    }
    const before = m2.steps;
    if (timeS >= m2.timeS + m2.stepS) {
      m2.advanceTo(timeS, 32, (dt2, t, q) => {
        if (!this.environment) {
          const local = this.localTemperature(t);
          for (let i = 0; i < local.length; i++) this.iceEnergy[i] = advanceSeaIce(this.iceEnergy[i], seaIceCooling(local[i], this.config.emissivity), dt2);
        }
        if (this.water) {
          if (this.environment.atmosphere) this.environment.atmosphere.step(dt2, m2.timeS + dt2 / 2);
          else {
            const wind = circulationWinds(this.grid, planet, orbit, m2.timeS + dt2 / 2, this.land, this.waterConfig.windMps);
            this.water.setWinds(wind.eastMps, wind.northMps);
          }
          this.environment.step(dt2);
          if (this.environmentConfig.vegetation) {
            const soil = resampleClimateField(this.grid, this.water.soilKgM2.map((v2, i) => this.water.land[i] > 0 ? v2 / (this.water.land[i] * this.waterConfig.soilCapacityKgM2) : 0), this.surfaceGrid);
            const rain2 = resampleClimateField(this.grid, this.water.precipitationKgM2S.map((v2) => v2 * 86400), this.surfaceGrid);
            this.vegetation.step(dt2, this.config.airRadiationFraction !== void 0 ? this.localReservoirTemperature("land") : this.localTemperature(t), rain2, soil);
          }
          this.refreshEnvironment();
        }
      });
    }
    this.lastTarget = timeS;
    if (!this.texture || before !== m2.steps) {
      const pixels = new Uint8Array(this.grid.count * 4);
      this.wind = this.water ? { eastMps: this.water.windEastMps, northMps: this.water.windNorthMps } : circulationWinds(this.grid, planet, orbit, m2.timeS, this.land, this.waterConfig.windMps);
      const byte = (x) => Math.round(Math.max(0, Math.min(1, x)) * 255);
      for (let i = 0; i < this.grid.count; i++) {
        pixels[4 * i] = byte((m2.temperatureK[i] - 193.15) / 140);
        pixels[4 * i + 1] = 128 + Math.round(1.27 * this.wind.eastMps[i]);
        pixels[4 * i + 2] = 128 + Math.round(1.27 * this.wind.northMps[i]);
        pixels[4 * i + 3] = 255;
      }
      this.texture = { width: this.grid.width, height: this.grid.height, pixels, timeS: m2.timeS };
      const soilDelta = this.initialSoil.map((initial2, i) => this.water && this.water.land[i] > 0 ? this.water.soilKgM2[i] / (this.water.land[i] * this.water.config.soilCapacityKgM2) - initial2 : 0);
      this.surfaceTemperature = this.localTemperature(m2.temperatureK);
      this.surfaceLandTemperature = this.localReservoirTemperature("land");
      this.surfaceOceanTemperature = this.localReservoirTemperature("ocean");
      this.surfaceSoil = resampleClimateField(this.grid, soilDelta, this.surfaceGrid).map((d2, i) => Math.max(0, Math.min(1, this.surfaceInitial.soilFraction[i] + d2)));
      if (this.water) {
        const localLand = this.surfaceTerrain.land;
        this.localSnow = downscaleStore(this.grid, this.surfaceGrid, this.water.snowKgM2, this.initialSnow, this.water.land, this.localSnowSeed).map((v2, i) => localLand[i] > 0 ? v2 : 0);
        this.localIce = downscaleStore(this.grid, this.surfaceGrid, this.water.seaIceKgM2, this.initialIce, this.water.land.map((f) => 1 - f), this.localIceSeed).map((v2, i) => localLand[i] < 1 ? v2 : 0);
        this.localLandIce = downscaleStore(this.grid, this.surfaceGrid, this.water.landIceKgM2, this.initialLandIce, this.water.land, this.localLandIceSeed).map((v2, i) => localLand[i] > 0 ? v2 : 0);
        if (this.shelves) {
          this.localShelfLand = downscaleStore(this.grid, this.surfaceGrid, this.water.shelfLandIceKgM2, this.shelves.initialLand, this.water.land, this.shelves.localLandSeed).map((v2, i) => localLand[i] > 0 ? v2 : 0);
          this.localShelfSea = downscaleStore(this.grid, this.surfaceGrid, this.water.shelfSeaIceKgM2, this.shelves.initialSea, this.water.land.map((f) => 1 - f), this.shelves.localSeaSeed).map((v2, i) => localLand[i] < 1 ? v2 : 0);
        }
      }
      const surfacePixels = new Uint8Array(this.surfaceGrid.count * 4);
      for (let i = 0; i < this.surfaceGrid.count; i++) {
        const cover = this.surfaceAt(i);
        for (let c = 0; c < 3; c++) surfacePixels[4 * i + c] = Math.round(cover.color[c]);
        surfacePixels[4 * i + 3] = byte(Math.max(cover.seaIceFraction, cover.shelfIceFraction));
      }
      this.surfaceTexture = { width: this.surfaceGrid.width, height: this.surfaceGrid.height, pixels: surfacePixels, timeS: m2.timeS };
      if (this.water) {
        const w2 = this.water, waterPixels = new Uint8Array(this.grid.count * 4);
        const byte2 = (x) => Math.round(Math.max(0, Math.min(1, x)) * 255);
        for (let i = 0; i < this.grid.count; i++) {
          waterPixels[4 * i] = byte2(86400 * w2.precipitationKgM2S[i] / 20);
          waterPixels[4 * i + 1] = byte2(w2.land[i] > 0 ? w2.soilKgM2[i] / (w2.land[i] * w2.config.soilCapacityKgM2) : 0);
          waterPixels[4 * i + 2] = byte2(Math.log10(1 + w2.dischargeM3S[i]) / 7);
          waterPixels[4 * i + 3] = byte2(w2.land[i]);
        }
        this.waterTexture = { width: this.grid.width, height: this.grid.height, pixels: waterPixels, timeS: m2.timeS };
      }
    }
    if (this.refinedSurface && (!this.refinedDisplay || before !== m2.steps)) this.renderRefinement();
    this.status = `Daily-mean model \xB7 ${m2.steps === 0 ? "Generated reference climate \u2014 no Play needed" : "Evolving from generated climate"} \xB7 ${this.grid.count} cells \xB7 ${(m2.stepS / 60).toFixed(1)} min step`;
    return this.texture;
  }
};

// environment-comparison.ts
var METRICS = [
  ["temperatureC", "Global temperature", "\xB0C"],
  ["icePercent", "Ocean ice cover", "% ocean"],
  ["snowPercent", "Land snow cover", "% land"],
  ["northIcePercent", "North polar ocean ice (>60\xB0)", "% ocean"],
  ["southIcePercent", "South polar ocean ice (<\u221260\xB0)", "% ocean"],
  ["vegetationPercent", "Vegetation cover", "% land"],
  ["albedo", "Mean albedo", "0\u20131"],
  ["snowMm", "Snow inventory", "global mm"],
  ["iceMm", "Sea-ice inventory", "global mm"],
  ["landIceMm", "Grounded ice inventory", "global mm"],
  ["glacierSpeedMyr", "Maximum ice speed", "m/yr"],
  ["glacialSolidResidualM", "Glacial solid residual", "global m"],
  ["meltMmDay", "Snow / land-ice melt", "global mm/day"],
  ["rainMmDay", "Precipitation", "mm/day"],
  ["currentMps", "Maximum current", "m/s"],
  ["waterResidualMm", "Water budget residual", "mm"],
  ["energyResidualJm2", "Total enthalpy residual", "J/m\xB2"]
];

// simulation-document.ts
var MAX_SIMULATION_FILE_BYTES = 32 * 1024 * 1024;
function text(v2, name, max) {
  if (typeof v2 !== "string" || v2.length > max) throw new Error(`Invalid ${name}`);
  return v2;
}
function metrics(value) {
  const d2 = record(value);
  return Object.fromEntries(METRICS.map(([k]) => [k, scalar(d2[k] === void 0 && ["landIceMm", "glacierSpeedMyr", "glacialSolidResidualM"].includes(k) ? 0 : d2[k], k)]));
}
function baseline(value) {
  if (value === null) return null;
  const d2 = record(value), width = scalar(d2.width, "comparison width", SURFACE_WIDTH, 384, true), height = scalar(d2.height, "comparison height", SURFACE_HEIGHT, 193, true), n2 = width * height;
  if (![SURFACE_WIDTH, 192, 384].includes(width) || height !== width / 2 + 1) throw new Error("Invalid comparison resolution");
  if (d2.width !== width || d2.height !== height) throw new Error("Invalid comparison dimensions");
  const parameters = text(d2.parameters, "comparison parameters", 16384);
  record(JSON.parse(parameters));
  const rgb = field(d2.rgb, "comparison pixels", 3 * n2, 0, 255);
  if (rgb.some((v2) => !Number.isInteger(v2))) throw new Error("Invalid comparison pixel");
  return {
    timeS: scalar(d2.timeS, "baseline time", 0, Number.MAX_SAFE_INTEGER),
    ageDays: scalar(d2.ageDays, "baseline age", 0),
    description: text(d2.description, "comparison description", 2048),
    parameters,
    width,
    height,
    rgb: new Uint8Array(rgb),
    metrics: metrics(d2.metrics),
    temperatureC: field(d2.temperatureC, "baseline temperature", n2, -273.15, 1e5),
    snowMm: field(d2.snowMm, "baseline snow", n2, 0),
    iceM: field(d2.iceM, "baseline ice", n2, 0),
    landIceM: d2.landIceM === void 0 ? new Float64Array(n2) : field(d2.landIceM, "baseline land ice", n2, 0),
    vegetation: field(d2.vegetation, "baseline vegetation", n2, 0, 1),
    land: field(d2.land, "baseline land", n2, 0, 1),
    east: field(d2.east, "baseline east", n2),
    north: field(d2.north, "baseline north", n2)
  };
}
function decodeSimulationDocument(source2, expected, constraintSize) {
  if (source2.length > MAX_SIMULATION_FILE_BYTES || new TextEncoder().encode(source2).length > MAX_SIMULATION_FILE_BYTES) throw new Error("Simulation file exceeds 32 MiB");
  const d2 = record(JSON.parse(source2));
  if (d2.format !== "mapgen4-sphere-simulation" || d2.version !== 1) throw new Error("Unsupported simulation document");
  const terrain2 = decodeTerrainDocument(JSON.stringify(d2.terrain), expected, constraintSize), runtime = decodeRuntimeState(d2.runtime), v2 = record(d2.view), c = record(d2.comparison);
  const layers = ["original", "day-night", "insolation", "temperature", "precipitation", "soil-moisture", "runoff", "erosion", "wind", "surface"];
  if (!layers.includes(v2.layer)) throw new Error("Invalid display layer");
  const speed = scalar(v2.speed, "clock speed", 60, 864e3);
  if (![60, 3600, 86400, 864e3].includes(speed)) throw new Error("Unsupported clock speed");
  if (runtime.state && runtime.state.lastTarget !== terrain2.settings.timeS) throw new Error("Clock and runtime time differ");
  if (!Array.isArray(c.history) || c.history.length > 240) throw new Error("Invalid comparison history");
  let previous = -1;
  const history = c.history.map((item) => {
    const h = record(item), time = scalar(h.time, "history time", 0);
    if (time <= previous) throw new Error("Unordered comparison history");
    previous = time;
    return { time, metrics: metrics(h.metrics) };
  });
  if (history.length && (!runtime.state?.water || previous > (runtime.state.lastTarget - runtime.state.epochS) / 86400 + 1e-8)) throw new Error("History outside simulation");
  ThermalRuntime.fromSnapshot(runtime, terrain2.settings.planet, terrain2.settings.orbit);
  return { format: "mapgen4-sphere-simulation", version: 1, terrain: terrain2, runtime, view: { speed, layer: v2.layer, weather: v2.weather === void 0 ? false : boolean(v2.weather) }, comparison: { baseline: baseline(c.baseline), history } };
}
function encodeSimulationDocument(document) {
  const source2 = JSON.stringify(document, (_, v2) => ArrayBuffer.isView(v2) ? Array.from(v2) : v2);
  decodeSimulationDocument(source2, document.terrain.mesh, document.terrain.constraints.size);
  return source2;
}

// climate-diagnostics.ts
var rad = Math.PI / 180;
var days = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
function cellBounds(grid, k) {
  const row = Math.floor(k / grid.width), x = k % grid.width;
  return { south: Math.asin(1 - 2 * (row + 1) / grid.height) / rad, north: Math.asin(1 - 2 * row / grid.height) / rad, west: -180 + 360 * x / grid.width, east: -180 + 360 * (x + 1) / grid.width };
}
function longitudeSegments(b) {
  if (b.east - b.west >= 360) return [[-180, 180]];
  const w2 = ((b.west + 180) % 360 + 360) % 360 - 180, width = ((b.east - b.west) % 360 + 360) % 360;
  return w2 + width <= 180 ? [[w2, w2 + width]] : [[w2, 180], [-180, w2 + width - 360]];
}
function sphericalOverlap(a, b) {
  const lo = Math.max(a.south, b.south), hi = Math.min(a.north, b.north);
  if (hi <= lo) return 0;
  let width = 0;
  for (const [al, ar] of longitudeSegments(a)) for (const [bl, br] of longitudeSegments(b)) width += Math.max(0, Math.min(ar, br) - Math.max(al, bl));
  return width * rad * (Math.sin(hi * rad) - Math.sin(lo * rad));
}
function matchedSupport(grid, land, region, observations) {
  const weights2 = new Float64Array(grid.count), observedMonthlyMm = new Float64Array(12);
  let solidAngle = 0;
  for (const cell of observations) {
    if (cell.monthlyMm.length !== 12 || Array.from(cell.monthlyMm).some((x) => !Number.isFinite(x) || x < 0)) continue;
    for (let k = 0; k < grid.count; k++) {
      if (land[k] <= 0) continue;
      const b = cellBounds(grid, k);
      let a = 0;
      for (const [west, east] of longitudeSegments(region)) {
        const left = Math.max(west, b.west), right = Math.min(east, b.east);
        if (right > left) a += sphericalOverlap({ south: Math.max(region.south, b.south), north: Math.min(region.north, b.north), west: left, east: right }, cell.bounds);
      }
      a *= land[k];
      if (a <= 0) continue;
      weights2[k] += a;
      solidAngle += a;
      for (let m2 = 0; m2 < 12; m2++) observedMonthlyMm[m2] += a * cell.monthlyMm[m2];
    }
  }
  if (solidAngle > 0) for (let m2 = 0; m2 < 12; m2++) observedMonthlyMm[m2] /= solidAngle;
  return { weights: weights2, solidAngle, observedMonthlyMm, mean: (values) => solidAngle > 0 ? weights2.reduce((sum3, a, k) => sum3 + a * values[k], 0) / solidAngle : NaN };
}
var CalendarFlux = class {
  constructor(count, yearS, startDay = 78) {
    this.yearS = yearS;
    this.startDay = startDay;
    this.total = new Float64Array(count);
    this.months = days.map(() => new Float64Array(count));
  }
  yearS;
  startDay;
  months;
  total;
  add(fromS, dtS, rate) {
    const dayS = this.yearS / 365;
    let left = fromS, right = fromS + dtS;
    for (let k = 0; k < this.total.length; k++) this.total[k] += rate[k] * dtS;
    while (left < right) {
      let d2 = ((left / dayS + this.startDay) % 365 + 365) % 365, month = 0, bound = days[0];
      while (month < 11 && d2 >= bound - 1e-10) {
        month++;
        bound += days[month];
      }
      const next2 = Math.min(right, left + (bound - d2) * dayS), delta = next2 - left;
      if (delta <= 0) throw new Error("Calendar integration failed to advance");
      for (let k = 0; k < this.total.length; k++) this.months[month][k] += rate[k] * delta;
      left = next2;
    }
  }
};
var VaporLedger = class {
  constructor(initial2) {
    this.initial = initial2;
    this.initial = Float64Array.from(initial2);
    this.evaporation = new Float64Array(initial2.length);
    this.precipitation = new Float64Array(initial2.length);
    this.transport = new Float64Array(initial2.length);
  }
  initial;
  evaporation;
  precipitation;
  transport;
  add(dtS, e2, p2, netTransport) {
    for (let k = 0; k < this.initial.length; k++) {
      this.evaporation[k] += e2[k] * dtS;
      this.precipitation[k] += p2[k] * dtS;
      this.transport[k] += netTransport[k];
    }
  }
  residual(final2) {
    return Float64Array.from(final2, (v2, k) => v2 - this.initial[k] - this.evaporation[k] + this.precipitation[k] - this.transport[k]);
  }
};

// docs/evidence/earth-seasonal-pressure-20261012/full.ts
var folder = "docs/evidence/earth-seasonal-pressure-20261012";
var out = "build/earth-seasonal-pressure";
var label = process.env.PARAM_PROFILE ?? "control";
var dt = Number(process.env.PARAM_DT ?? 1800);
var start = performance.now();
var sha = (v2) => createHash("sha256").update(v2).digest("hex");
var sum2 = (a) => Array.from(a).reduce((s, v2) => s + v2, 0);
var profiles = JSON.parse(await readFile(`${folder}/profiles.json`, "utf8"));
assert(profiles[label]);
config_default.spacing = HIGH_DETAIL_SPACING;
var { mesh, t_peaks } = await makeMesh();
var identity = meshIdentity(mesh, config_default);
var raw = await readFile("scenes/earth-land-sea/earth-simulation.json", "utf8");
var inputRaw = await readFile("build/earth-lakes-freeze-temperate/lake-day0.json", "utf8");
var d = decodeSimulationDocument(inputRaw, identity, 128);
var p = d.terrain.settings.planet;
var o = d.terrain.settings.orbit;
var map = new Map2(mesh, t_peaks, config_default);
map.assignElevation(d.terrain.parameters.elevation, { size: 128, constraints: new Float32Array(d.terrain.constraints.values) }, new Float32Array(d.terrain.offsets));
map.assignRainfall(d.terrain.parameters.biomes);
map.assignRivers(d.terrain.parameters.rivers, true);
var elevation = new Float32Array(mesh.numRegions + mesh.numTriangles);
elevation.set(map.elevation_r);
elevation.set(map.elevation_t, mesh.numRegions);
var quads = new Int32Array(mesh.numSolidSides * 3);
geometry_default.setMapGeometry(map, 0, quads, new Float32Array(elevation.length * 2));
var source = { mesh, directions: mesh.xyz_r, elevation, quadElements: quads, drainage: d.terrain.drainage };
var initial = structuredClone(d.runtime);
initial.state.stepS = dt;
initial.waterConfig.moistureScheme = "transport";
initial.waterConfig.compensatedOceanTransfers = true;
initial.config.airRadiationFraction = 0.5;
initial.environmentConfig.conductiveSeaIce = true;
initial.environmentConfig.underIceOcean = true;
Object.assign(initial.config, profiles[label].thermal);
Object.assign(initial.waterConfig, profiles[label].water);
Object.assign(initial.environmentConfig, profiles[label].environment);
if (initial.environmentConfig.dynamicCirculation === false) initial.state.circulation = null;
if (profiles[label].water?.windMps !== void 0) {
  assert(initial.state.thermal.steps === 0);
  const limit = Math.abs(initial.waterConfig.windMps), base = circulationWinds(makeThermalGrid(), p, o, initial.state.epochS, initial.state.land, initial.waterConfig.windMps);
  const saved = initial.state.water, memory = initial.state.circulation.atmosphere;
  for (let k = 0; k < base.eastMps.length; k++) {
    assert(Math.abs(saved.windEastMps[k]) <= limit && Math.abs(saved.windNorthMps[k]) <= limit, "New wind bound cannot preserve applied initial winds");
    memory.eastMps[k] = saved.windEastMps[k] - base.eastMps[k];
    memory.northMps[k] = saved.windNorthMps[k] - base.northMps[k];
  }
}
var rt = ThermalRuntime.fromSnapshot(initial, p, o);
var terrain = sampleTerrainGrid(rt.grid, mesh.xyz_r, elevation);
rt.attachRestoredTerrain(terrain.landFraction, terrain.landElevation, source);
rt.configureSurfacePhysics({ separateSurfaceAlbedo: true, liquidOceanEvaporation: true });
await mkdir(out, { recursive: true });
await writeFile(`${out}/full-${label}-day0.json`, encodeSimulationDocument({ ...d, runtime: rt.snapshot() }));
var m = rt.model;
var w = rt.water;
var e = rt.environment;
var n = rt.grid.count;
var year = deriveOrbit(p, o).yearS;
var initialStockSha = sha(JSON.stringify({ air: m.temperatureK, land: m.landTemperatureK, sea: m.oceanTemperatureK, water: Object.fromEntries(["atmosphereKgM2", "soilKgM2", "surfaceKgM2", "snowKgM2", "seaIceKgM2", "landIceKgM2", "shelfLandIceKgM2", "shelfSeaIceKgM2", "oceanGlobalKgM2"].map((k) => [k, w[k]])), routing: w.routing.volumeM3, heat: m.energy(), enthalpy: e.enthalpy() }));
var obs = JSON.parse(await readFile("docs/evidence/earth-moisture-structural-20261011/gpcc-grid.json", "utf8"));
var regions = [
  { name: "Europe", bounds: { south: 45, north: 55, west: -5, east: 25 }, fit: true },
  { name: "East North America", bounds: { south: 35, north: 45, west: -95, east: -75 }, fit: true },
  { name: "East Asia", bounds: { south: 30, north: 45, west: 110, east: 135 }, fit: true },
  { name: "West Siberia", bounds: { south: 50, north: 60, west: 60, east: 90 }, fit: true },
  { name: "India", bounds: { south: 18, north: 25, west: 74, east: 86 }, fit: false },
  { name: "Himalaya foreland", bounds: { south: 26, north: 30, west: 76, east: 88 }, fit: false },
  { name: "Tibet", bounds: { south: 29, north: 35, west: 80, east: 95 }, fit: false },
  { name: "Australia southwest", bounds: { south: -35, north: -29, west: 113, east: 120 }, fit: false },
  { name: "Australia north", bounds: { south: -18, north: -10, west: 125, east: 140 }, fit: false },
  { name: "Amazon", bounds: { south: -10, north: 2, west: -70, east: -50 }, fit: false },
  { name: "Congo", bounds: { south: -5, north: 5, west: 15, east: 30 }, fit: false }
];
var supports = regions.map((r) => matchedSupport(rt.grid, w.land, r.bounds, obs.cells));
var rain = new CalendarFlux(n, year);
var ice = new CalendarFlux(n, year);
var snow = new CalendarFlux(n, year);
var coverage = new CalendarFlux(1, year);
var temp = new CalendarFlux(2, year);
var vapor = new VaporLedger(w.atmosphereKgM2);
var vaporExchange = new CalendarFlux(n, year);
var advectiveExchange = new CalendarFlux(n, year);
var diffusiveExchange = new CalendarFlux(n, year);
var mechanisms = ["saturation", "convection", "front", "convergence", "orographic"];
var mechanismFlux = mechanisms.map(() => new CalendarFlux(n, year));
var transportKeys = ["orographicAdvection", "orographicDiffusion", "frontAdvection", "frontDiffusion", "coldFrontAdvection"];
var transportFlux = transportKeys.map(() => new CalendarFlux(n, year));
var snowInput = new CalendarFlux(n, year);
var snowMelt = new CalendarFlux(n, year);
var snowCompact = new CalendarFlux(n, year);
var drivers = new CalendarFlux(n * 8, year);
var initialSnow = w.snowKgM2.slice();
var snowfallActual = new Float64Array(n);
var meltActual = new Float64Array(n);
var compactActual = new Float64Array(n);
var phase = e.phase.bind(e);
e.phase = (delta) => {
  const before = w.snowKgM2.slice();
  phase(delta);
  before.forEach((v2, k) => meltActual[k] += Math.max(0, v2 - w.snowKgM2[k]));
  const s = Math.max(0, Math.min(delta, year - m.timeS));
  if (s > 0) snowMelt.add(m.timeS, s, before.map((v2, k) => Math.max(0, v2 - w.snowKgM2[k]) / delta));
};
if (e.surfaceSolver) {
  const solver = e.surfaceSolver, compact = solver.compact.bind(solver);
  solver.compact = (delta) => {
    const before = w.snowKgM2.slice();
    compact(delta);
    before.forEach((v2, k) => compactActual[k] += Math.max(0, v2 - w.snowKgM2[k]));
    const s = Math.max(0, Math.min(delta, year - m.timeS));
    if (s > 0) snowCompact.add(m.timeS, s, before.map((v2, k) => Math.max(0, v2 - w.snowKgM2[k]) / delta));
  };
}
if (w.glacier) {
  const glacier = w.glacier, advance = glacier.step.bind(glacier);
  glacier.step = (delta, t) => {
    const before = w.snowKgM2.slice();
    advance(delta, t);
    before.forEach((v2, k) => compactActual[k] += Math.max(0, v2 - w.snowKgM2[k]));
  };
}
var step = w.step.bind(w);
w.step = (delta, t, q, c) => {
  step(delta, t, q, c);
  w.snowfallKgM2S.forEach((v2, k) => snowfallActual[k] += v2 * delta);
  vapor.add(delta, w.evaporationKgM2S, w.precipitationKgM2S, w.vaporTransportKgM2);
  const s = Math.max(0, Math.min(delta, year - m.timeS));
  if (s > 0) {
    rain.add(m.timeS, s, w.landPrecipitationKgM2S.map((v2, k) => w.land[k] > 0 ? v2 / w.land[k] : 0));
    mechanisms.forEach((key, j) => mechanismFlux[j].add(m.timeS, s, w.landPrecipitationComponents[key].map((v2, k) => w.land[k] > 0 ? v2 / w.land[k] : 0)));
    vaporExchange.add(m.timeS, s, w.vaporTransportKgM2.map((v2) => v2 / delta));
    const adv = new Float64Array(n), mix = new Float64Array(n);
    w.grid.edges.forEach((face, k) => {
      adv[face.a] -= w.faceAdvectiveVaporKgM2[k];
      adv[face.b] += w.faceAdvectiveVaporKgM2[k];
      mix[face.a] -= w.faceDiffusiveVaporKgM2[k];
      mix[face.b] += w.faceDiffusiveVaporKgM2[k];
    });
    advectiveExchange.add(m.timeS, s, adv.map((v2) => v2 / delta));
    diffusiveExchange.add(m.timeS, s, mix.map((v2) => v2 / delta));
    transportKeys.forEach((key, j) => transportFlux[j].add(m.timeS, s, w.transportRain[key]));
    snowInput.add(m.timeS, s, w.snowfallKgM2S);
    const values = new Float64Array(n * 8);
    for (let k = 0; k < n; k++) {
      values[k] = m.temperatureK[k];
      values[n + k] = m.landTemperatureK[k];
      values[2 * n + k] = w.atmosphereKgM2[k];
      values[3 * n + k] = w.windEastMps[k];
      values[4 * n + k] = w.windNorthMps[k];
      values[5 * n + k] = w.atmosphereKgM2[k] / moistureCapacity(m.temperatureK[k]);
      values[6 * n + k] = w.convergence[k] * 86400;
      values[7 * n + k] = m.oceanTemperatureK[k];
    }
    drivers.add(m.timeS, s, values);
    coverage.add(m.timeS, s, [1]);
  }
};
var envStep = e.step.bind(e);
e.step = (delta) => {
  envStep(delta);
  const s = Math.max(0, Math.min(delta, year - m.timeS));
  if (s > 0) {
    ice.add(m.timeS, s, e.iceCover);
    snow.add(m.timeS, s, e.snowCover);
    let total = 0, tropicalSea = 0, wet = 0;
    for (let k = 0; k < n; k++) {
      total += w.land[k] * m.landTemperatureK[k] + (1 - w.land[k]) * m.oceanTemperatureK[k];
      if (k >= n / 4 && k < 3 * n / 4) {
        tropicalSea += (1 - w.land[k]) * m.oceanTemperatureK[k];
        wet += 1 - w.land[k];
      }
    }
    temp.add(m.timeS, s, [total / n, tropicalSea / wet]);
  }
};
var records = [];
var waterMax = 0;
var heatMax = 0;
var vaporMax = 0;
var routingMax = 0;
var auditCount = 0;
var lastAuditDay = -1;
var audit = () => {
  const day = Math.floor(m.timeS / 86400);
  if (day === lastAuditDay) return;
  lastAuditDay = day;
  auditCount++;
  const waterError = Math.abs(w.diagnostics().residualMm), heatError = Math.abs(e.enthalpy() - e.initialEnthalpy - m.radiationJm2), vaporError = Math.max(...vapor.residual(w.atmosphereKgM2).map(Math.abs));
  const routingError = Math.abs(w.routing.diagnostics(w).partitionResidualM3);
  waterMax = Math.max(waterMax, waterError);
  heatMax = Math.max(heatMax, heatError);
  vaporMax = Math.max(vaporMax, vaporError);
  routingMax = Math.max(routingMax, routingError);
  assert(waterError < 5e-6 && heatError < 5e-3 && vaporError < 1e-8 && routingError < 1, "Daily budget check failed");
};
for (const days2 of [0, 90, 180, 270, year / 86400]) {
  const end = Math.ceil(days2 * 86400 / dt);
  while (m.steps < end) {
    rt.sync(p, o, Math.min(end, m.steps + 32) * dt + 1e-3, null);
    audit();
  }
  const budget = { waterResidualMm: w.diagnostics().residualMm, enthalpyResidualJm2: e.enthalpy() - e.initialEnthalpy - m.radiationJm2, vaporResidualMm: Math.max(...vapor.residual(w.atmosphereKgM2).map(Math.abs)), routingResidualM3: w.routing.diagnostics(w).partitionResidualM3 };
  waterMax = Math.max(waterMax, Math.abs(budget.waterResidualMm));
  heatMax = Math.max(heatMax, Math.abs(budget.enthalpyResidualJm2));
  vaporMax = Math.max(vaporMax, budget.vaporResidualMm);
  assert(waterMax < 5e-6 && heatMax < 5e-3 && vaporMax < 1e-8);
  records.push({ day: m.timeS / 86400, seconds: (performance.now() - start) / 1e3, budget });
  console.log(JSON.stringify({ label, ...records.at(-1) }));
}
assert(Math.abs(sum2(coverage.total) - year) < 1e-6);
var reference = JSON.parse(await readFile("docs/evidence/earth-seaice-causal-20261011/nsidc-same-grid.json", "utf8"));
var weights = reference.supportM2;
var concentration = ice.months.map((a, j) => Array.from(a, (v2) => v2 / coverage.months[j][0]));
var polar = (c, h) => {
  let extent = 0, area = 0;
  for (let k = 0; k < n; k++) if (h === "north" ? k < n / 2 : k >= n / 2) {
    if (c[k] >= 0.15) extent += weights[k] / 1e12;
    area += c[k] * weights[k] / 1e12;
  }
  return { extentMillionKm2: extent, areaMillionKm2: area };
};
var hemispheres = Object.fromEntries(["north", "south"].map((h) => {
  const monthly = concentration.map((c, j) => ({ month: j + 1, ...polar(c, h), observed: polar(reference.concentration[j], h) }));
  return [h, { monthly, extentMAE: sum2(monthly.map((v2) => Math.abs(v2.extentMillionKm2 - v2.observed.extentMillionKm2))) / 12, areaMAE: sum2(monthly.map((v2) => Math.abs(v2.areaMillionKm2 - v2.observed.areaMillionKm2))) / 12 }];
}));
var gpcc = regions.map((r, i) => ({ ...r, observedAnnualMm: sum2(supports[i].observedMonthlyMm), observedMonthlyMm: Array.from(supports[i].observedMonthlyMm), modelAnnualMm: supports[i].mean(rain.total), annualMechanismsMm: Object.fromEntries(mechanisms.map((key, j) => [key, supports[i].mean(mechanismFlux[j].total)])), monthlyMm: rain.months.map((a) => supports[i].mean(a)), monthlySnowCover: snow.months.map((a, j) => supports[i].mean(a) / coverage.months[j][0]) }));
for (const r of gpcc) assert(Math.abs(sum2(Object.values(r.annualMechanismsMm)) - r.modelAnnualMm) < 1e-7, "Precipitation mechanism partition failed");
await mkdir(out, { recursive: true });
var snowLedger = { initial: Array.from(initialSnow), final: Array.from(w.snowKgM2), snowfall: Array.from(snowfallActual), melt: Array.from(meltActual), compaction: Array.from(compactActual) };
var snowResidual = initialSnow.map((v2, k) => w.snowKgM2[k] - v2 - snowfallActual[k] + meltActual[k] + compactActual[k]);
assert(Math.max(...snowResidual.map(Math.abs)) < 1e-6, "Snow transfer ledger mismatch");
var causal = { transport: transportKeys.map((key, j) => ({ key, annual: Array.from(transportFlux[j].total), monthly: transportFlux[j].months.map((a) => Array.from(a)) })), snowLedger, snowResidualMax: Math.max(...snowResidual.map(Math.abs)), drivers: { keys: ["airK", "landK", "vaporKgM2", "windEastMps", "windNorthMps", "relativeHumidity", "convergenceDay", "oceanK"], monthly: drivers.months.map((a, j) => Array.from(a, (v2) => v2 / coverage.months[j][0])) } };
var vaporBudget = { advectiveNet: Array.from(advectiveExchange.total), diffusiveNet: Array.from(diffusiveExchange.total), monthlyAdvectiveNet: advectiveExchange.months.map((a) => Array.from(a)), monthlyDiffusiveNet: diffusiveExchange.months.map((a) => Array.from(a)), monthlyNetTransport: vaporExchange.months.map((a) => Array.from(a)), initial: Array.from(vapor.initial), final: Array.from(w.atmosphereKgM2), evaporation: Array.from(vapor.evaporation), precipitation: Array.from(vapor.precipitation), netTransport: Array.from(vapor.transport) };
var final = rt.snapshot();
var restored = ThermalRuntime.fromSnapshot(final, p, o);
var next = m.timeS + dt;
restored.attachRestoredTerrain(terrain.landFraction, terrain.landElevation, source);
var lakeVolumeM3 = sum2(Array.from(w.routing.volumeM3).filter((v2, t) => (w.routing.network.inlandLakeId?.[t] ?? 0) > 0));
await writeFile(`${out}/full-${label}-day365.json`, encodeSimulationDocument({ ...d, runtime: final, terrain: { ...d.terrain, settings: { ...d.terrain.settings, timeS: final.state.lastTarget } } }));
rt.sync(p, o, next, null);
restored.sync(p, o, next, null);
assert.deepEqual(restored.snapshot(), rt.snapshot());
await mkdir(out, { recursive: true });
await writeFile(`${out}/full-${label}.json`, JSON.stringify({ stage: "full-earth", lakeVolumeM3, inputSha256: sha(inputRaw), meshTriangles: mesh.numTriangles, label, parameters: profiles[label], formalSha256: sha(raw), initialStockSha, initialEnthalpy: e.initialEnthalpy, dt, bundleSha256: sha(await readFile(process.argv[1], "utf8")), records, causal, vaporBudget, numerics: "compensated-ocean-transfers", budgetMax: { waterMax, heatMax, vaporMax, routingMax }, budgetAudit: { cadence: "at least once per physical day, after completed sync block", auditCount }, strictContinuation: true, hemispheres, gpcc, annualSurfaceMeanC: temp.total[0] / year - 273.15, annualTropicalSeaMeanC: temp.total[1] / year - 273.15, monthlyTemperatureC: temp.months.map((a, j) => Array.from(a, (v2) => v2 / coverage.months[j][0] - 273.15)) }, null, 2) + "\n");
